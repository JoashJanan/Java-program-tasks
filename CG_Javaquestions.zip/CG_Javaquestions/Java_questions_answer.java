Java :
Jira ---> Java8--> springboot --->microservices --> sql --> Push the code to git --> Sonarqube --> AWS(docker &kubernetes for deployment) --> 

### 🔍 Recommended Log Checking Strategy by Stage

| Stage | Log Source | What to Check | Best Tool | Regex Tips |
|-------|------------|----------------|-----------|------------|
| **Jira** | Issue tracking logs | Workflow transitions, comments, status changes | Jira REST API or webhook logs | Use regex to extract issue keys: `([A-Z]+-\d+)` |
| **Java 8 / Spring Boot** | Application logs | Exceptions, request traces, performance | Logback, Log4j, ELK Stack | Match timestamps: `\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}` |
| **Microservices** | Service logs, API gateway | Inter-service calls, latency, errors | ELK, Prometheus + Grafana | Match service names and status codes: `ServiceName=.* Status=\d{3}` |
| **SQL** | DB query logs | Slow queries, failed transactions | MySQL/PostgreSQL logs, pgBadger | Match SQL statements: `SELECT .* FROM .*` |
| **Git** | Commit logs | Who pushed what, commit messages | Git CLI, GitHub/GitLab API | Match commit hashes: `[a-f0-9]{40}` |
| **SonarQube** | Code quality reports | Bugs, vulnerabilities, code smells | SonarQube UI/API | Match issue types: `BUG|VULNERABILITY|CODE_SMELL` |
| **AWS (Docker & Kubernetes)** | Container logs, deployment logs | Resource usage, pod failures, scaling events | CloudWatch, EKS, kubectl logs | Match pod names and error levels: `pod-[\w-]+.*(ERROR|WARN)` |

---

### 🧠 Regex Best Practices

- Use **named groups** for clarity: `(?<timestamp>\d{4}-\d{2}-\d{2})`
- Use **lookahead/lookbehind** for context-sensitive matches: `(?<=ERROR )\w+`
- Escape special characters carefully in Java: `\\d`, `\\s`, etc.

---

### 🛠 Tools You Might Use

- **ELK Stack (Elasticsearch, Logstash, Kibana)** for centralized log analysis
- **Prometheus + Grafana** for metrics and alerting
- **CloudWatch Logs Insights** for AWS-native log queries
- **Regex101.com** for testing and debugging regex patterns

---

Would you like help writing a regex for a specific log format or setting up a log parser for one of these stages?


Project lifecycle:
1.initiation
2.planning
3.Execution
4.monitoring
5.Closing

Two methodology: 
1.Agile
2.Waterfall
Now a days all are using Agile methodology:
Agile methodology 5 phases:
1.Requirement gathering
2.Planning
3.designing
4.development
5.testing
5.deployment


datatypes:(1 byte-8 bit)
byte -1
char,short -2
int ,float -4
long,double -8


Difference between JDK,JRE and JVM?
JDK-> Includes JRE and development tools.
JRE-> It provides libraries and JVM to run java application.
JVM-> It executes java bytecode.

1. JVM (Java Virtual Machine)
- JVM is a virtual machine that provides the environment to run Java programs.
- It converts Java bytecode (compiled Java code) into machine code (understandable by the operating system).
- JVM is platform-independent, meaning Java programs can run on any OS that has a compatible JVM.
- It includes functionalities like memory management (Garbage Collection) and security features.
2. JRE (Java Runtime Environment)
- JRE is a software package that contains everything needed to run Java applications.
- It includes the JVM, along with libraries and other runtime components needed for execution.
- However, JRE does not include the Java compiler, meaning you cannot compile Java code with JRE.
- Ideal for users who just want to run Java applications but don’t need development tools.
3. JDK (Java Development Kit)
- JDK is a complete software development package for Java programmers.
- It includes JRE, JVM, and additional tools like Java compiler (javac), debugging tools, and documentation.
- It enables developers to write, compile, and execute Java programs.
- If you’re a developer, you need JDK because it provides all essential tools to create Java applications.


OOPs:
1.object oriented programmimg language.
2.Its is faster and easier to execute.
3.Its helps the reusable java code.

- Encapsulation (data hiding), Inheritance (code reuse), Polymorphism (multiple forms), and Abstraction (hiding complexity).

oops concept:
Abstraction :Hiding internal details and showing only functionality.(Blue print)
Encapsulation:Binding data and methods together in a single unit.(Capsule)
                 hides the internal details of an object (e.g., keeping data private and providing controlled access via methods).
Inheritance: one object acquires all the properties and behaviors of a parent object.
Polymorishm:Performing a single action in different ways depending on the context.

Java is not fully object oriented programming language:
1.Primitive Data Types: Java has primitive types such as int, char, float, boolean, etc. These are not objects. A key principle of OOP is that everything should be an object, but in Java, primitive types are handled separately for performance reasons.
2.Static Methods and Variables: Java allows the use of static methods and variables. Static members belong to the class itself rather than instances of the class, which means they do not follow the object-oriented principle of "everything should be an object."
3.Memory Management: In Java, memory management and garbage collection are handled automatically by the JVM,.

Constructor:
It is same as the classname.Does not have a return type.


call by value:
Passing the value to the actual parameter.It does not affect the original value.
call by reference:
Passing the address to the actual parameter.It affect the original value.


can you refer static member thorough the class reference?yes 
can you refer static variable thorough the class reference?yes 


Access Specifier Summary:
private: Accessible only within the same class.
default (no specifier): Accessible within the same package.
protected: Accessible within the same package and by subclasses (including subclasses in different packages).
public: Accessible from anywhere, including different packages.

Access Modifiers:
private,default,protected,public,static,final,synchoronized,abstract,volatile,transient,strictfp,native.


Retention Policy:
Lifetime for Annotation.(Source,class and runtime)
source-> Annotations with the source retention policy are only retained in the source code.
         They are ignored by the compiler and not included in the  files.
class -> Annotations with the class retention policy are recorded in the  files by the compiler.
         However, they are not available at runtime.They are useful for tools that work with compiled  files but don't need runtime access.
Runtime ->Annotations with the runtime retention policy are retained in the  files and are available at runtime through reflection.
          These are often used for frameworks and libraries that need access to annotations during program execution, like Spring or Hibernate.


Reflection:
Reflection in Java is the capability of a program to examine and modify its own structure, behavior, and metadata at runtime.

transient modifier:
If a class implements Serializable, all of its fields are eligible to be serialized by default.
If a field is marked as transient, that field will not be serialized, but the rest of the object can still be serialized.
After trying to deserialization of transient variable,it will show the value of (obj=null,number=0,boolean =false).

volatile modifier:
A volatile keyword is used in a multithreading environment where two threads reading and writing the same variable simultaneously.
The volatile keyword flushes the changes directly to the main memory instead of the CPU cache. 


Purpose of assert:
Using this debugging the code.

serialization:
Convert Object to byte stream.

Deserialization:
Convert byte stream to object.

Serialization: ObjectOutputStream.writeObject() converts the object into a byte stream and saves it to a file.
Deserialization: ObjectInputStream.readObject() reads the byte stream from the file and reconstructs the original object.

- Autoboxing: Primitive → Wrapper (int → Integer)
- Unboxing: Wrapper → Primitive (Integer → int)


Thread Communication methods:
wait(),notify(),notifyAll()

difference between extend threadclass and implement runnable interface in java
In general, if you don’t have any other class to extend, extending Thread is simpler, but if you need more flexibility or are working in a more complex application, implementing Runnable is usually the better choice.

String
Immutable
thread safe
cant modify the value
Not synchoronized

String buffer
mutable
thread safe
modify the value
synchoronized

String builder
mutable
not thread safe
modify the value
not synchoronized

Collection:
Collection Framework is a combination of classes and interface, which is used to store and manipulate the data in the form of objects. 
It provides various classes such as ArrayList, Vector, Stack, and HashSet, etc.
interfaces such as List, Queue, Set, etc. for this purpose.

Two ways of thread creation:
Extend thread class and Implements runnable interface. (best is implements runnable interface).

Default bean scope ?
Singleton scope.

Difference between Comparable and Comparator?
Comparable interface can be used to provide single way of sorting.Comparator interface is used to provide different ways of sorting.

Git command in java:
Git commands are not specific to any programming language like Java; 
they are used to manage version control for projects regardless of the programming language being used.

explain about thin driver in jdbc:
JDBC driver that communicates directly with the database server without requiring any native database client software 

JDBC 4 drivers:
Pure java driver 
native protocol
network protocol
native API

JDBC steps:
1.Import JDBC Packages
2.Load and Register JDBC Driver
3.Establish Connection (Use the DriverManager.getConnection() method to establish a connection to the database)
4.Create Statement(create a Statement object using conn.createStatement() to execute sql queries)
5.Execute SQL Queries (ResultSet rs = stmt.executeQuery(sql))
6.Process Results: (process the ResultSet object (rs) to retrieve and manipulate data)
7.close the connection (conn.close())

Singleton design Pattern:
Singleton pattern in Java is a pattern which allows a single instance within an application. One good example of the singleton pattern is java.lang.Runtime.

Singleton Pattern states that define a class that has only one instance and provides a global point of access to it.

In other words, it is the responsibility of the class that only a single instance should be created, and all other classes can use a single object.

There are two ways of creating a Singleton pattern?

1.Early Instantiation
It is responsible for the creation of instance at load time.

2.Lazy Instantiation
It is responsible for the creation of instance when required.


public class Singleton {
    private static Singleton instance;

    private Singleton() {
        // Private constructor prevents instantiation from other classes
    }

    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    public void showMessage() {
        System.out.println("Hello, I am a Singleton instance!");
    }

    public static void main(String[] args) {
        Singleton singleton = Singleton.getInstance();
        singleton.showMessage();
    }
}

Path param and Query(Request) param:
Definition: Path parameters are part of the URL path and are used to identify specific resources. They are defined within the URL structure itself.

Syntax: Typically indicated with curly braces in the API definition, e.g., /users/{userId}.

Definition: Query parameters are used to filter or modify the request and are appended to the URL after a question mark (?).

Syntax: Consist of key-value pairs, separated by &, e.g., ?search=keyword&limit=10.

Path parameters are essential for specifying the resource you want to interact with, while request parameters provide additional options to modify the request or filter the results.


What is Mockito vs JUnit?
JUnit is a testing framework for Java. It allows you to write and run tests for your Java code. It provides annotations like @Test to mark methods as test cases, and assertions like assertEquals() to verify expected outcomes.

JUnit is used to write and run the tests.
Mockito is used to mock dependencies (like UserRepository) and simulate behaviors without needing real implementations.
Always use assertions (assertEquals, assertTrue, etc.) to check if the results are as expected.


Interface:
An interface is not a completely abstract class because it cannot have any implementation (in the basic sense), while an abstract class can contain both abstract methods (which have no implementation) and concrete methods (which do have implementation).

Key Differences: Iterator vs ListIterator
Feature	                         Iterator	                                               ListIterator
Direction of Iteration==>	 One-way (forward)	                                       Two-way (forward and backward)
Used With==>	             Any collection (implements Iterable)	                   Only with List collections (e.g.,                                                                                        ArrayList, LinkedList)
Additional Methods==>	     hasNext(), next(), remove()	                            has Next(), next(), hasPrevious                                                                                        (), previous(), add(), set()
Modify List	==>              Can only remove elements during iteration.                 Can add, set, or remove elements                                                                                        during iteration
Use Cases==>	Simple forward iteration, when you don’t need to modify the collection.	When you need to iterate forward and backward, and also modify the list

user-defined method in Java:
user-defined method is one that you create to solve a problem or to perform an operation that’s needed for your program. You define it once and can call it multiple times from different places in your code.

Which is "most effective" list,set or map?
If you need to store and access items based on a unique key: Map is the best choice.
If you need to store elements in a collection with no duplicates, and the order doesn't matter: Set (especially HashSet) is efficient.
If you need to store elements with possible duplicates and care about the order: List (especially ArrayList) is most effective.

Summary of Drawbacks:
Collection Type    	Drawback
List	            Performance issues with insertions/deletions (especially in the middle or start)
Set               	No duplicates (if you need duplicates, a Set is not suitable)
                    Unordered (in HashSet, no guarantee of insertion order)
Map	                Memory overhead (due to key-value pairs)
                    Key uniqueness (overwrites the existing value for the same key)


JDBC statements:
1.Statement()->1.Used for executing static SQL queries.
               2.Each time a query is executed, it is compiled and executed by the database, which can be less efficient
Statement stmt = connection.createStatement();
ResultSet rs = stmt.executeQuery("SELECT * FROM employees");

2.Preparestatement()->Used for executing precompiled SQL queries with parameters, making it more efficient and secure.

PreparedStatement pstmt = connection.prepareStatement("SELECT * FROM employees WHERE id = ?");
pstmt.setInt(1, 101);
ResultSet rs = pstmt.executeQuery();

3.Callablestatement() ->A CallableStatement in Java is used to execute stored procedures in a database. It extends the PreparedStatement interface and allows you to call procedures that may have IN, OUT, or INOUT parameters.
CallableStatement stmt = connection.prepareCall("{call myProcedure(?, ?)}");
stmt.setInt(1, 100); // Setting IN parameter
stmt.registerOutParameter(2, Types.VARCHAR); // Registering OUT parameter
stmt.execute();
String result = stmt.getString(2); // Retrieving OUT parameter
====================================******************==============================


JAVA 8 features:

Stream API:

In Java 8, the Stream API is used to process the collections of objects.
A stream is a sequence of objects that supports various methods which can be pipelined to produce the desired result.

Intermediate Operators:
Intermediate operation will transform a stream into another stream, such as map(MapperFn) or filter(Predicate).
map(), filter(), distinct(), sorted(), limit(), skip().

Terminal Operators:
Terminal operation will produce a result or side-effect, such as count() or forEach(Consumer).
forEach(), toArray(), reduce(), collect(), min(), max(), count(), anyMatch(), allMatch(), noneMatch(), findFirst(), findAny()


import java.util.Arrays;
import java.util.List;

public class StreamExample {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        // Example 1: Print all numbers in the list
        System.out.println("Example 1: Print all numbers");
        numbers.stream()
               .forEach(System.out::println);

        // Example 2: Filter even numbers and print them
        System.out.println("\nExample 2: Filter even numbers and print");
        numbers.stream()
               .filter(num -> num % 2 == 0)
               .forEach(System.out::println);

        // Example 3: Sum of all numbers using reduce
        System.out.println("\nExample 3: Sum of all numbers");
        int sum = numbers.stream()
                         .reduce(0, (a, b) -> a + b);
        System.out.println("Sum: " + sum);

        // Example 4: Convert numbers to their squares and collect in a list
        System.out.println("\nExample 4: Map to squares and collect in a list");
        List<Integer> squares = numbers.stream()
                                      .map(num -> num * num)
                                      .collect(Collectors.toList());
        System.out.println("Squares: " + squares);
    }
}



import java.util.*;
import java.util.stream.Collectors;
class Sample{
public static void main(String args[])
{
List<String> fruits=Arrays.asList("Apple","Orange","Kiwi");
List<String> demo=fruits.stream()
                  .filter(bowl-> bowl.startsWith("K"))
				  .collect(Collectors.toList());

System.out.println(demo);
}
}

output:
Kiwi

lambda Expression:
A lambda expression is a short block of code which takes in parameters and returns a value. 


(parameter) -> {
	body

forEach:
import java.util.List;  
public class ForEachExample {  
    public static void main(String[] args) {  
        List<String> gamesList = new ArrayList<String>();  
        gamesList.add("Football");  
        gamesList.add("Cricket");  
        gamesList.add("Chess");  
        gamesList.add("Hocky");  
        System.out.println("------------Iterating by passing lambda expression--------------");  
        gamesList.forEach(games -> System.out.println(games)); 
		or
		gamesList.forEach(System.out::println);  
          
    }  
}  
Output:

------------Iterating by passing lambda expression--------------
Football
Cricket
Chess
Hocky


interface Sample{
	int add(int a,int b);

}

class SampleAddition{
public static void main(String args[])
{
	
	Sample ad=(a,b)->(a+b);
	{
		System.out.println("Addition :"+ad.add(10,20));
}
}
}


Functional Interface:
An Interface that contains exactly one abstract method is known as functional interface.
It can have any number of default, static methods but can contain only one abstract method.
Functional interface inbuilt functions: Consumer,Supplier,predicate,function.

Java 8 features:
Lambda expression:
1.what=It is anonymous Function.
2.why= Functional Programming.
3.How=
Before lambda :
Ex:1 public void print()
{
S.o.p("Hi");
}

After lambda: (we have to remove method name, data type and access modifiers)

()
{
S.o.p("Hi");
}

4. Add -> in between () and {}

() ->
{
S.o.p("Hi");
}

Ex:2 Before lambda :
public void add(int a, int b)
{
S.o.p("Hi");
}

After lambda:
(a,b) ->
{
S.o.p("Hi");
}

Ex:3 Before lambda :
public int add(int a, int b)
{
return a+b;
}

After lambda:
(a,b) ->
{
return a+b ;
}



@FunctionalInterface  
interface sayable{  
    void say(String msg);  
}  
public class FunctionalInterfaceExample implements sayable{  
    public void say(String msg){  
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
        FunctionalInterfaceExample fie = new FunctionalInterfaceExample();  
        fie.say("Hello there");  
    }  
} 


Default and static example program:
interface Sayable{    
    // default method    
    default void say(){    
        System.out.println("Hello, this is default method");    
    }    
    // Abstract method    
    void sayMore(String msg);    
    // static method    
    static void sayLouder(String msg){    
        System.out.println(msg);    
    }    
}    
public class DefaultMethods implements Sayable{    
    public void sayMore(String msg){     // implementing abstract method    
        System.out.println(msg);    
    }    
    public static void main(String[] args) {    
        DefaultMethods dm = new DefaultMethods();    
        dm.say();                       // calling default method    
        dm.sayMore("Work is worship");      // calling abstract method    
        Sayable.sayLouder("Helloooo...");   // calling static method    
    }    
}   

Optional Class:
This program terminates abnormally and throws a nullPointerException.
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        Optional<String> optionalString = Optional.of("Hello, World!");

        if (optionalString.isPresent()) {
            System.out.println("Value is present: " + optionalString.get());
        } else {
            System.out.println("Value is absent");
        }
    }
}
Output:Value is present: Hello, World!

Using optional null value checking:
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        String value = null;

        // Wrap the value in an Optional
        Optional<String> optionalValue = Optional.ofNullable(value);

        // Check if the value is present (not null)
        if (optionalValue.isPresent()) {
            System.out.println("Value is: " + optionalValue.get());
        } else {
            System.out.println("Value is null");
        }
    }
}



Hashmap internal working:

Map<String,Integer> demo=new Hashmap<>();
   demo.put("Vasanth",1);
   demo.put("Navila",2);
   
 1.buket
   array of nodes.
 buket ==>(0-16)nodes.
 Each nodes==>hash=key=value=next
 
 2.load factor value (0.75)==>currently node have 16 .which means 2^4 using load factor size will increase 2^5 like that.
 Handling Size (Capacity & Load Factor)
- Capacity → The number of buckets in the HashMap (default: 16).
- Load Factor → When the map reaches 75% full, it resizes (default: 0.75).
- When resizing, the number of buckets doubles to maintain efficiency.
 
 3.Hashing:
   keys to hashcode.
   hashcode is number format(ex 1000)
   every node have hashcode.
   hashcode to index.
   whenever our keys produce same hashcode its called hash collision.If collision happen same node==> next will point the next value this is linked list.
 - If a single bucket has more than 8 elements (default value), Java converts it from a LinkedList to a Red-Black Tree.

 After java8,
 collision is happened here its called the treeify.we set the threshold value for this.{Ex.treeify --4}.
 after it will meet the 4 its converted the balanced tree.
 
Hash Set internal working:

### **How HashSet Works Internally**
A **HashSet** in Java internally uses a **HashMap** to store its elements, ensuring unique values. Here’s what happens internally:

1. **Adding an Element (`add(value)`)**:
   - When you add an element, `HashSet` calls the `put()` method of an internal `HashMap`.
   - The value you add becomes the **key** in the `HashMap`, and the **value** in the `HashMap` is a dummy object (`PRESENT`).
   - The HashMap then computes the **hash code** of the key and assigns it to a specific **bucket** (an array index).

2. **Checking for Duplicates**:
   - If the same element is added again, the HashMap checks if the key already exists.
   - If yes, it **does not add** the duplicate element since a HashMap cannot have duplicate keys.

3. **Retrieval & Lookup (`contains(value)`)**:
   - It finds the bucket corresponding to the **hash code** of the key.
   - It performs **equals()** check to confirm if the element is present.

4. **Collision Handling**:
   - If multiple elements have the same hash code, they are stored in a linked list (Java 7) or a balanced tree (Java 8+), ensuring efficient lookup.

### **Example of Internal Storage**
If we add:
```java
HashSet<String> set = new HashSet<>();
set.add("Apple");
set.add("Banana");
set.add("Apple"); // Duplicate, will not be added
```
Internally, this translates to:
```java
HashMap<String, Object> map = new HashMap<>();
map.put("Apple", PRESENT);
map.put("Banana", PRESENT);
```
Here, `PRESENT` is just a placeholder object.

Hash map vs Hash table vs Hash set:
- Hashtable vs HashMap: Hashtable is synchronized, while HashMap is not.
- Hashtable vs HashSet: Hashtable stores key-value pairs, but HashSet only stores unique values.


HTTP request:
2xx Codes: Use when the request is successful.  (200 -success)
3xx Codes: Use for redirects, when the client needs to perform an additional action.   (302 -Moved Permanently)
4xx Codes: Use for client-side errors that indicate the client sent a bad request.      (400 - bad request)
5xx Codes: Use for server-side errors indicating that the server encountered an issue in processing the request. (500 -Internal Server Error)


Map and flatMap:
map: Transforms each element (one-to-one mapping).
flatMap: Flattens collections or streams into a single stream (one-to-many).


import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMapExample {
    public static void main(String[] args) {
        // Create a list of lists
        List<List<String>> listOfLists = Arrays.asList(
            Arrays.asList("Apple", "Banana"),
            Arrays.asList("Orange", "Pineapple"),
            Arrays.asList("Grapes", "Mango")
        );

        // Use flatMap to flatten the list of lists into a single list
        List<String> flattenedList = listOfLists.stream()
                                                .flatMap(List::stream)
                                                .collect(Collectors.toList());

        // Print the flattened list
        System.out.println("Flattened List: " + flattenedList);
    }
}


custom exception handson?
 It is happened in catch block.
 create a simple BankAccount class that uses the InsufficientFundsException to throw an error if a user tries to withdraw more than the available balance.
 
 Example program:
     BankAccount account = new BankAccount(1000.0);  // Creating an account with $1000 balance

        try {
            // Trying to withdraw more money than the balance
            account.withdraw(1500.0);  // This will throw InsufficientFundsException
        } catch (InsufficientFundsException e) {
            // Handle the custom exception
            System.out.println("Error: " + e.getMessage());
        }
		

Multithreading -Runnable vs Callable?
Runnable Interface
Purpose: Represents a task that can be executed concurrently by a thread.
Method: Contains a single method run() with no parameters and no return value.
Usage: Often used for tasks where you don’t need to return a result or handle exceptions beyond what is done inside the run() method.

Callable Interface
Purpose: Represents a task that can be executed concurrently by a thread and returns a result.
Method: Contains a single method call() which returns a result and can throw a checked exception.
Usage: Used for tasks that need to return a result or handle exceptions beyond what is done inside the call() method.

Path and class variable:
Path is for locating executable files (Java binaries like java, javac), while Classpath is for locating Java classes and libraries at runtime.
Path affects your ability to run Java commands from the command line, while Classpath ensures that your Java program can access the necessary classes and libraries during execution.

Path: C:\Program Files\Java\jdk-11\bin
Classpath : C:\path\to\your\project\classes;C:\path\to\libs\some-library.jar


 What is the purpose of the synchronized keyword? How does it ensure thread safety?
In order, to ensure that only one thread is running the synchronized code, the Java  synchronized keyword employs locks on objects or classes internally.

Difference between wait(),notify() and notifyAll()?
method	                     Description	                                         How to Use
sleep()	     Pauses the current thread for a specified time.	                    Thread.sleep(milliseconds);
wait()	     Causes the current thread to wait until notified or interrupted.	Must be called from within a synchronized block.
notify()	Wakes up one thread that is waiting on the object's monitor.	    Must be called from within a synchronized block.
notifyAll()	Wakes up all threads that are waiting on the object's monitor.	    Must be called from within a synchronized block.


Project explanation:

BFIAS System - Banking Domain Project (Banking Financial Information & Account System)
Overview
The BFIAS system is a banking domain application designed to store and monitor customer details efficiently.
- Personal Information: Name, date of birth, address, phone number, email ID.
- Identification Details: Government-issued ID (passport, Aadhaar, PAN card, etc.).
- Account Information: Account number, type of account (savings, current, loan, etc.), transaction history.
- Financial Data: Income details, credit score, loan records, investment portfolios.
- KYC (Know Your Customer) Data: Verification documents, risk assessment, compliance records.
- Transaction Monitoring: Deposits, withdrawals, fund transfers, suspicious activity tracking.
- Security Information: Login credentials, authentication methods, fraud detection mechanisms.

Key Features & Functionality
- The system enables banks to track and manage customer details.
- Supports Spring Boot REST API for various banking operations.
REST API Implementation
We implemented different HTTP methods for customer account management:
- POST → Registers a new customer (customer login).
- GET → Retrieves customer details based on a


ccount number.
- PUT → Updates customer information.
- DELETE → Removes customer records.
Database & Connectivity
- SQL Database (MySQL/PostgreSQL) used for storing customer data.
- JDBC Connectivity facilitates seamless interaction between the application and the database.
Security Implementation
- JWT Token is used for authentication and authorization, ensuring secure access to customer accounts.
Exception Handling
- The application handles errors, such as a customer trying to withdraw more than the available account balance, ensuring proper validation.


To describe your **roles and responsibilities** for the BFIAS System project, you should tailor it to the tasks you actively handled. Here's a structured approach:

### **Roles and Responsibilities in BFIAS System Project**
1. **Requirement Analysis & Design**  
   - Gathered and analyzed banking requirements to define system functionalities.  
   - Designed REST API endpoints for customer account management.  

2. **Backend Development (Spring Boot & REST API)**  
   - Developed and implemented RESTful APIs using Spring Boot for banking operations (POST, GET, PUT, DELETE).  
   - Integrated MySQL/PostgreSQL database with the application using JDBC for seamless data management.  

3. **Security Implementation**  
   - Implemented **JWT-based authentication and authorization** to ensure secure access to customer accounts.  
   - Applied role-based access control for different banking users.  

4. **Exception Handling & Validation**  
   - Designed robust exception handling mechanisms to validate transactions (e.g., preventing overdrafts).  
   - Ensured proper error messaging and status codes for API responses.  

5. **Testing & Deployment**  
   - Conducted **unit and integration testing** to validate API functionalities.  
   - Assisted in deploying the application to a production or cloud environment.  

6. **Maintenance & Performance Optimization**  
   - Optimized SQL queries for efficient data retrieval.  
   - Ensured smooth application performance and scalability.  

Would you like me to refine this for a resume or interview format? I can help you craft a polished version!

BFIAS-System/
│── src/main/java/com/bfias/
│   ├── config/
│   │   ├── SecurityConfig.java   # Spring Security Configuration
        |-  GlobalExceptionHandler.java
│   ├── controller/
│   │   ├── CustomerController.java   # Handles API requests
│   ├── model/
│   │   ├── Customer.java   # Defines customer entity
│   ├── repository/
│   │   ├── CustomerRepository.java   # Database interactions
│   ├── service/
│   │   ├── CustomerService.java   # Business logic for customers
│   │   ├── JwtUtil.java           # Generates & verifies JWT
│   ├── Application.java           # Main entry point
│── pom.xml (Dependencies)
│── application.properties (Database & security configs)


### **1️⃣ Customer Entity (model/Customer.java)**
```java
@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String accountNumber;

    private String name;
    private String email;
    private double balance;

    // Getters and Setters
}
```

---

### **2️⃣ Repository for Customer Data (repository/CustomerRepository.java)**
```java
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Optional<Customer> findByAccountNumber(String accountNumber);
}
```

---

### **3️⃣ JWT Utility (service/JwtUtil.java)**
```java
public class JwtUtil {
    private String secretKey = "yourSecretKey";

    // New Token generator

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
				.claim("role", role) // Add user role to JWT
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000)) //15 min
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }
	
// Refresh Token

public String generateRefreshToken(String username) {
    return Jwts.builder()
            .setSubject(username)
            .setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + 604800000)) // 7 days expiry
            .signWith(SignatureAlgorithm.HS256, secretKey)
            .compact();
}

// Token checker
    public Claims extractClaims(String token) {
        return Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody();
				.get("role", String.class); // Get role from JWT

    }
}
```

---

### **4️⃣ Customer Service (service/CustomerService.java)**
```java
@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public Optional<Customer> getCustomerByAccountNumber(String accountNumber) {
        return customerRepository.findByAccountNumber(accountNumber);
    }

    public Customer updateCustomer(Long id, Customer updatedCustomer) {
        return customerRepository.findById(id).map(customer -> {
            customer.setName(updatedCustomer.getName());
            customer.setEmail(updatedCustomer.getEmail());
            customer.setBalance(updatedCustomer.getBalance());
            return customerRepository.save(customer);
        }).orElseThrow(() -> new RuntimeException("Customer not found"));
    }

    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }
}
```

---

### **5️⃣ Customer API Controller (controller/CustomerController.java)**
```java
@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        return ResponseEntity.ok(customerService.createCustomer(customer));
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<Customer> getCustomer(@RequestHeader("Authorization") String token, @PathVariable String accountNumber) {
        String role = new JwtUtil().extractClaims(token.replace("Bearer ", "")).get("role", String.class);
        if (!role.equals("CUSTOMER") && !role.equals("BANKER")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        return customerService.getCustomerByAccountNumber(accountNumber)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @RequestBody Customer updatedCustomer) {
        return ResponseEntity.ok(customerService.updateCustomer(id, updatedCustomer));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@RequestHeader("Authorization") String token, @PathVariable Long id) {
        String role = new JwtUtil().extractClaims(token.replace("Bearer ", "")).get("role", String.class);
        if (!role.equals("ADMIN")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
}
```

---

### **6️⃣ Spring Security Configuration (config/SecurityConfig.java)**
```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/admin/**").hasAuthority("ADMIN")
                .requestMatchers("/api/customer/**").hasAnyAuthority("CUSTOMER", "BANKER")
                .anyRequest().authenticated()
            )
            .oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt); // JWT Authentication

        return http.build();
    }
}
```

---

### **7️⃣ Database Configuration (application.properties)**
```
spring.datasource.url=jdbc:mysql://localhost:3306/bfias
spring.datasource.username=root
spring.datasource.password=yourpassword
spring.jpa.hibernate.ddl-auto=update
```

# ✅ JWT Secret Key (Security Configuration)
jwt.secret=yourSecretKey
jwt.expiration=900000   # 15 minutes (in milliseconds)
jwt.refresh-expiration=604800000   # 7 days (in milliseconds)

---


********** POM.XML:
<dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- ✅ Spring Boot Starter for JPA (ORM) -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>

*****Global Exception Handler:
	
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<String> handleEntityNotFoundException(EntityNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGeneralException(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred!");
    }
}

@PostMapping
public ResponseEntity<?> createCustomer(@RequestBody Customer customer) {
    if (customer.getAccountNumber() == null || customer.getName() == null) {
        throw new IllegalArgumentException("Account number and name must be provided!");
    }
    return ResponseEntity.ok(customerService.createCustomer(customer));
}

### **🔹 Summary of Features**
✅ **Customer Account Management (CRUD - POST, GET, PUT, DELETE)**  
✅ **JWT Authentication** (User must provide a valid token)  
✅ **JWT Authorization** (Only customers & bankers can access accounts, only admins can delete records)  
✅ **Spring Security Integration** 


===================================================************************================================================
JWT Token Generator:

public class JwtUtil {
    private String secretKey = "yourSecretKey";
	
// New Token generator

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
				.claim("role", role) // Add user role to JWT
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000)) //15 min
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }
	
// Refresh Token

public String generateRefreshToken(String username) {
    return Jwts.builder()
            .setSubject(username)
            .setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + 604800000)) // 7 days expiry
            .signWith(SignatureAlgorithm.HS256, secretKey)
            .compact();
}

// Token checker
    public Claims extractClaims(String token) {
        return Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody();
				.get("role", String.class); // Get role from JWT

    }
}

You can call generateAccessToken() and generateRefreshToken() by creating an instance of TokenService and passing a username as an argument. Here's how you do it:

public class AuthController {
    private TokenService tokenService = new TokenService(); // Create an instance

    public void loginUser(String username) {
        // Generate tokens
        String accessToken = tokenService.generateAccessToken(username);
        String refreshToken = tokenService.generateRefreshToken(username);

        // Print tokens (In real applications, send them in response headers)
        System.out.println("Access Token: " + accessToken);
        System.out.println("Refresh Token: " + refreshToken);
    }

    public static void main(String[] args) {
        AuthController authController = new AuthController();
        authController.loginUser("user123"); // Call loginUser with a sample username
    }
}

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/admin/**").hasAuthority("ADMIN")
                .requestMatchers("/api/customer/**").hasAnyAuthority("CUSTOMER", "BANKER")
                .anyRequest().authenticated()
            )
            .oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt); // JWT Authentication

        return http.build();
    }
}
=========================================================================================================
Here’s a **Spring Boot REST API** implementation for your **BFIAS banking system**, covering **customer management, authentication (JWT), and exception handling**.

---

### **1. Customer Entity (SQL Database)**
```java
@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String accountNumber;
    private Double balance;
}
```

---

### **2. Customer Repository (JDBC Connectivity)**
```java
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Optional<Customer> findByAccountNumber(String accountNumber);
}
```

---

### **3. Customer Service (Business Logic)**
```java
@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public Customer getCustomerByAccountNumber(String accountNumber) {
        return customerRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }

    public Customer updateCustomer(Long id, Customer updatedCustomer) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        customer.setName(updatedCustomer.getName());
        customer.setBalance(updatedCustomer.getBalance());
        return customerRepository.save(customer);
    }

    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }
}
```

---

### **4. Customer Controller (Spring Boot REST API)**
```java
@RestController
@RequestMapping("/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        return ResponseEntity.ok(customerService.createCustomer(customer));
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<Customer> getCustomer(@PathVariable String accountNumber) {
        return ResponseEntity.ok(customerService.getCustomerByAccountNumber(accountNumber));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @RequestBody Customer customer) {
        return ResponseEntity.ok(customerService.updateCustomer(id, customer));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.ok("Customer deleted successfully");
    }
}
```

---

### **5. JWT Authentication (Security)**
```java
@Component
public class JwtUtil {
    private String secretKey = "bankingSecret";

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60))
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }

    public Claims validateToken(String token) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();
    }
}
```

---

### **6. Exception Handling (Withdraw Limit)**
```java
@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<String> handleException(RuntimeException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    }
}
```

---

### **How This Works?**
✅ **Spring Boot REST API** handles customer operations.  
✅ **SQL Database with JDBC** stores customer details.  
✅ **JWT Authentication** secures login and authorization.  
✅ **Exception Handling** prevents invalid withdrawals.  



JDBC Communication with SQL
import java.sql.*;

public class JdbcExample {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/bankdb";
        String user = "root";
        String password = "password";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM customers")) {

            while (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Balance: " + rs.getDouble("balance"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

Thread:
Threads are a fundamental part of Java's concurrency model, allowing multiple tasks to run simultaneously. Here's a breakdown of key **thread concepts**:

### **1. What is a Thread?**
A **thread** is the smallest unit of execution in a program. It runs independently and shares resources with other threads in the same process.

### **2. Types of Threads**
- **User Threads**: Actively perform tasks in an application (e.g., background processing).
- **Daemon Threads**: Run in the background and automatically terminate when all user threads finish (e.g., garbage collection).

### **3. Creating Threads in Java**
You can create a thread using:
#### **a) Extending `Thread` Class**
```java
class MyThread extends Thread {
    public void run() {
        System.out.println("Thread is running...");
    }
}

public class Main {
    public static void main(String[] args) {
        MyThread t1 = new MyThread();
        t1.start(); // Starts the thread
    }
}
```

#### **b) Implementing `Runnable` Interface**
```java
class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread is running...");
    }
}

public class Main {
    public static void main(String[] args) {
        Thread t1 = new Thread(new MyRunnable());
        t1.start();
    }
}
```
### **4. Thread Lifecycle**
A thread goes through the following states:
1. **New** → Created but not started.
2. **Runnable** → Ready to run but waiting for CPU.
3. **Running** → Actively executing.
4. **Blocked** → Waiting for a resource.
5. **Terminated** → Completed execution.

### **5. Thread Synchronization**
When multiple threads access shared resources, synchronization ensures **data consistency**.
Example:
```java
synchronized (object) {
    // Critical section
}
```

### **6. Thread Methods**
- `start()` – Starts a thread.
- `sleep(ms)` – Pauses execution for a given time.
- `join()` – Waits for another thread to finish.
- `yield()` – Suggests the thread scheduler to give other threads a chance.
- `isAlive()` – Checks if a thread is still running.

### **7. Multi-threading Benefits**
✅ Better CPU utilization  
✅ Parallel execution  
✅ Faster performance for complex tasks  



Jenkins port: 8080

AWS link : https://teams.microsoft.com/l/message/19:03187be9-3246-428e-b88e-a5c07bdb4820_7dd3234e-abc5-4f79-91f6-f705745de7cf@unq.gbl.spaces/1758091843896?context=%7B%22contextType%22%3A%22chat%22%7D
=====================================================================================================
Welcome back to JWT token creation! Let’s quickly recap and walk through the **simplest way to implement JWT authentication** in your Spring Boot project. Here's a clean and minimal setup:

---

## 🔐 JWT Token Creation in Spring Boot — Simplified

### ✅ 1. Add Dependencies (Maven)

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt</artifactId>
    <version>0.9.1</version>
</dependency>
```

---

### ✅ 2. Create `JwtUtil.java`

```java
@Component
public class JwtUtil {
    private final String SECRET_KEY = "secret";

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hour
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }

    public String extractUsername(String token) {
        return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateToken(String token, String username) {
        return extractUsername(token).equals(username);
    }
}
```

---
3. **Use BCrypt to Hash Passwords**

Spring Security provides `BCryptPasswordEncoder` for hashing passwords.

#### Add to your configuration:

```java
@Bean
public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
}
```

---

### ✅ 4. **Hash Passwords Before Storing**

When registering a user (e.g., in a `UserService`):

```java
@Autowired
private PasswordEncoder passwordEncoder;

public void registerUser(String username, String rawPassword) {
    String hashedPassword = passwordEncoder.encode(rawPassword);
    userRepository.save(new User(username, hashedPassword));
}
```

---

### ✅ 5. **Verify Password During Login**

Update your `/login` endpoint to check hashed passwords:

```java
@Autowired
private PasswordEncoder passwordEncoder;

@Autowired
private UserRepository userRepository;

@PostMapping("/login")
public ResponseEntity<String> login(@RequestBody Map<String, String> user) {
    String username = user.get("username");
    String password = user.get("password");

    User dbUser = userRepository.findByUsername(username);
    if (dbUser != null && passwordEncoder.matches(password, dbUser.getPassword())) {
        String token = jwtUtil.generateToken(username);
        return ResponseEntity.ok(token);
    } else {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
    }
}



---

### ✅ 7. Create JWT Filter

```java
@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            String username = jwtUtil.extractUsername(token);

            if (username != null && jwtUtil.validateToken(token, username)) {
                UsernamePasswordAuthenticationToken auth =
                        new UsernamePasswordAuthenticationToken(username, null, new ArrayList<>());
                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        }

        chain.doFilter(request, response);
    }
}
```

---

### ✅ 8. Configure Security

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private JwtFilter jwtFilter;
    
	@Override
    protected void configure(HttpSecurity http) throws Exception {
    http.csrf().disable()
        .authorizeRequests()
        .requestMatcher("/login").hasRole("Admin").permitAll()
        .anyRequest().authenticated();

    http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
}
}
```

---

### ✅ 6. Test It

1. **POST** to `/login` with:
   ```json
   {
     "username": "admin",
     "password": "password"
   }
   ```

2. Use the returned token in the header:
   ```
   Authorization: Bearer <your_token>
   ```

3. Access your protected endpoints like `/studentnew`.

---

Would you like me to help you plug this into your existing `StudentController` project or generate a full working zip?



To **encrypt the username and password** in your Spring Boot JWT authentication setup, you typically **hash the password** (not encrypt it) and store it securely in the database. Here's how to do it properly: