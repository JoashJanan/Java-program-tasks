JAVA stream API?

  .filter()  ===>(addition,odd or even)
  .map()    ==>(multiply)
  .sorted()==>(sorting)
  .sorted(Comparator.reverseOrder())   ==>(reversing )
  .forEach(System.out::println) ===>(iteration and printing the values)
  .count()  ==> counting the values
  .skip()  ==>(as per need skip the element)
  .distinct() ==>(remove the duplicates)
  .peek()  ==>(print each element after skipping)
  .mapToObj===>(changing the integer to char)
  .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));  ==>character counts
  .collect(Collectors.joining(",", "[", "]"))  ==>prefix,suffix
  .mapToInt(Integer::intValue)
                         .max()
                         .orElseThrow()     ========>(maximum)
						 
	Arrays.stream(arr1)==>(Array creation)
	.limit()  ==>(limited values)
	Stream.of(s1.split(""))  ===>(converts string into char)
	Arrays.stream(a).sum();  ==>(Sum of the array values)
	list1.stream().filter(list2::contains)  ==>(returns the common elements of the first array)
    IntStream.rangeClosed(1, 10)	  ===>(return range of values)
	IntStream.range(1,a.length)
                  .map(i->a[a.length-i]).toArray()  ==>(reverse the array)
				  
    {
	List<Integer> listOfIntegers = Arrays.asList(111, 222, 333, 111, 555, 333, 777, 222);
         
        Set<Integer> uniqueElements = new HashSet<>();
         
        Set<Integer> duplicateElements = listOfIntegers.stream().filter(i -> ! uniqueElements.add(i)).collect(Collectors.toSet());
         
        System.out.println(duplicateElements);
		}
	.filter(i -> ! uniqueElements.add(i))  ==>(return duplicates)


==================================================================================
One way:
          String a=scan.nextLine();
          List<Integer> test=Arrays.stream(a.split(" "))

Two way:
         String a=scan.nextLine();         
         String[] demo=a.split(" ");
         Arrays.stream(demo)

Third way:
    String a=scan.nextLine();
    List<String> demo = Arrays.asList(a.split(" "));
	       demo.stream
	
- List<Integer>.stream() → Stream<Integer> → Use .map()
- int[].stream() → IntStream → Use .mapToObj()


Numeric operations (sum, avg,count,min,max,filter and map) => boxed() no need.
Collecting into List<Integer>  ==> boxed() need

=====================================================================================

1.list of integers, separate odd and even numbers?

import java.util.*;
import java.util.stream.Collectors;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
          List<Integer> test = Arrays.stream(a.split(" "))
                                .mapToInt(Integer::parseInt)
                                .boxed()
                                .filter(i->i%2==0)
                                .collect(Collectors.toList());
                                
        System.out.println(test);
         
         
    }
}
----------------------------------------------------------------
import java.util.*;

class Sample{
    public static void main(String arg[])
    {
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        
       System.out.println("EVEN NUM IS:");
       Arrays.stream(s.split(" "))
                  .mapToInt(Integer::parseInt)
                 .filter(i->i%2==0)
                 .forEach(System.out::println);
                 
       System.out.println("ODD NUM IS:");
       Arrays.stream(s.split(" "))
                 .mapToInt(Integer::parseInt)
                 .filter(i->!(i%2==0))
                 .forEach(System.out::println);
    }
}

=============*************===================================

import java.util.*;

class Sample{
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        String a=s.next();
        Arrays.stream(a.split(" "))
        .mapToInt(Integer::parseInt)
        .boxed()
        .map(i->(i%2==0) ?"EVEN":"ODD")
        .forEach(System.out::print);
        
    }
}

====********************************************=======================
2.Remove duplicate elements from a list 
import java.util.*;
import java.util.stream.Collectors;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
         
         List<Integer> test=Arrays.stream(a.split(" "))
                                .mapToInt(Integer::parseInt)
                                .boxed()
                                .distinct()
                                .collect(Collectors.toList());
                                
           System.out.println(test);
    }
}
-----------------------------------------------
import java.util.*;

class Sample{
    public static void main(String arg[])
    {
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        
                  Arrays.stream(s.split(" "))
                 .distinct()
                 .forEach(System.out::println);
    }
}
======================**************************=====================================================================
3.Find frequency of each character in a string using Java 8 streams
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;

public class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        // Use streams to map each character to its frequency
        Map<Character, Long> frequencyMap = a.chars() // IntStream of char values
                .mapToObj(c -> (char) c) // Map to Character objects
                .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new, Collectors.counting()));

        System.out.println(frequencyMap);
    }
}


====================================================================

4.find frequency of each element in an array or a list?
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
         
         Map<String,Long> test=Arrays.stream(a.split(" "))
                                  .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
                                
       System.out.println(test);
         
         
    }
}

5.sort the given list of decimals in reverse order?
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
         
         String[] demo=a.split(" ");
         Arrays.stream(demo)
         .mapToInt(Integer::parseInt)
         .boxed()
         .sorted(Comparator.reverseOrder())
         .forEach(System.out::println);                             
     }
}

6.Given a list of strings, join the strings with ‘[‘ as prefix, ‘]’ as suffix and ‘,’ as delimiter?


import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
         
         String[] demo=a.split(" ");
     String test= Arrays.stream(demo)
         .collect(Collectors.joining(",","[","]"));
         
         System.out.println(test);    
    }
}

7.From the given list of integers, print the numbers which are multiples of 5?
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
         
         String[] demo=a.split(" ");
    List<Integer> test= Arrays.stream(demo)
                  .mapToInt(Integer::parseInt)
                  .boxed()
                  .filter(i->i%5==0)
                  .collect(Collectors.toList());
         
         System.out.println(test);    
    }
}

8.Given a list of integers, find maximum and minimum of those numbers

import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
         
         String[] demo=a.split(" ");
    int test= Arrays.stream(demo)
                  .mapToInt(Integer::parseInt)
                  .max()
                  .orElseThrow(NoSuchElementException::new);
                  
         System.out.println("Maximum value is:"+test);
             
         
     int test1= Arrays.stream(demo)
                  .mapToInt(Integer::parseInt)
                  .min()
                  .orElseThrow(NoSuchElementException::new);
                  
         System.out.println("Minimum value is:"+test1);

         
    }
}

9.How do you merge two unsorted arrays into single sorted array using Java 8 streams

Using integer:
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.stream.Stream;



class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
          String b=scan.nextLine();

         
         String[] demo=a.split(" ");
         String[] demo1=b.split(" ");

    int[] test=Stream.concat(Arrays.stream(demo), Arrays.stream(demo1))
                     .mapToInt(Integer::parseInt)
                     .sorted()
                     .toArray();
                 
                  
        System.out.println(Arrays.toString(test));
                  

         
    }
}

using String:
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.stream.Stream;

class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
          String b=scan.nextLine();
          
          String[] demo=a.split(" ");
          String[] demo1=b.split(" ");

    String test=Stream.concat(Arrays.stream(demo), Arrays.stream(demo1))
                .collect(Collectors.joining("")); 
     
     System.out.println(test);
        
    }
}


=========================================================
import java.util.*;

class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter first string: ");
        String s1 = scan.nextLine();
        System.out.print("Enter second string: ");
        String s2 = scan.nextLine();

        List<String> demo = Arrays.asList(s1.split(" "));
        List<String> demo1 = Arrays.asList(s2.split(" "));

        Stream.concat(demo.stream(), demo1.stream())
                .forEach(System.out::println);
    }
}


10.How do you merge two unsorted arrays into single sorted array without duplicates

import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.stream.Stream;



class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
          String b=scan.nextLine();

         
         String[] demo=a.split(" ");
         String[] demo1=b.split(" ");

    int[] test=Stream.concat(Arrays.stream(demo), Arrays.stream(demo1))
               .mapToInt(Integer::parseInt)
               .sorted()
			   .distinct()
               .toArray();
                 
                  
        System.out.println(Arrays.toString(test));
                  

         
    }
}

11.How do you get three maximum numbers and three minimum numbers from the given list of integers?
import java.util.*;
import java.util.stream.Collectors;

public class MaxMinNumbers {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        // Read integers separated by spaces
        System.out.println("Enter integers separated by spaces:");
        String input = scan.nextLine();
        
        
        List<Integer> maxNumbers = Arrays.stream(input.split(" "))
                                      .mapToInt(Integer::parseInt)
                                         .boxed()
                                         .sorted(Comparator.reverseOrder())
                                         .limit(3)
                                         .collect(Collectors.toList());
        
        System.out.println("Three maximum numbers: " + maxNumbers);
        
        
        List<Integer> minNumbers = Arrays.stream(input.split(" "))
                                      .mapToInt(Integer::parseInt)
                                         .boxed()
                                         .sorted()
                                         .limit(3)
                                         .collect(Collectors.toList());
        
        System.out.println("Three minimum numbers: " + minNumbers);
    }
}

12.Java 8 program to check if two strings are anagrams or not?
import java.util.*;
import java.util.stream.Collectors;

public class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter first string:");
        String a = scan.nextLine().trim();
        System.out.println("Enter second string:");
        String b = scan.nextLine().trim();
        
        String sortedA = Arrays.stream(a.split(""))
                               //.map(String::toUpperCase)
                               .sorted()
                               .collect(Collectors.joining());
        
        String sortedB = Arrays.stream(b.split(""))
                             //  .map(String::toUpperCase)
                               .sorted()
                               .collect(Collectors.joining());
        
        if (sortedA.equals(sortedB)) {
            System.out.println("Anagram");
        } else {
            System.out.println("Not an Anagram");
        }
    }
}

====================================================================

import java.util.*;

class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the first string:");
        String s1 = scan.nextLine();
        System.out.println("Enter the second string:");
        String s2 = scan.nextLine();
        
        // Sort characters of the strings using streams
        String sortedS1 = Arrays.stream(s1.split(""))
                               .sorted()
                               .reduce("", (a, b) -> a + b);
        
        String sortedS2 = Arrays.stream(s2.split(""))
                               .sorted()
                               .reduce("", (a, b) -> a + b);
        
        // Compare sorted strings
        if (sortedS1.equals(sortedS2)) {
            System.out.println("It is an anagram");
        } else {
            System.out.println("Not an anagram");
        }
    }
}


13.Find sum of all digits of a number in Java 8?
import java.util.*;
import java.util.stream.Collectors;
class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String input=scan.nextLine();
          
          int intArray = Arrays.stream(input.split(" "))
                               .mapToInt(Integer::parseInt)
                               .sum();
                               
                System.out.println(intArray);
    }
        
         
    }


14.Find second largest number in an integer array?
import java.util.*;
import java.util.Comparator;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
          
          int[] c=Arrays.stream(a.split(" "))
                        .mapToInt(Integer::parseInt)
                        .toArray();
     
            int d  =Arrays.stream(c)
                         .boxed()
                        .sorted(Comparator.reverseOrder())
                        .skip(1)
                        .findFirst()
                        .orElseThrow(NoSuchElementException::new);
                        
                      
        System.out.print(d);      
        
         
    }
}

===================================*************************

import java.util.*;
import java.util.Comparator;

public class Main
{
	public static void main(String[] args) {
	    
	  int a[]={1,89,56,92};
	  
	    Arrays.stream(a)
	    .boxed()
	    .sorted(Comparator.reverseOrder())
	    .skip(1)
	    .findFirst()
	    .ifPresent(System.out::print);

	}
}

======================================*********************
import java.util.*;
import java.util.Comparator;


class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
     
                        Arrays.stream(a.split(" "))
                        .mapToInt(Integer::parseInt)
                        .boxed()
                        .sorted(Comparator.reverseOrder())
                        .skip(1)
                        .findFirst()
                        .ifPresent(System.out::println);
                        
        }
}


15.Given a list of strings, sort them according to increasing order of their length?
import java.util.*;
import java.util.Comparator;

class Sample
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        
          String a=scan.nextLine();
          
          Arrays.stream(a.split(" "))
                        .sorted(Comparator.comparing(String::length))
                        .forEach(System.out::println);
                        
    }
}

16.Given an integer array, find sum and average of all elements?
import java.util.*;

public class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter integers separated by spaces:");
        String input = scan.nextLine();
        
        
        int[] intArray = Arrays.stream(input.split(" "))
                               .mapToInt(Integer::parseInt)
                               .toArray();
        
        // Calculate sum using Stream API
        int sum1 = Arrays.stream(intArray)
                        .sum();
        
        double sum2 = Arrays.stream(intArray)
                        .average().getAsDouble();
        System.out.println("Sum of integers: " + sum1);
        System.out.println("Average of integers: " + sum2);

    }
}


                  OR
				  
				  
				  
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        
        // Calculate the sum
        int add = Arrays.stream(a.split(" "))
                        .mapToInt(Integer::parseInt)
                        .sum();
        
        System.out.println("SUM: " + add);

        // Calculate the average
        OptionalDouble avg = Arrays.stream(a.split(" "))
                                   .mapToInt(Integer::parseInt)
                                   .average();
        
        // Print the average if present, otherwise print 0.0
        System.out.println("AVG: " + (avg.isPresent() ? avg.getAsDouble() : 0.0));
    }
}



17.How do you find common elements between two arrays?
import java.util.*;
import java.util.stream.Collectors;

class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        
        String s1 = scan.nextLine();
        String s2 = scan.nextLine();
        
        // Split strings by spaces to get individual numbers
        String[] s3 = s1.split(" ");
        String[] s4 = s2.split(" ");
        
        // Convert string arrays to int arrays
        int[] test = Arrays.stream(s3)
                           .mapToInt(Integer::parseInt)
                           .toArray();
        
        int[] test1 = Arrays.stream(s4)
                            .mapToInt(Integer::parseInt)
                            .toArray();
        
        // Find common elements between test and test1
        List<Integer> commonElements = Arrays.stream(test)
                                             .filter(num -> Arrays.stream(test1)
                                                                  .anyMatch(num1 -> num1 == num))
                                             .boxed() // Convert int to Integer for collecting
                                             .collect(Collectors.toList());
        
        if (commonElements.isEmpty()) {
            System.out.println("No common integers found.");
        } else {
            System.out.println("Common integers: " + commonElements);
        }
    }
}

==============================================================================
import java.util.*;
import java.util.stream.Collectors;

class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        
        // Read two lines of input from the user
        String s = scan.nextLine();
        String s1 = scan.nextLine();
        
        // Split s and s1 by spaces, parse to integer arrays
        int[] arr1 = Arrays.stream(s.split(" "))
                           .mapToInt(Integer::parseInt)
                           .toArray();
        
        int[] arr2 = Arrays.stream(s1.split(" "))
                           .mapToInt(Integer::parseInt)
                           .toArray();
        
        // Convert arr1 to a set for fast containment check
        Set<Integer> set = Arrays.stream(arr1)
                                 .boxed()  // Convert int to Integer
                                 .collect(Collectors.toSet());
        
        // Stream over arr2, filter elements present in set, and print
        Arrays.stream(arr2)
              .filter(set::contains)
              .forEach(System.out::println);
    }
}

=================================================================================================
using string:
import java.util.*;
import java.util.stream.Collectors;

class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        
        // Read two lines of input
        String s1 = scan.nextLine();
        String s2 = scan.nextLine();
        
        // Split input strings by space to get individual strings
        String[] s3 = s1.split(" ");
        String[] s4 = s2.split(" ");
        
        // Convert string arrays to List<String> for easier operations
        List<String> list1 = Arrays.asList(s3);
        List<String> list2 = Arrays.asList(s4);
        
        // Find common elements between list1 and list2
        List<String> commonElements = list1.stream()
                                          .filter(list2::contains)
                                          .collect(Collectors.toList());
        
        if (commonElements.isEmpty()) {
            System.out.println("No common strings found.");
        } else {
            System.out.println("Common strings: " + commonElements);
        }
    }
}

     

================================================================================================
import java.util.*;
import java.util.stream.Collectors;

class Sample{
    public static void main(String args[])
    {
        
       Scanner scan=new Scanner(System.in);
       String s=scan.nextLine();
       String s1=scan.nextLine();
     Set<String> test=new HashSet<>(Arrays.asList(s1.split("")));
      
        Arrays.stream(s.split(""))
        .filter(test::contains)
        .forEach(System.out::print);
    }
}

input: s=flower
       s1=flow
output:flow

18.Reverse each word of a string using Java 8 streams?
import java.util.*;
import java.util.stream.Collectors;

class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        
        String s1 = scan.nextLine();
      
      String s2=Arrays.stream(s1.split(" "))
                     .map(s->new StringBuffer(s).reverse())
                     .collect(Collectors.joining(" "));
            
            System.out.print(s2);
    }
}

class Test{
    public static void main(String args[])
    {
            int n=1234567;

            String a[]= new String[]{String.valueOf(n)};

            String f=  Arrays.stream(a)
                     .map(e-> new StringBuffer(e).reverse())
                     .collect(Collectors.joining(""));
             System.out.println(f);
    }
}
=================================*************************=======================
Reverse a number or word without using a reverse() :

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class Sample{
    public static void main(String args[])
    {
    
          Scanner scan=new Scanner(System.in);
            String s=scan.nextLine();
          List<String>list=Arrays.asList(s.split(" "));
       
       System.out.println("OriginalList:"+list);
       
       List<String> reversedList = IntStream.range(0,list.size())
                    .mapToObj(i-> list.get(list.size()-1-i))
                    .collect(Collectors.toList());
        
        System.out.println("ReversedList: "+reversedList);
    }
}

19.How do you find sum of first 10 natural numbers?

import java.util.stream.IntStream;

public class SumOfFirstTenNumbers {
    public static void main(String[] args) {
        // Generate a stream of the first 10 natural numbers (1 to 10)
        int sum = IntStream.rangeClosed(1, 10)
                           .sum();
        
        System.out.println("Sum of the first 10 natural numbers: " + sum);
    }
}

20.Print first 10 even numbers
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.stream.IntStream;

class Sample {
    public static void main(String args[]) {
        // Use IntStream to generate numbers from 0 to 9 (inclusive)
        IntStream filteredStream = IntStream.range(0, 10)
                                            .filter(i -> i % 2 == 0); // Filter even numbers
        
        // Convert IntStream to List<Integer> and collect the result
        List<Integer> result = filteredStream.boxed()
                                            .collect(Collectors.toList());
        
        // Print the result
        System.out.println("Filtered even numbers: " + result);
    }
}


(or)

import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.stream.IntStream;

class Sample {
    public static void main(String args[]) {
        // Use IntStream to generate numbers from 0 to 9 (inclusive)
        IntStream filteredStream = IntStream.range(0, 10)
                                            .filter(i -> i % 2 == 0); // Filter even numbers
        
        // Convert IntStream to List<Integer> and collect the result
                                  filteredStream.boxed()
                                            .forEach(System.out::println);
    }
}

(or)
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class Sample{
    public static void main(String args[])
    {
        
        IntStream.rangeClosed(0,10)
        .filter(i->i%2==0)
        .forEach(System.out::println);
    }
}

21.How do you find the most repeated element in an array?
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.*;

public class Java8Code {
    public static void main(String[] args) {
        List<Integer> listOfIntegers = Arrays.asList(111, 222, 333, 111, 555, 333, 777, 222);
        
        Set<Integer> uniqueElements = new HashSet<>();
        
        // Using stream to filter and collect duplicate elements
        List<Integer> duplicateElements = listOfIntegers.stream()
                                                       .filter(i -> !uniqueElements.add(i)) // If add returns false, it means the element is a duplicate
                                                       .collect(Collectors.toSet());
        
        System.out.println("Duplicate elements: " + duplicateElements);
    }
}

==================*********************=================================

22.Given a list of strings, find out those strings which start with a number?
import java.util.*;
import java.util.stream.Collectors;

class Sample {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        
        String s1 = scan.nextLine();
      
     List<String>s2=Arrays.stream(s1.split(" "))
                     .filter(str->Character.isDigit(str.charAt(0)))
                     .collect(Collectors.toList());
                     
                     
                System.out.print(s2);
          
    }
}

23.Print duplicate characters in a string?

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
 
public class Java8Code 
{
    public static void main(String[] args) 
    {
        String inputString = "Java Concept Of The Day".replaceAll("\\s+", "").toLowerCase();
         
        Set<String> uniqueChars = new HashSet<>();
         
        Set<String> duplicateChars = 
                Arrays.stream(inputString.split(""))
                        .filter(ch -> ! uniqueChars.add(ch))
                        .collect(Collectors.toSet());
         
        System.out.println(duplicateChars);
    }
}

24.Find first repeated character in a string

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class FirstRepeatedCharacter {
    public static void main(String[] args) {
        String str = "abcdefgabc";

        Set<Character> seen = new LinkedHashSet<>();
        
        // Find the first repeated character using Java Stream API
        Character firstRepeatedChar = str.chars()
                .mapToObj(c -> (char) c)
                .filter(ch -> !seen.add(ch)) // Add to set; if add returns false, it's a repeat
                .findFirst()
                .orElse(null); // If no repeated character found, return null

        if (firstRepeatedChar != null) {
            System.out.println("First repeated character: " + firstRepeatedChar);
        } else {
            System.out.println("No repeated characters found.");
        }
    }
}

25.First 10 odd numbers?
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.stream.IntStream;

class Sample {
    public static void main(String args[]) {
        // Use IntStream to generate numbers from 0 to 9 (inclusive)
         List<Integer> result = IntStream.range(0, 20)
                .filter(i -> !(i % 2 == 0))
                .boxed()
                .collect(Collectors.toList());
        
        // Print the result
        System.out.println("Filtered even numbers: " + result);
    }
}

26.Fibonacci series?
import java.util.*;
import java.util.stream.Stream;


class Sample{
    public static void main(String args[])
    {
        int n=10;
        
        Stream.iterate(new int[]{0,1},f->new int[]{f[1],f[0]+f[1]})
        .limit(n)
        .map(f->f[0])
        .forEach(System.out::println);
         
    }
}

27.Given the list of integers, find the first element of the list using Stream functions?
import java.util.*;
import java.util.stream.Collectors;

class Sample {
    public static void main(String arg[]) {
        Scanner scan = new Scanner(System.in);
        String s = scan.nextLine();
        
        // Split the input string by spaces, convert to integers, and find the first element
               Arrays.stream(s.split(" "))
              .mapToInt(Integer::parseInt) // Convert each string to an integer
              .boxed() // Convert IntStream to Stream<Integer>
              .findFirst() // Find the first element in the stream
              .ifPresent(System.out::println); // Print the first element if present
    }
}

28.Given a list of integers, find the total number of elements present in the list using Stream functions?
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;

class Sample{
    public static void main(String arg[])
    {
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        
    long count=Arrays.stream(s.split(" "))
           .mapToInt(Integer::parseInt)
           .boxed()
           .count();
           
           
      System.out.println(count);
            
    }
}

29.Given an integer array nums, return true if any value appears at least twice in the array, and return false if every element is distinct
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.*;
 
public class Java8Code 
{
    public static void main(String[] args) 
    {
       Scanner scan=new Scanner(System.in);
       String inputString=scan.nextLine();
         
        Set<String> uniqueChars = new HashSet<>();
         
        Set<String> duplicateChars = 
                Arrays.stream(inputString.split(" "))
                        .filter(ch -> ! uniqueChars.add(ch))
                        .collect(Collectors.toSet());
            //     System.out.println(uniqueChars);
        if(!duplicateChars.isEmpty())
        {
        System.out.println("TRUE");
        }
        else
        {
        System.out.println("FALSE");
        }
    }
}

30.Java 8 program to perform cube on list elements and filter numbers greater than 50
import java.util.*;
import java.util.stream.Stream;

class Sample{
    public static void main(String args[])
    {
     Scanner scan=new Scanner(System.in);
     String s1=scan.nextLine();
     
     Arrays.stream(s1.split(" "))
     .mapToInt(Integer::parseInt)
     .map(n->n*n*n)
     .filter(n->n>50)
     .forEach(System.out::println);
    }
}

31.How will you get the current date and time using Java 8 Date and Time API?
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.*;
 
public class Java8Code 
{
    public static void main(String[] args) 
    {
       System.out.println("Current Local Date: " + java.time.LocalDate.now());
        //Used LocalDate API to get the date
        System.out.println("Current Local Time: " + java.time.LocalTime.now());
        //Used LocalTime API to get the time
        System.out.println("Current Local Date and Time: " + java.time.LocalDateTime.now());
        //Used LocalDateTime API to get both date and time
        
    }
}

32.Given a String, find the first non-repeated character in it using Stream functions?
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;

class Sample{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        
            Map<Character, Long> frequencyMap = s.chars() // IntStream of char values
                .mapToObj(c -> (char) c) // Map to Character objects
                .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
				
            List<Character> n= s.chars()
                         .mapToObj(c-> (char)c)
                         .filter(i->frequencyMap.get(i)==1)
                                 .collect(Collectors.toList());
                            
            System.out.print(n);                
    }
}

==========================================================================================================

class Test{
    public static void main(String args[])
    {
        int n[]={12,19,12,20};

        String[] d=  Arrays.stream(n)
                .mapToObj(String::valueOf)
                .toArray(String[]::new);

        Map<String,Long> k= Arrays.stream(d)
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

        Set<String> Unique=   Arrays.stream(d)
                .filter(e->k.get(e)==1)
                .collect(Collectors.toSet());
        System.out.println(Unique);
    }
}

==============================================================================================
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;

class Sample{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        
            Map<Character, Long> frequencyMap = s.chars() // IntStream of char values
                .mapToObj(c -> (char) c) // Map to Character objects
                .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
                               
                 s.chars()
                .mapToObj(c -> (char) c)
                .filter(i -> frequencyMap.get(i) == 1)
                .findFirst()
                .ifPresent(System.out::println);
                            
    }
}

=================================================================================================
public List<Grocery> getAll() {
    List<Grocery> store = groceryRepository.findAll(); // Fetch all records from DB
    
    HashSet<Grocery> unique = new HashSet<>();
    List<Grocery> uniqueList = store.stream()
                                    .filter(unique::add) // Only keep first occurrence
                                    .toList();
    
    return uniqueList; // Return only unique values
}



33.Shortlist based on given letters:
import java.util.*;
import java.util.stream.Collectors;
class Sample{
public static void main(String args[])
{
List<String> fruits=Arrays.asList("Apple","Orange","Kiwi");
List<String> demo=fruits.stream()
                  .filter(bowl-> bowl.startsWith("K"))
				  .collect(Collectors.toList());

System.out.println(demo);
}
}

output:
Kiwi

Write a program starts with one?
class Sample{
    public static void main(String args[])
    {
        List<Integer> demo=Arrays.asList(1,90,65,17);

        demo.stream()
                .filter(e-> String.valueOf(e).startsWith("1"))
                .forEach(System.out::println);
    }
}

34.Given string identify the vowel character count:
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;

class Sample{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        
     long vowels= s.chars()
        .filter(c-> (c=='a' ||c=='e' ||c=='i' ||c=='o' ||c=='u'))
        .count();
        
        System.out.println(vowels);
    }
}

35.write a program first half of string uppercase and second half of string is lowercase using java8 
import java.util.*;

class Sample{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        
            int mid=s.length() /2;
            
        String demo= s.substring(0,mid).toUpperCase()+s.substring(mid).toLowerCase();
        
        System.out.println(demo);
    }
}

36.Group the words have a same length?
import java.util.*;
import java.util.stream.Collectors;

class Sample{
    public static void main(String args[])
    {
        String s="Hi welcome to you";
        
     Map<Integer, List<String>> lengthToWords =Arrays.stream(s.split(" "))
        .collect(Collectors.groupingBy(String::length));                                
       System.out.println(lengthToWords);
    }
}


Output:{2=[Hi, to], 3=[you], 7=[welcome]}

37.Prime number:
import java.util.Scanner;
import java.util.stream.IntStream;

public class PrimeNumberChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = scanner.nextInt();

        if (isPrime(number)) {
            System.out.println(number + " is a prime number.");
        } else {
            System.out.println(number + " is not a prime number.");
        }
        
        scanner.close();
    }

    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false; // 0 and 1 are not prime numbers
        }
        return IntStream.rangeClosed(2, (int) Math.sqrt(num))
                .noneMatch(i -> num % i == 0); // Check if num is divisible by any number in the range
    }
}


38. In map how to get key and value using stream api?
import java.util.Map;

public class MapStreamExample {
    public static void main(String[] args) {
        Map<Integer, String> map = Map.of(1, "Alice", 2, "Bob", 3, "Charlie");

        // Iterate through key-value pairs using stream
        map.entrySet().stream().forEach(entry -> 
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue())
        );
    }
}


39. Filter the DOB:
package Employee;

import java.time.LocalDate;

public class Employee {

    private int id;
    private String name;
    private int age;
    private LocalDate dob;

    public Employee(int id, String name, int age, LocalDate dob) {
        this.id=id;
        this.name=name;
        this.age=age;
        this.dob=dob;

    }





    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}



class Emp{
    public static void main(String args[])
    {
        List<Employee> test= new CopyOnWriteArrayList<>(Arrays.asList(
                new Employee(1,"vasanth",34, LocalDate.parse("1990-09-29")),
                new Employee(2,"Navila",1,LocalDate.parse("2023-07-05"))
        ));

     /* List<Employee> demo=  test.stream()
                .filter(e->e.getAge() > 2)
                .collect(Collectors.toList());*/

        List<Employee> demo=  test.stream()
              //  .filter(e->e.getDob().getMonthValue() > 8)
              //  .filter(e->e.getDob().getYear() > 1990)
                  .filter(e->e.getDob().getDayOfMonth() > 21)
                .collect(Collectors.toList());

      for( Employee emp : demo)
      {
          System.out.println(emp.getName()+" "+emp.getDob());
      }
    }

}


40. To find pairs that sum to a target in Java using the Stream API ?

import java.util.*;
import java.util.stream.*;

public class PairSumAlt {
    public static void main(String[] args) {
        List<Integer> input = Arrays.asList(1, 2, 3, 4);
        int target = 7;

        Set<String> seen = new HashSet<>();

            input.stream()
            .flatMap(i -> input.stream()
                .filter(j -> i < j && i + j == target)
                .map(j -> new int[]{i, j}))
            .forEach(pair -> {
                String key = pair[0] + "," + pair[1];
                if (seen.add(key)) {
                    System.out.println(Arrays.toString(pair));
                }
            });
    }
}

41.Find the max and min repeated character in map?

class duplicate
{
    public static void main(String args[])
    {
        String s = "Hello world";

        Map<Character, Long> d = s.chars()
                .mapToObj(e -> (char) e)
                .filter(e -> !e.equals(' '))
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println("Count: " + d);

        long max = Collections.max(d.values());

        long min=Collections.min(d.values());

        s.chars()
                .mapToObj(e -> (char) e)
                .filter(e -> !e.equals(' ') && d.get(e) == max)
                .distinct()
                .forEach(System.out::println);

        s.chars()
                .mapToObj(e -> (char) e)
                .filter(e -> !e.equals(' ') && d.get(e) == min)
                .distinct()
                .forEach(System.out::println);
    }

}


42. Group the based on the matched the strings?

class AnagramGroups {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("cat", "tac", "gol", "log", "ogl");

        Map<String, List<String>> grouped = words.stream()
                .collect(Collectors.groupingBy(word ->
                        word.chars()
                                .sorted()
                                .mapToObj(c -> String.valueOf((char)c))
                                .collect(Collectors.joining())
                ));

        grouped.forEach((key, group) ->
                System.out.println("Group: " + group)
        );
    }
}

43.List of Employee having empId,EmpName, empSalary, department
output : 1. max salaried employee of each department
2. Group by department count

class TestMap2
{
    public static void main(String args[]) {
        List<Employee> s = Arrays.asList(
                new Employee(1, "Sarath", 34, null),
                new Employee(2, "Sarath", 39, null),
                new Employee(3, "Vidhya", 40, null)
        );

        Map<String,Optional<Employee>> a= s.stream()
                .collect(Collectors.groupingBy(Employee::getName,Collectors.maxBy(Comparator.comparingInt(Employee::getAge))));

        for(Map.Entry<String,Optional<Employee>> d: a.entrySet()) {
            System.out.println(d.getKey() + " value" + d.getValue().get());
        }

}
}


class EmployeeOperation {
    public static void main(String[] args) {
        List<Employee1> test = Arrays.asList(
                new Employee1("Sarvesh", 30, 3000000,"Sarvesh"),
                new Employee1("Nithya", 32, 23000 ,"Ram")
        );

        test.stream()
                .filter(e-> e.getSalary() > 100000)
                .map(Employee1::getName)
                .forEach(System.out::println);

        test.stream()
                .filter(e-> e.getAge() > 30 )
                .map(e -> e.getSalary() + 10000)
                .forEach(System.out::println);

        test.stream()
                .filter(e-> e.getName() == e.getLastname() )
                .forEach(System.out::println);
    }
}

44.Copy of the one map to another map ?
class CopyHashMap {
    public static void main(String[] args) {
        HashMap<Integer, String> original = new HashMap<>();
        original.put(1, "Apple");
        original.put(2, "Banana");

        // Copying HashMap
        HashMap<Integer, String> copy = new HashMap<>(original);

        System.out.println(copy);
    }
}

45.Convert list to queue ?
class ListToQueue {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("Red", "Green", "Blue");

        // Convert List to Queue
        Queue<String> queue = new LinkedList<>(list);

        System.out.println(queue);
    }
}
=======================================**************========================
import java.util.Queue;
import java.util.LinkedList;

public class QueueExample {
    public static void main(String[] args) {
        Queue<String> queue = new LinkedList<>();

        // Adding elements
        queue.add("Arun");
        queue.add("Ajay");

        // Removing elements
        System.out.println(queue.poll()); // Outputs: Arun  //Retrieves and removes the head (returns null if empty)
        System.out.println(queue.peek()); // Outputs: Ajay  //Retrieves but does not remove the head
    }
}

46.Custom validator or Age validation?
class CustomException extends Exception{
    public CustomException(String msg){
        super(msg);
    }
}

public class AgeValidation {
    public static void validate(int age) throws CustomException{
        if(age<18){
            throw new CustomException("Age should be greater than 18");
        }else {
            System.out.println("valid voting age");
        }
    }

    public static void main(String[] args) {
        try{
            validate(17);
        }catch (CustomException exception){
            System.out.println(""+exception.getMessage());
        }
    }
}


==============================================================================================================================
1. All major intermediate operations in a single stream pipeline ?

public class IntermediateOpsDemo {
    public static void main(String[] args) {
        List<Emp> employees = Arrays.asList(
            new Emp("Alice", 60000, Arrays.asList("Java", "Spring")),
            new Emp("Bob", 45000, Arrays.asList("JavaScript", "React")),
            new Emp("Charlie", 52000, Arrays.asList("Java", "Angular")),
            new Emp("David", 48000, Arrays.asList("Python", "Django")),
            new Emp("Eve", 70000, Arrays.asList("Java", "Spring"))
        );

        List<String> result = employees.stream()
            .filter(e -> e.getSalary() > 50000)                      // Filter high earners
            .map(Emp::getSkills)                                     // Map to skill lists
            .flatMap(List::stream)                                   // Flatten skill lists
            .distinct()                                              // Remove duplicates
            .sorted()                                                // Sort alphabetically
            .peek(skill -> System.out.println("Skill: " + skill))    // Debug output
            .skip(1)                                                 // Skip first skill
            .limit(3)                                                // Limit to top 3
            .collect(Collectors.toList());                           // Terminal operation

        System.out.println("\nFinal Result: " + result);



2.Two kinds of streams in java ?

1.Stream<Integer>

2.Intstream,Longstream
 
 
 
* mapToInt(Integer::parseInt) ==> String to int

* mapToInt(Integer::intValue) ==> Stream<Integer> to int

* boxed() ==> int to Integer
 
Stream<Integer>  ---mapToInt(Integer::intValue)  --> Intstream

Intstream        ---boxed()                      --> Stream<Integer>
 
 
3.Group Employee Names by Department ?
Map<String, List<String>> namesByDept = employees.stream()
    .collect(Collectors.groupingBy(
        Emp::getDept,
        Collectors.mapping(Emp::getName, Collectors.toList())
    ));
========================***********===================================
 Grouping Words by Sorted Characters?
 input: String[] words = {"dog", "god", "cat", "tac", "act","rabbit"}; output:{[a, c, t]=[cat, tac, act], [a, b, b, i, r, t]=[rabbit], [d, g, o]=[dog, god]}
Map<String, List<String>> grouped12 = Arrays.stream(words)
                .collect(Collectors.groupingBy(word ->
                        word.chars()
                                .mapToObj(c -> String.valueOf((char) c)) // Convert char to String
                                .sorted()
                                .collect(Collectors.joining())           // Join sorted characters
                ));   (OR)
				Map<String, List<String>> grouped12 = Arrays.stream(words)
                .collect(Collectors.groupingBy(word -> {
                    return word.chars()
                            .mapToObj(c -> String.valueOf((char) c)) // Convert char to String
                            .sorted()
                            .collect(Collectors.joining());          // Join sorted characters
                }));
======================***********=============================================				
  Inside the group we can use if and else condition?
  Map<String, List<Person>> ageGroups = people.stream()
                .collect(Collectors.groupingBy(p -> {
                    int age = p.getAge();
                    if (age < 18) return "Minor";
                    else if (age < 60) return "Adult";
                    else return "Senior";
                }));
				
=====================************=============================================
Grouping the name and finding the maximum age ?
 Map<String,Optional<Employee>> a= s.stream()
                .collect(Collectors.groupingBy(Employee::getName,Collectors.maxBy(Comparator.comparingInt(Employee::getAge))));


4.Get Top 3 Salaries per Department ?

Map<String, List<Double>> topSalariesByDept = employees.stream()
            .collect(Collectors.groupingBy(
                Emp::getDept,
                Collectors.collectingAndThen(
                    Collectors.mapping(Emp::getSalary, Collectors.toList()),
                    list -> list.stream()
                                .sorted(Comparator.reverseOrder())
                                .limit(3)
                                .collect(Collectors.toList())
                )
            ));
Why You Need collectingAndThen Here
You're doing two things:
- Mapping Emp to salary
- Post-processing the list of salaries:
    - Sorting in descending order
    - Limiting to top 3
This post-processing is only possible with collectingAndThen.

🧪 What Happens If You Use Only mapping
Collectors.mapping(Emp::getSalary, Collectors.toList())


This will give you:
- A list of all salaries per department
- Unsorted, unlimited
You won’t be able to sort or limit unless you wrap it with collectingAndThen.
====================================**********======================================================
 List<Employee> s = Arrays.asList(
                new Employee(1, "Sarath", 34, null),
                new Employee(2, "Sarath", 39, null),
                new Employee(3, "Kani", 40, null)

        );

        Map<String, List<Integer>> d = s.stream().collect(Collectors.groupingBy(
                        Employee::getName,
                        Collectors.mapping(Employee::getAge, Collectors.toList())
                ));
        System.out.println(d);

        Map<String,List<Integer>> r=s.stream().collect(Collectors.groupingBy(Employee::getName,
                Collectors.collectingAndThen(Collectors.toList(), g->g.stream().map(Employee::getAge).toList())));

        System.out.println(r);

5.Two field sorting ?
After Sorting?
[
    EmpObj(1, "Bob"),
    EmpObj(1, "Charlie"),
    EmpObj(2, "Alice"),
    EmpObj(3, "David")
]

List<EmpObj> sortedList = employees.stream()
    .sorted(Comparator.comparing(EmpObj::getId)
                      .thenComparing(EmpObj::getName))
    .collect(Collectors.toList());
	
6.Reverse the string greater than length()> 3?
String r= Arrays.stream(s.split(" "))
                .map(e-> e.length() >3 ? new StringBuffer(e).reverse().toString() : e)
                .collect(Collectors.joining(" "));
				
7.Java Streams that splits a stream into two groups based on a boolean predicate ?
- filter() is great for one group.Selects elements that match a condition
- partitioningBy() is perfect when you need both sides of the condition.Splits elements into two groups: true and false.

Map<Boolean, List<Emp>> partitioned = employees.stream()
    .collect(Collectors.partitioningBy(e -> e.getSalary() > 50000));

System.out.println("Salary > 50000:");
partitioned.get(true).forEach(System.out::println);

System.out.println("\nSalary <= 50000:");
partitioned.get(false).forEach(System.out::println);
=====================**********===================================================
Gmail validation:
 boolean isValid = s.chars()
                .mapToObj(c -> (char) c)
                .allMatch(e -> Character.isLetter(e) || e.equals('@') || e.equals('.') || Character.isDigit(e));

8.Regex:

What is (?<=...)?
This is called a lookbehind assertion. It checks if something comes before the current position in the string — but it doesn't include that part in the match.
In Java, \\s means any whitespace (space, tab, newline), and \\ is needed because Java escapes backslashes.

 String input = "   arun      ajay";

        String output = Arrays.stream(input.split("(?<=\\s)"))
                .map(token -> token.isEmpty() ? token : new StringBuilder(token).reverse().toString())
                .collect(Collectors.joining());  // output :     nura     yaja
				
=====================*********====================================================================
 Gmail validation:
 String s = "usernam#e@domain";
        boolean isValid = true;
        for (char c : s.toCharArray()) {
            if (!String.valueOf(c).matches("[A-Za-z0-9@.]")) {
                isValid = false;
                break;
            }
        }
		
=====================*********==========================================================
Remove the special characters?
 String s="Hello$1",k="";

         k= s.replaceAll("[^ a-zA-Z0-9 ]","");

         System.out.println(k);
		 
====================**************=======================================================
How regex is working ?
String input = "H$1e@2l%3l-+4o5_ w67o(8r)l#d9";

        String k=input. ("[A-Za-z]", "");//output: $1@2%3-+45_67(8)#9
        String l=input.replaceAll("[^A-Za-z]", "");//output: Helloworld

        System.out.println(k);
        System.out.println(l);
		
=======================**************============================================


String input = "apple   banana orange";
String[] words = input.split("\\s+"); // This "\\s+" means: "One or more whitespace characters"




		
9.Using map() operation ?

        List<String> names = Arrays.asList("Alice", "Bob", "Charlie");

        names.stream()
                .map(String::toLowerCase)
                .forEach(System.out::println);

        names.stream()
                .map(String::toUpperCase)
                .forEach(System.out::println);

        names.stream()
                .map(String::length)
                .forEach(System.out::println);

10.Lowercase conversion & comparison with character ?
List<String> demo = Arrays.asList(
                "start","steps","signs","java");

        List<String>d=demo.stream()
                .filter(i -> i.toLowerCase().startsWith("s")
                        && i.toLowerCase().endsWith("s"))
                .collect(Collectors.toList());

        System.out.println(d);
		
11.After map how to sort?
Arrays.stream(s.split(" "))
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
                        .entrySet().stream()
                        .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                                .limit(10)
                                        .forEach(System.out::println);
										
12. Ifpresent usage ?
 List<Integer> numbers = Arrays.asList(2, 9, 15, 22, 30, 7);

        numbers.stream()
                .filter(i -> i>=10)
                .filter(e -> (e%3==0 && e%5==0))
                .findFirst()
                .ifPresentOrElse(System.out::println,()-> System.out.println("No match found"));
				
13.Remove the consecutive letter ?
String input = "JJjjjjAaaavvvVVvAAAA";

        String result  =Arrays.stream(input.split(""))
                .map(String::toUpperCase)
                .reduce("", (a,b) -> a.endsWith(b) ? a : a+b);
        
        System.out.println(result);  // output :"JAVA"
		
14.
// Online Java Compiler
// Use this editor to write, compile and run your Java code online
import java.util.*;
import java.util.stream.*;
import java.util.stream.Collectors;
class Main {
    public static void main(String[] args) {
        System.out.println("Categorise fruits");
        List<String> names = Arrays.asList("potato:Veg", "apple:fruits","mango:fruits");
        Map<String,List<String>> categorised = names.stream()
        .map(s->s.split(":"))
        .collect(Collectors.groupingBy(s->s[1],
        Collectors.mapping(s->s[0],Collectors.toList())));
 
Output :
Categorise fruits
{fruits=[apple, mango], Veg=[potato]}
        System.out.println(categorised);
    }
}


15. Display the contains character in string:

List<String> d= Arrays.asList("apple","orange","banana");

   List<String>f=  d.stream()
		 .filter(i -> i.contains("an"))
		 .sorted()
		 .collect(Collectors.toList());
		 
		 System.out.println(f);