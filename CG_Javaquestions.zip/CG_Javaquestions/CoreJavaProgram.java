1.Java Program to Reverse Words in a String:

import java.util.Arrays;

public class SortStrings {

 public static void main(String[] args) {

 String s="Hello World";
String reverse="";

String r[]=s.split(" ");

for(int i=r.length-1;i>=0;i--)
{
reverse=reverse+r[i]+" ";
}
System.out.print(reverse);

 }

 }
 
 ============================*************=========================
 import java.util.*;

class Sample{
    public static void main(String args[])
    {
        String s="Hello";
    
    StringBuilder s1=new StringBuilder();
    
    for(int i=s.length()-1;i>=0;i--)
    {
        s1=s1.append(s.charAt(i));
    }
    System.out.print(s1);
    }
}

2.Java Program to Sort Strings in Alphabetical Order:

import java.util.*;

public class SortStrings {

 public static void main(String[] args) {

Scanner scan=new Scanner(System.in);
 String h = scan.nextLine();
 
 String[] strings=h.split(" ");

 Arrays.sort(strings);

 System.out.println(“Sorted Strings:”);

 for (String s : strings) {

 System.out.println(s);

 }

 }

}

3.Java Program to Check Palindrome :
import java.util.Arrays;

public class SortStrings {

    public static void main(String[] args) {
        String s = "racecar";
        String reverse = "";

        // Split the string into words
        String[] r = s.split("");

        // Iterate from the end of the array to the beginning
        for (int i = r.length - 1; i >= 0; i--) {
            // Append each word and a space to the reverse string
            reverse = reverse + r[i];
        }

        if(reverse.equals(s))
        {
            
        System.out.println("It is a Palindrome");
    }
    else
    {
        System.out.println("It is not a Palindrome");
    }
    }
}

4.Java Program to Find Duplicate Characters in a String:

import java.util.*;
public class Duplicate {

 public static void main(String[] args) {

 String s="Hello World";

Map<Character,Integer> charMap=new HashMap<Character,Integer>();

for(Character c:s.toCharArray())
{

if(charMap.containsKey(c))
{
    charMap.put(c,charMap.get(c)+1);
}
else
{
   charMap.put(c,1); 
}
}
System.out.print(charMap);
 }
 }

5.Java Program to Convert char to String and String to Char?
public class CharStringConversion {

 public static void main(String[] args) {

 // Convert char to String

 char ch = 'A';

 String str = Character.toString(ch);

 System.out.println("Char to String: " + str);

 // Convert String to char

 String s = "Hello";

 char c = s.charAt(0);

 System.out.println("String to Char: " + c);

 }

}

6.Java Program to Find Quotient and Remainder:
import java.util.*;

public class Sample {

    public static void main(String[] args) {
        
        Scanner scan=new Scanner(System.in);
        int upper=scan.nextInt();
        int lower=scan.nextInt();
        
        int Quotient=upper/lower;
        int Remainder=upper%lower;
  System.out.println("Quotient :"+Quotient);
  System.out.print("Remainder :"+Remainder);
        
    }
}

7.Check Vowel or Consonant in Java:
import java.util.*;
public class Sample {

    public static void main(String[] args) {
        
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        char[] h=s.toCharArray();
        
        for(char c:h)
        {
        if(c=='a' ||c=='e' ||c=='i' ||c=='o' ||c=='u' ||c=='A'
        ||c=='E' ||c=='I' ||c=='O' ||c=='U' )
        {
        System.out.println("Vowel :"+c);
        }
        else
        {
        System.out.print("Consonant :"+c);        
        }
        }
}
}

8.Check Leap Year in Java:
public class LeapYear {

public static void main(String[] args) {

 int year = 2024;

 if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)) {

 System.out.println(year + ” is a leap year.”);

 } else {

 System.out.println(year + ” is not a leap year.”);

 }

 }

}

9.Print Pattern in Java:
Output:

* 

* * 

* * * 

* * * * 

* * * * *

public class PrintPattern {

 public static void main(String[] args) {

 int rows = 5;

 for (int i = 1; i <= rows; ++i) {

 for (int j = 1; j <= i; ++j) {

 System.out.print(“* “);

 }

 System.out.println();

 }

 }

}

10.Factorial of a Number:
public class Factorial {

 public static void main(String[] args) {

 int num = 5, factorial = 1;

 for(int i = 1; i <= num; ++i) {

 factorial *= i;

 }

 System.out.println(“Factorial of ” + num + ” is: ” + factorial);

 }

}

Output:

Factorial of 5 is: 120

11.Find Maximum of Three Numbers:

public class MaxOfThreeNumbers {

 public static void main(String[] args) {

 int num1 = 10, num2 = 20, num3 = 15, max;

 max = (num1 > num2) ? (num1 > num3 ? num1 : num3) : (num2 > num3 ? num2 : num3);

 System.out.println(“Maximum of ” + num1 + “, ” + num2 + “, and ” + num3 + ” is: ” + max);

 }

}

Output:

Maximum of 10, 20, and 15 is: 20

12.Java program to find occurrence of a character in a String:
public class CharacterOccurrences {

 public static void main(String[] args) {

 String str = "hello world";

 char ch = ‘o’;

 int count = 0;

 for (int i = 0; i < str.length(); i++) {

 if (str.charAt(i) == ch) {

 count++;

 }

 }

 System.out.println("Occurrences of '" + ch + "' in the string: " + count);

 }

}

Output:

Occurrences of ‘o’ in the string: 2

13.Java Program to check two strings are anagram or not:

import java.util.*;

public class Anagram {

    public static void main(String[] args) {
        
        Scanner scan=new Scanner(System.in);
        String s1=scan.nextLine();
        String s2=scan.nextLine();
        
        char[] c1=s1.toCharArray();
        char[] c2=s2.toCharArray();
        
      Arrays.sort(c1);
      Arrays.sort(c2);
      
      if(Arrays.equals(c1, c2))      
      {
          System.out.println("It is a Anagram");
      }
      else
      {
          System.out.print("It is a not Anagram");
      }
}
}

14.Java Program to remove all the white spaces from a string:
import java.util.Scanner;

public class RemoveWhitespaces {

    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter a string with white spaces:");
        String input = scanner.nextLine();

        // Remove all white spaces from the input string
        String noSpaces = input.replaceAll(" ", "");
        
        System.out.print(noSpaces);
    }
}

15.Program to find number of elements in an array:
public class ArrayLength {

 public static void main(String[] args) {

 int[] array = {1, 2, 3, 4, 5};

 int length = array.length;

 System.out.println(“Number of elements in the array: ” + length);

 }

}

Output:

Number of elements in the array: 5

16.Java Program to Calculate average of numbers using Array:
import java.util.*;

public class SortStrings {

 public static void main(String[] args) {

Scanner scan=new Scanner(System.in);
int b=scan.nextInt();
int[] a=new int[b];
int sum=0;
int d=a.length;

System.out.print("Enter the number of Array:"+b);
for (int i = 0; i < a.length; i++) {
            a[i] = scan.nextInt();

        }
     
 for(int i=0;i<a.length;i++)
 {
     sum+=a[i];
 }
 System.out.println("SUM is:"+sum);
 
  double average=(sum/d);
 System.out.println("Average is:"+average);

 }

}
17. Java Program to reverse an array
import java.util.Arrays;
import java.util.Scanner;

public class SortStrings {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Initialize the arrays
        int[] b = new int[3];
        int[] c = new int[3];

        // Read elements into array `b`
        System.out.println("Enter 3 integer values:");
        for (int i = 0; i < b.length; i++) {
            b[i] = scan.nextInt();
        }

        // Reverse the array `b` and store in array `c`
        for (int i = 0; i < b.length; i++) {
            c[i] = b[b.length - 1 - i];
        }

        // Print the reversed array `c`
        System.out.println("Reversed Array:");
        
        System.out.println(Arrays.toString(c));

        // Close the scanner
        scan.close();
    }
}

18.Java Program to sort an array in ascending order:

import java.util.*;

public class SortStrings {

 public static void main(String[] args) {

Scanner scan=new Scanner(System.in);

int b[]=new int[3];

for(int i=0;i<b.length;i++)
{
    b[i]=scan.nextInt();
}

Arrays.sort(b);

System.out.println(Arrays.toString(b));
}
}

19.Java Program to convert char Array to String:

public class CharArrayToString {

 public static void main(String[] args) {

 char[] charArray = {‘h’, ‘e’, ‘l’, ‘l’, ‘o’};

 String str = new String(charArray);

 System.out.println(“Converted String: ” + str);

 }

}

Output:

Converted String: hello

20.Fibonacci Series:
import java.util.*;

public class PositiveNegative {

public static void main(String[] args) {
        
  int  n1=0,n2=1,n3;
 
 for(int i=1;i<=5;i++)
 {
 n3=n1+n2;
 n1=n2;
 n2=n3;
 System.out.println(n3);
}
 }
}

output:
1
2
3
5
8

21.Iterate the elements using hashmap:
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        HashMap<String, Integer> map = new HashMap<>();
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }
    }
}
============================*************==================================
import java.util.*;

public class Main {
  public static void main(String[] args) {
    HashMap<String, String> capitalCities = new HashMap<String, String>();
    capitalCities.put("England", "London");
    capitalCities.put("Germany", "Berlin");
    capitalCities.put("Norway", "Oslo");
    capitalCities.put("USA", "Washington DC");
    
    
    for(Map.Entry<String,String> demo:capitalCities.entrySet())
    {
    System.out.println("Key:"+demo.getKey()+"   Value:"+demo.getValue());
    }
  }
}


22.Iterate the elements using ArrayList:
import java.util.ArrayList;

public class ArrayListIteration {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");

        // Using for-each loop
        for (String item : list) {
            System.out.println(item);
        }
		
		(or)
		
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i));
		}
    }
}


23.Find Second largest element in an array
import java.util.*;

class Sample{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        int a[]=new int[2];
        
        for(int i=0;i<a.length;i++)
        {
            a[i]=scan.nextInt();
        }
        
        System.out.println("Before sorting:"+Arrays.toString(a));
        Arrays.sort(a);
        System.out.println("After sorting:"+ (a[a.length -2]));
        
    }
}

24.Bubble sort:

public class BubbleSortExample {  
    static void bubbleSort(int[] arr) {  
        int n = arr.length;  
        int temp = 0;  
         for(int i=0; i < n; i++){  
                 for(int j=1; j < (n-i); j++){  
                          if(arr[j-1] > arr[j]){  
                                 //swap elements  
                                 temp = arr[j-1];  
                                 arr[j-1] = arr[j];  
                                 arr[j] = temp;  
                         }  
                          
                 }  
         }  
  
    }  
    public static void main(String[] args) {  
                int arr[] ={3,60,35,2,45,320,5};  
                 
                System.out.println("Array Before Bubble Sort");  
                for(int i=0; i < arr.length; i++){  
                        System.out.print(arr[i] + " ");  
                }  
                System.out.println();  
                  
                bubbleSort(arr);//sorting array elements using bubble sort  
                 
                System.out.println("Array After Bubble Sort");  
                for(int i=0; i < arr.length; i++){  
                        System.out.print(arr[i] + " ");  
                }  
   
        }  
}  

25.Prime number:
import java.util.*;
class HelloWorld {
    public static void main(String[] args) {
       
       int i,n=3;
       
       if(n==0 || n==1)
       {
           System.out.print("It is not a prime number");
       }
       else
       {
           for(i=2;i <= Math.sqrt(n);i++)
           {
               if(n%i==0)
               {
                   System.out.print("It is not a prime number");
               }
           }
           System.out.print(n+" :is a prime number");       
	   }
    }
}

29.matrix multiplication:
public class MatrixMultiplicationExample{  
public static void main(String args[]){  
//creating two matrices    
int a[][]={{1,1,1},{2,2,2},{3,3,3}};    
int b[][]={{1,1,1},{2,2,2},{3,3,3}};    
    
//creating another matrix to store the multiplication of two matrices    
int c[][]=new int[3][3];  //3 rows and 3 columns  
    
//multiplying and printing multiplication of 2 matrices    
for(int i=0;i<3;i++){    
for(int j=0;j<3;j++){    
c[i][j]=0;      
for(int k=0;k<3;k++)      
{      
c[i][j]+=a[i][k]*b[k][j];      
}//end of k loop  
System.out.print(c[i][j]+" ");  //printing matrix element  
}//end of j loop  
System.out.println();//new line    
}    
}}  

30.matrix Addition:
import java.util.*;

class Sample{
public static void main(String args[])
{

Scanner s=new Scanner(System.in);
int a_row, a_col, b_row, b_col;
System.out.println("Enter Matrix A row size:");
a_row = s.nextInt();
System.out.println("Enter Matrix A col size:");
a_col = s.nextInt();
System.out.println("Enter Matrix B row size:");
b_row = s.nextInt();
System.out.println("Enter Matrix B col size:");
b_col = s.nextInt();

if (a_col != b_row) 
{
    System.out.print("Cannot be multiplied");
	return;
}

int a[][]=new int[a_row][a_col];
int b[][]=new int[b_row][b_col];
int c[][]=new int[a_row][b_col];



for(int i=0;i<a_row;i++)
{
    for(int j=0;j<a_col;j++)
    {
    
    System.out.println("a["+i+"]["+j+"]");
    a[i][j]=s.nextInt();
   }
}
for(int i=0;i<b_row;i++)
{
    for(int j=0;j<b_col;j++)
    {
    System.out.println("b["+i+"]["+j+"]");
    b[i][j]=s.nextInt();
   }
}

for(int i=0;i<a_row;i++)
{
for(int j=0;j<b_col;j++)
{
    c[i][j]=0;
for(int k=0;k<a_col;k++)
{
c[i][j]+=a[i][k]*b[k][j];
}
System.out.print(c[i][j]+" ");

}
System.out.println(" ");
}
}
}

31.swap the 2 numbers without using the third variable:
import java.util.*;
class HelloWorld {
    public static void main(String[] args) {
    Scanner s=new Scanner(System.in);
    int a=s.nextInt();
    int b=s.nextInt();
    a=a+b; 
    b=a-b; 
    a=a-b; 
    
 System.out.println("a: "+a);
  System.out.println("b: "+b);

    }
}

32.Stack:
import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        // Create a new stack
        Stack<Integer> stack = new Stack<>();

        // Push elements onto the stack
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        // Pop elements from the stack
        while(!stack.isEmpty()) {
            System.out.println(stack.pop());
        }
    }
}


=====================**********************-====================================
import java.util.Stack;
 class MyStack{
     int MAX = 5;
     int top = -1;
     int db[] = new int[MAX];
     boolean isEmpty () {
         if (top == -1)
         return true;
         else
         return false;
     }
     boolean isFull () {
         if(top == MAX -1)
         return true;
         else
         return false;
     }
    void push (int data) {
        if (isFull())
           return; 
        
        top++;
        db[top] = data;
    }
    int pop () {
        int data;
        if (isEmpty())
            return 0;
        data = db[top];
        top--;
        return data;
    }
}
public class StackExample1 {
    public static void main(String[] args) {


     MyStack my_stack =new MyStack();
     my_stack.push(1);
     my_stack.push(2);
     my_stack.push(3);
     my_stack.push(4);
     my_stack.push(5);
     my_stack.push(6);

        // Pop elements from the stack
        while(!my_stack.isEmpty()) {
            System.out.println(my_stack.pop());
        }
        // Push elements onto the stack
    }
}



33.Queue:
import java.util.*;

class GfG {

    public static void main(String args[])
    {
        // Creating empty priority queue
        Queue<Integer> pQueue
            = new PriorityQueue<>();

        // Adding items to the pQueue
        // using add()
        pQueue.add(10);
        pQueue.add(20);  
        pQueue.add(15);
		
        // Priority Queue store the value of ascending order
        // Printing the top element of
        // the PriorityQueue
        System.out.println(pQueue.peek()); 

        // Printing the top element and removing it
        // from the PriorityQueue container
        System.out.println(pQueue.poll());

        // Printing the top element again
        System.out.println(pQueue.peek());
    }
}

34.find the vowels position index?
import java.util.*;

class Main{
public static void main(String args[])
{
String s="English is a popular language";

int i;

for(i=0;i<s.length();i++)
{
if(s.charAt(i)=='a' || s.charAt(i)=='e' || s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u')
{
System.out.println(s.charAt(i) + " : "+i);
}
}
}
}