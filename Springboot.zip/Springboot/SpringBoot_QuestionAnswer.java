SPRINGBOOT :
Spring Boot makes it easy to create stand-alone, production-grade Spring based application that you can “Just Run”.

The main difference between Spring Boot and Spring Framework ?
Spring Boot is an opinionated framework that provides a streamlined way of developing Spring-based applications, while 
Spring Framework is a more traditional, modular framework that requires more configuration and setup.

Spring Framework is a broad and comprehensive framework with a lot of flexibility and customization, but it requires significant configuration.
Spring Boot is built on top of the Spring Framework, designed to simplify setup and development by reducing boilerplate configuration and providing a quick way to start Spring-based projects.


Spring is a comprehensive framework that provides features for building enterprise applications.
Spring Boot is an extension of Spring that simplifies the process by providing auto-configuration and embedded servers.

Spring over Spring boot?
Spring Framework:
- It is a comprehensive framework for building Java applications.
- Provides flexibility and control over configurations.
- Requires manual setup, dependency management, and XML/Java-based configurations.
- Suitable for large-scale enterprise applications where customization is needed.
Spring Boot:
- A simplified version of Spring that automates configurations.
- Provides embedded servers (Tomcat, Jetty) to avoid manual setup.
- Uses opinionated defaults to speed up development.
- Eliminates the need for extensive XML configurations.
- Suitable for microservices and rapid application development.
When to Use Spring vs Spring Boot?
- Use Spring when you need full control and customization over configurations.
- Use Spring Boot when you want fast development with minimal setup.



Spring Boot Layers:
Presentation Layer – Authentication & Json Translation(HTTP Request)==>(The presentation layer handles the HTTP requests, translates the JSON parameter to object, and authenticates the request and transfer it to the business layer.)
Business Layer – Business Logic, Validation & Authorization.
Persistence Layer – database Storage Logic(converting business objects to the database row and vice-versa)
Database Layer – Actual Database==>CRUD (create, retrieve, update, delete) operations are performed.

Features of Spring Boot?  or Key component of Spring Boot?
Auto-configuration – Spring Boot automatically configures dependencies by using @EnableAutoconfiguration annotation and reduces boilerplate code.
//Spring Boot Starter POM – These Starter POMs are pre-configured dependencies for functions like database, security, maven configuration etc.
Spring Boot CLI (Command Line Interface) – This command line tool is generally for managing dependencies, creating projects and running the applications.
Actuator – Spring Boot provides an actuator dependency that can be used to monitor and manage your Spring Boot application.
Embedded Servers – Spring Boot contains embedded servers like Tomcat and Jetty for quick application run. No need of external servers.

Advantages of Spring Boot?
Easy to use
Rapid Development (Spring Boot’s opinionated approach)
Scalable (simply scaled up or down to match your application’s needs)
Production-ready (Metrics, health checks, and externalized configuration are just a few of the features that Spring Boot includes and are designed for use in production environments.)
Microservices support and Easy integration.

Difference between Spring and Spring Boot?
Feature	                            Spring	        Spring Boot
Ease of use	                      More complex	      Easier
Production readiness	    Less production-ready	More production-ready
Scalability	                      Less scalable	    More scalable
Speed	                             Slower	          Faster
Customization	             Less Customizable	    More Customizable

Main steps involved in how Spring Boot works?
Start by creating a new Spring Boot project.
Add the necessary dependencies to your project.
Annotate the application with the appropriate annotations.
Run the application

Spring Boot Starter Dependencies?
Data JPA starter
Web starter
Security starter
Test Starter
Thymeleaf starter

How does a spring application get started?
A Spring application gets started by calling the main() method with @SpringBootApplication annotation in the SpringApplication class. This method takes a SpringApplicationBuilder object as a parameter, which is used to configure the application.

Once the SpringApplication object is created, the run() method is called.
Once the application context is initialized, the run() method starts the application’s embedded web server.

import org.springframework.boot.SpringApplication; 
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class MyApplication 
{ 
  public static void main(String[] args) {
    SpringApplication.run(MyApplication.class, args);
  }
}

@SpringBootApplication annotation?
@AutoConfiguration: This annotation automatically configuring beans in the class path and automatically scans the dependencies according to the application need.
@ComponentScan:  tells Spring to look for beans in the (com.example.myapp) package and its sub-packages. The @Service annotated MyService method will be picked up automatically.
@Configuration: This annotation explicitly configures the beans and packages in the class path.
@RestController: This annotation is used to define a RESTful web service controller. It is a specialized version of the 
                 @Controller annotation that includes the @ResponseBody annotation by default.
@RequestMapping: This annotation is used to map HTTP requests to a specific method in a controller. It can be applied at the class level to define a base URL for all methods in the class, or at the method level to specify a specific URL mapping.

@SpringBootApplication = @Configuration + @EnableAutoConfiguration + @ComponentScan

Spring Initializer?
Spring Initializer is a website or web-based tool used to set up Spring Boot projects in an easier and efficient manner.

Spring Boot CLI and the most used CLI commands?
-run
-test
-jar
-war
–init
-help

DisAdvantages of spring boot?
Lack of control==>Spring Boot creates many unused dependencies that result in large deployment file size.
Not suitable for large-scale projects.

How to call one service to another service in spring boot?
To use the Spring RestTemplate class.

Procedure:
Step 1: Creating Spring Boot project.
Step 2: Create Rest Controllers and map API requests.
Step 3: Build and run the Project.
Step 4: Make a call to external API services and test it.


What is use of @qualifier in spring boot?
The @Qualifier annotation in Spring is used to differentiate a bean among the same type of bean objects

Spring Boot - Thymeleaf?
Thymeleaf is a Java-based library used to create a web application. It provides a good support for serving a XHTML/HTML5 in web applications

springboot dependency injection?
Spring container “injects” objects into other objects or “dependencies”.(EX:@autowired)

Exception Handler?
The @ExceptionHandler is an annotation used to handle the specific exceptions and sending the custom responses to the client.

Interceptor in Spring Boot?
you can use an interceptor to add the request header before sending the request to the controller.
add the response header before sending the response to the client.
Interceptors can be used for logging, security, or manipulating request/response data globally.

Spring Boot JPA? (Java Persistence API)
It allows us to access and persist data between Java object/ class and relational database.
Spring Data JPA handles most of the complexity of JDBC-based database access.

Spring Boot Starters?
Spring Boot provides a number of starters that allow us to add jars in the classpath.
Spring Boot built-in starters make development easier and rapid. 
Spring Boot Starters are the dependency descriptors.

Bean life cycle?
Bean life cycle is managed by the spring container.
When we run the program then, first of all, the spring container gets started.
After that, the container creates the instance of a bean as per the request, and then dependencies are injected.
And finally, the bean is destroyed when the spring container is closed.


Exception Handling in Spring Boot
Using @ExceptionHandler annotation for method level exception handling
Using @ControllerAdvice for global exception handling

spring profile?
It is used for application.properties file.
<context-param>
        <param-name>contextConfigLocation</param-name>
        <param-value>/WEB-INF/app-config.xml</param-value>
    </context-param>
    <context-param>
        <param-name>spring.profiles.active</param-name>
        <param-value>dev</param-value>
    </context-param>
	
request param and path param?
@RequestParam is used to extract query parameters while @PathVariable is used to extract data right from the URI.

What is an embedded container in Spring Boot, and why is it important?
Spring Boot includes an embedded container, which is a lightweight server that can run inside a Spring Boot application. It eliminates the need for developers to deploy their applications on external containers like Tomcat or Jetty, making it easier to develop and deploy applications. The embedded container also supports hot reloading, which allows developers to make changes to their code and see the results immediately, without having to restart the application.

How does Spring Boot handle database connections?
Spring Boot provides a set of auto-configuration modules that make it easy to connect to databases. By default, it supports several popular databases like MySQL, PostgreSQL, and MongoDB. 
Developers can specify the database they want to use in the application.properties or application.yml file, and 
Spring Boot will automatically configure the database connection

How can you externalize the configuration properties in Spring Boot?
In Spring Boot, we can externalize the configuration properties by using the application.properties or application.yml file. These files are located in the src/main/resources directory of the Spring Boot application. By using these files, we can configure various properties such as database settings, server settings, and other application-specific properties. We can also use the @Value annotation to inject configuration properties into a Spring bean.

What is the difference between the @Component, @Service, and @Repository annotations in Spring Boot?
The @Component, @Service, and @Repository annotations are used to denote different types of beans in a Spring Boot application. The main differences between them are as follows: 

@Component: This is a generic annotation that is used to denote any Spring-managed component. It is used as a base annotation for all other annotations.
@Service: This annotation is used to denote a business service in a Spring Boot application. It is used to encapsulate the business logic of an application.
@Repository: This annotation is used to denote a data access object in a Spring Boot application. It is used to provide data access services to the application.
                                    (OR)
@Component is the most generic and can be used for any class.
@Service is used for business logic and the service layer.
@Repository is used for classes that interact with a database, providing extra database-related features like exception translation.


### Quick Summary:
- `@Component` → Generic, used for anything.
- `@Service` → Used for business logic.
- `@Repository` → Used for database-related operations.

Spring Boot and Spring MVC?
Spring Boot is an opinionated framework that is built on top of the Spring Framework, which is a modular framework for building enterprise applications in Java. Spring Boot provides an out-of-the-box configuration for Spring applications and minimizes the effort required to set up and run a Spring application. Spring MVC, on the other hand, is a module within the Spring Framework that is used for building web applications. It provides a model-view-controller architecture for developing web applications and is used for building RESTful web services.

What are the different types of Bean scopes in Spring Boot?
In Spring Boot, there are different types of Bean scopes available. These are:
Singleton: This is the default scope in Spring Boot. A singleton bean is created only once in the container, and the same instance is returned every time the bean is requested.
Prototype: This scope creates a new instance of the bean every time it is requested.
Request: This scope creates a new instance of the bean for every HTTP request.
Session: This scope creates a new instance of the bean for every HTTP session.
Global Session: This scope creates a new instance of the bean for every global HTTP session.

What is Spring Data, and how does it work with Spring Boot?
Spring Data is a tool that helps you work with databases easily without writing a lot of code.
It provides ready-made methods to save, update, delete, and find data.

When combined with **Spring Boot**, it becomes even simpler:
- Spring Boot automatically sets up everything for you, like connecting to your database.
- You just create interfaces (called repositories), and Spring Data handles common tasks like saving or finding data.
- You can also add custom queries using simple annotations.


For a relational database like MySQL:
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>

For MongoDB (NoSQL):
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-mongodb</artifactId>
</dependency>

How does Spring Boot simplify development?
Spring Boot simplifies development by,
Providing pre-configured templates
Reducing boilerplate code
Auto-configuring the application based on the dependencies
Including an embedded server
All these things make it easier to run applications.

What is Spring Boot’s role in Microservices?
Simply put, Spring Boot makes it easier to create microservices. 
It helps developers quickly build small, independent services that can run on their own. 
It provides all the tools needed, like an embedded server, easy setup, and features for connecting and communicating between services. 
In short, Spring Boot simplifies the entire process, so you can focus on building and deploying microservices without worrying about too much configuration.

difference between @inject and @autowired?
@Inject is more universally supported by different DI frameworks (Spring, Guice, CDI, etc.), 
whereas @Autowired is specifically for Spring.
===========================***********==========================================================================
explanation of Spring MVC with sample program:
Spring MVC (Model-View-Controller) program in Java. Spring MVC is a framework for building web applications in Java.
1. Controller receives the requests and handles overall control of the request
2. Model holds majority of the Business logic, and
3. View comprise of the view objects and GUI component

IoC Container:
The IoC container is responsible to instantiate, configure and assemble the objects. 
The IoC container gets informations from the XML file and works accordingly. 
The main tasks performed by IoC container are:
to instantiate the application class
to configure the object
to assemble the dependencies between the objects
There are two types of IoC containers. They are:

BeanFactory
ApplicationContext

SpringBoot CRUD opreation:
1.Books.java
2.Controller.java
3.service .java
4.Repositary.java
5.CRUD repositary.java
6.Application.java(main method)

or
entity
repository
service
controller

how to stop springboot from auto configure something?
you can use the exclude attribute of @SpringBootApplication to disable them.
@SpringBootApplication( exclude = { MyConfigurationClass. class, … }) or EnableAutoConfiguration( exclude = { MyConfigurationClass. class, … })


OAuth?
OAuth is like Netflix allowing you to log in via your Google account, but Netflix doesn’t store your Google password. It simply uses the access token from Google to authenticate and authorize you.
You can have multiple users using different OAuth providers (like Google, Facebook) to log in to Netflix, and each will have their own tokens and access.

JWT(Json Web Token)?
JWT is like when you log into your Gmail. After you enter your password, you don’t need to keep typing it in. Instead, your email client stores a token (or session ID) to prove you're authenticated and allow you to access your email. As long as the token is valid (not expired), you can access your account.

Difference between OAuth and JWT?
OAuth:
Authorization mechanism. It gives an access token to a third-party service (like Netflix) after the user authenticates with an identity provider (Google, Facebook).
OAuth allows the delegation of permissions. For example, Google might grant Netflix permission to access your basic profile info.
OAuth is used for authorization of third-party applications to access user data.

JWT:
Authentication mechanism. It provides a token that is used to verify a user's identity (e.g., logging into your email or website).
Once authenticated, JWT allows the server to recognize the user and grant access without requiring them to log in every time.
JWT tokens are self-contained, containing information (claims) about the user and the permissions they have (e.g., roles).


Springboot object creation?
@Component, @Service, @Repository: Used to mark classes as beans for automatic detection and management by Spring.
@Autowired: Used to inject dependencies.
@Configuration and @Bean: Used to manually configure beans.
@SpringBootApplication: The entry point to your application, which enables component scanning.

Difference between @RESTcontroller and @controller:
@RestController is used for building REST APIs, where the response is typically in JSON or XML.
@Controller is used for traditional web applications that return views (like HTML pages).

Spring ORM ?
**Spring ORM** provides a set of tools to integrate Object-Relational Mapping (ORM) frameworks like 
Hibernate, JPA, and JDO with Spring, making it easier to manage database transactions and perform data operations within Spring applications.


What is the use of @SpringBootApplication annotation?
The @SpringBootApplication annotation is a convenience annotation that combines @Configuration, @EnableAutoConfiguration, and @ComponentScan. It marks the main class of a Spring Boot application

What is Dependency Injection in Spring Boot?
Dependency Injection is a design pattern used to implement IoC (Inversion of Control). It allows the creation of dependent objects outside of a class and provides those objects to a class in various ways (constructor, setter method, or field injection).

CommandLineRunner and RowSet Interface: 
CommandLineRunner: It is a Spring Boot interface that runs some code at the start of the application (useful for initialization tasks or startup logic).
RowSet Interface: It’s a more flexible interface for working with database result sets, allowing features like scrolling, updating, and being disconnected from the database.


Summary of @Autowired Flow:
Spring scans for annotated beans (like @Component).
When creating beans, Spring checks for dependencies (marked with @Autowired).
Spring resolves the dependencies, either by constructor, setter, or field injection.
Beans are injected with their dependencies and initialized.
Key Points:
Constructor Injection is preferred as it makes dependencies explicit and is easier to test.
Field Injection can be convenient but makes dependencies less visible and harder to test.
@Autowired(required = false) allows optional dependencies.
@Qualifier is used to resolve ambiguity when there are multiple beans of the same type.

Refer this link for more:
https://www.hirist.tech/blog/top-40-spring-boot-interview-questions/#Spring_Boot_Interview_Questions_for_5_Years_Experienced_Candidates