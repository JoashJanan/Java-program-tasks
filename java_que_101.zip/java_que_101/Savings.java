package java_que_101;

public class Savings extends Account{

	String accountHolder = "";

    public void setAccountHolder(String accountHolder) {
        this.accountHolder = accountHolder;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    @Override
    public Savings manage(String accountHolder) {
        setAccountHolder(accountHolder);
        return this;
    }

}
