package java_que_101;

import java.util.Scanner;

public class Sloution {
	private static final Scanner INPUT_READER = new Scanner(System.in);
    private static final AccountFactory ACCOUNT_FACTORY = AccountFactory.getFactory();

    static {
        ((AccountFactory) ACCOUNT_FACTORY).registerAccount("Savings", new Savings());
        ((AccountFactory) ACCOUNT_FACTORY).registerAccount("Current", new Current());
        ((AccountFactory) ACCOUNT_FACTORY).registerAccount("FixedDeposit", new FixedDeposit());
        ((AccountFactory) ACCOUNT_FACTORY).registerAccount("Loan", new Loan());
    }

    public static void main(String[] args) {
        // Hardcoded input for testing
        String[] inputs = {
            "Savings JohnDoe",
            "Current JaneSmith",
            "FixedDeposit AliceBrown",
            "Loan BobWhite",
            "Crypto ChrisBlack" // This will throw an exception
        };

        int totalNumberOfRequests = inputs.length;

        for (int i = 0; i < totalNumberOfRequests; i++) {
            String[] input = inputs[i].split(" ");
            String accountType = input[0];
            String accountHolderName = input[1];

            try {
                if (ACCOUNT_FACTORY.equals(AccountFactory.getFactory())) {
                    Account managedAccount = ACCOUNT_FACTORY.manageAccount(accountType, accountHolderName);

                    switch (accountType) {
                        case "Savings":
                            Savings savingsAccount = (Savings) managedAccount;
                            System.out.println("Managing account for " + savingsAccount.getAccountHolder() + "(Savings)");
                            break;
                        case "Current":
                            Current currentAccount = (Current) managedAccount;
                            System.out.println("Managing account for " + currentAccount.getAccountHolder() + "(Current)");
                            break;
                        case "FixedDeposit":
                            FixedDeposit fixedDepositAccount = (FixedDeposit) managedAccount;
                            System.out.println("Managing account for " + fixedDepositAccount.getAccountHolder() + "(FixedDeposit)");
                            break;
                        case "Loan":
                            Loan loanAccount = (Loan) managedAccount;
                            System.out.println("Managing account for " + loanAccount.getAccountHolder() + "(Loan)");
                            break;
                        default:
                            break;
                    }
                }
            } catch (UnmanageableAccountRequestException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }


}
