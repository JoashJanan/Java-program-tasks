package java_que_101;

import java.util.HashMap;
import java.util.Map;

public class AccountFactory {
    private AccountFactory() {}

    private static AccountFactory instance = null;

    public static AccountFactory getFactory() {
        if(instance == null)
            instance = new AccountFactory();
        return instance;
    }

    Map<String, Account> accountMap = new HashMap<>();

    public void registerAccount(String key, Account account) {
        accountMap.put(key, account);
    }

    public Account manageAccount(String key, String accountHolderName) throws UnmanageableAccountRequestException {
        if(accountMap.containsKey(key)) {
            Account account = accountMap.get(key);
            return account.manage(accountHolderName);
        } else {
            throw new UnmanageableAccountRequestException("Unmanageable account " + key + " for holder " + accountHolderName);
        }
    }

}
