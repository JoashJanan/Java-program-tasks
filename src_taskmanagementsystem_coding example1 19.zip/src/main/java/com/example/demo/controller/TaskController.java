package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Task;
import com.example.demo.repository.TaskRepository;

@RestController
@RequestMapping("/v1/tasks")
public class TaskController {
	private TaskRepository taskRepository;
	
	TaskController(TaskRepository taskRepository) {
		this.taskRepository = taskRepository;
	}
	
	@PostMapping
	public ResponseEntity<Task> createTask(@RequestBody Task task) {
		Task saved = taskRepository.save(task);
		return ResponseEntity.status(HttpStatus.CREATED).body(saved);
	}
	
	@GetMapping
	public ResponseEntity<List<Task>> getAllTasks() {
		List<Task> tasks = taskRepository.findAll();
		tasks.sort((t1, t2) -> Long.compare(t1.getId(), t2.getId()));
		return ResponseEntity.status(HttpStatus.OK).body(tasks);
	}
	
	@GetMapping("/{taskId}")
	public ResponseEntity<Task> getTaskById(@PathVariable Long taskId) {
		return taskRepository.findById(taskId).map(ResponseEntity::ok)
				.orElse(ResponseEntity.notFound().build());
	}
	
	@DeleteMapping("/{taskId}")
		public ResponseEntity<Task> deleteTask(@PathVariable Long taskId) {
			if (taskRepository.existsById(taskId)) {
				taskRepository.deleteById(taskId);
				return ResponseEntity.noContent().build();
			} else {
				return ResponseEntity.notFound().build();
			}
		}
	}
@RestController
@RequestMapping("/v2/tasks")
class TaskController2{
	private TaskRepository taskRepository;
	public  TaskController2(TaskRepository taskRepository){
		this.taskRepository=taskRepository;
	}
	@PostMapping
	public ResponseEntity<Task>  createTask2(@RequestBody Task task2){
		Task save=taskRepository.save(task2);
		return ResponseEntity.status(HttpStatus.CREATED).body(save);
	}
	@GetMapping
		public ResponseEntity<List<Task>> getAllTasks() {
		List<Task> tasks = taskRepository.findAll();
		tasks.sort((t1, t2) -> Long.compare(t1.getId(), t2.getId()));
		return ResponseEntity.status(HttpStatus.OK).body(tasks);
	}
	@GetMapping("{taskid}")
	public ResponseEntity<Optional<Task>> getTaskById(@PathVariable Long taskid){
		if(taskRepository.existsById(taskid)) {
			Optional<Task> task = taskRepository.findById(taskid);
			return ResponseEntity.status(HttpStatus.OK).body(task);
		}
		else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}
	@DeleteMapping("{taskid}")
	public ResponseEntity<Task> deeletTaskById(@PathVariable Long taskid){
		if (taskRepository.existsById(taskid)) {
			taskRepository.deleteById(taskid);
			return ResponseEntity.noContent().build();
		}
		else{
			return ResponseEntity.noContent().build();
		}
	}
}