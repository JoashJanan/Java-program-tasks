package com.hardcoded.hardcoded;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HardcodedApplicationTests {

	@Test
	void contextLoads() {
	}

}
