package com.hardcoded.hardcoded;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HardcodedApplication {

	public static void main(String[] args) {
		SpringApplication.run(HardcodedApplication.class, args);
	}

}
