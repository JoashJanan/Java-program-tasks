package com.bank.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankProjectThymeLeafApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankProjectThymeLeafApplication.class, args);
	}

}
