package com.OnetoManyMapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetoManyMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetoManyMappingApplication.class, args);
	}

}
