package com.OnetoManyMapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetoManyMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
