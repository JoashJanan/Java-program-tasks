package com.product_dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductDashboardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
