package com.product_dashboard.client;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.product_dashboard.fallback.ProductClientFallback;
import com.product_dashboard.model.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "product-service", fallback = ProductClientFallback.class)

public interface ProductClient {
    @GetMapping("/basePath/v1/products")
    List<Product> getAllProducts();
}
