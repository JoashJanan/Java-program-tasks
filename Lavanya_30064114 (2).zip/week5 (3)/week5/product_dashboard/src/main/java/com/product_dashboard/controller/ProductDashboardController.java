package com.product_dashboard.controller;

import com.product_dashboard.client.ProductClient;
import com.product_dashboard.model.Product;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductDashboardController {

    private final ProductClient productClient;

    public ProductDashboardController(ProductClient productClient) {
        this.productClient = productClient;
    }

    @GetMapping("/dashboard/products")
    public List<Product> getProducts() {
        return productClient.getAllProducts();
    }
}
