package com.product_dashboard.fallback;

import com.product_dashboard.client.ProductClient;
import com.product_dashboard.model.Product;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
public class ProductClientFallback implements ProductClient {
    @Override
    public List<Product> getAllProducts() {
        Product fallbackProduct = new Product(0, "Fallback Product", 0.0, 0, "Default product due to service unavailability");
        return Collections.singletonList(fallbackProduct);
    }
}
