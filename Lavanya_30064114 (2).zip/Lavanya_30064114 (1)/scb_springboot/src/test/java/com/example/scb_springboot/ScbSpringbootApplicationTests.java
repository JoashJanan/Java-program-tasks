package com.example.scb_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScbSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
