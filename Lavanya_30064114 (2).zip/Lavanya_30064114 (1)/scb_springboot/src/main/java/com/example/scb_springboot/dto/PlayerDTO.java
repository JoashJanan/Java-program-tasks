package com.example.scb_springboot.dto;

import java.time.LocalDate;

public class PlayerDTO {
public String firstName;
public String lastName;
public LocalDate dateOfBirth;
public Long sportId;
}
