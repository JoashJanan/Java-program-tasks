package com.example.scb_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScbSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScbSpringbootApplication.class, args);
	}

}
