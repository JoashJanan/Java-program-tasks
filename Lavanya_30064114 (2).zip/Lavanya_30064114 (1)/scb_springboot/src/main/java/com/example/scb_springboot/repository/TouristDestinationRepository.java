package com.example.scb_springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.scb_springboot.entity.TouristDestination;

public interface TouristDestinationRepository extends JpaRepository<TouristDestination, Long> {


}
