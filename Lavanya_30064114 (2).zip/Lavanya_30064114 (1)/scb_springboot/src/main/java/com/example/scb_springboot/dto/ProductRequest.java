package com.example.scb_springboot.dto;


public class ProductRequest {
	public String name;
	public Double price;
	public Long category_id;
}
