package com.example.scb_springboot.dto;

public class SportDTO {
public String name;
public String type;
}
