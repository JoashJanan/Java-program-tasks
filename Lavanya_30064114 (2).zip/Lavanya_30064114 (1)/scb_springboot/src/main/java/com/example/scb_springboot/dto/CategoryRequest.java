package com.example.scb_springboot.dto;

public class CategoryRequest {
	public String name;
}

