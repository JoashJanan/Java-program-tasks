package com.example.controller;

import com.example.model.Customer;
import com.example.model.Order;
import com.example.service.CustomerServiceImpl;
import com.example.service.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderServiceImpl orderService;


    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Order>> getAllOrdersByCustomer(@PathVariable Long customerId) {

        return new ResponseEntity<List<Order>>(orderService.getAllOrdersByCustomerId(customerId), HttpStatus.OK);
    }

    @GetMapping("/total/{customerId}")
    public ResponseEntity<?> getTotalSumOfAllOrders(@PathVariable Long customerId) {

        return new ResponseEntity<Double>(orderService.getAllOrdersPlacedByCustomer(customerId), HttpStatus.OK);
    }
}
