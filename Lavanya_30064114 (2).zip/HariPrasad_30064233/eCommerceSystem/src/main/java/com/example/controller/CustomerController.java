package com.example.controller;

import com.example.model.Customer;
import com.example.service.CustomerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerServiceImpl customerService;


    @GetMapping("/{thresholdValue}")
    public ResponseEntity<List<Customer>> getCustomersPlacedOrdesAboveThresholdValue(@PathVariable Integer thresholdValue) {

        return new ResponseEntity<>(customerService.getCustomersPlacedOrdesAboveThresholdValue(thresholdValue), HttpStatus.OK);
    }

    @GetMapping("/partition-by-order-value/{threshold}")
    public ResponseEntity<?> getPartitioningByOrderValue(@PathVariable Integer threshold) {

        return new ResponseEntity<>(customerService.partitionCustomersBasedOnOrderValues(threshold), HttpStatus.OK);
    }

    @GetMapping("/above-order-value/{value}")
    public ResponseEntity<?> getAboveThresholdStockProducts(@PathVariable Integer value) {

        return new ResponseEntity<>(customerService.getCustomersPlacedOrdesAboveThresholdValue(value), HttpStatus.OK);
    }
}
