package com.example.service;

import com.example.model.Customer;
import com.example.model.Order;
import com.example.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl {

    @Autowired
    private OrderRepository orderRepository;


    public List<Order> getAllOrdersByCustomerId(Long customerId) {
        List<Order> orderList = orderRepository.findAll();
        if(!CollectionUtils.isEmpty(orderList)) {

            return orderList.stream().filter(order -> order.getCustomer().getId()==customerId).collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    public Double getAllOrdersPlacedByCustomer(Long customerId) {
        List<Order> orderList = orderRepository.findAll();

        return orderList.stream().filter(order -> order.getCustomer().getId() == customerId).map(Order::getTotalAmount).mapToDouble(Double::doubleValue).sum();
    }


}
