package com.example.controller;

import com.example.model.Product;
import com.example.service.ProductServiceImpl;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductServiceImpl productService;

    @GetMapping("/category/{category}")
    public ResponseEntity<List<Product>> getAllProductsByCategory(@PathVariable String category) {

        return new ResponseEntity<List<Product>>(productService.getAllProductsByCategory(category), HttpStatus.OK);
    }

    @GetMapping("/price/above/{threshold}")
    public ResponseEntity<?> getProductsPriceGreaterThanThresholdValue(@PathVariable Double threshold) {

        return new ResponseEntity<>(productService.getProductsWithThresholdValue(threshold), HttpStatus.OK);
    }

    @GetMapping("/top/{n}")
    public ResponseEntity<?> getTopMostExpensiveProducts(@PathVariable Integer n) {

        return new ResponseEntity<List<Product>>(productService.getTopMostExpensiveProducts(n), HttpStatus.OK);
    }

    @GetMapping("low-stock/{threshold}")
    public ResponseEntity<?> getLowStockThresholdValue(@PathVariable Integer threshold) {

        return new ResponseEntity<List<Product>>(productService.getLowStockProducts(threshold), HttpStatus.OK);
    }

    @GetMapping("/group-by-category")
    public ResponseEntity<?> getProductsByCategory() {

        return new ResponseEntity<Map<String, List<Product>>>(productService.getProductsByCategory(), HttpStatus.OK);
    }

    @GetMapping("/total-price")
    public ResponseEntity<?> getTotalPrice() {

        return new ResponseEntity<Double>(productService.getTotalPriceOfAllProducts(), HttpStatus.OK);
    }

    @GetMapping("/names")
    public ResponseEntity<?> getProductNames() {

        return new ResponseEntity<String>(productService.getProductNames(), HttpStatus.OK);
    }

    @GetMapping("/average-price-by-category")
    public ResponseEntity<?> getAvgPriceByCategory() {

        return new ResponseEntity<Map<String, Long>>(productService.averagePriceByCategory(), HttpStatus.OK);
    }

    @GetMapping("/top/{n}")
    public ResponseEntity<?> getTopNMostExpensiveProducts(Integer n) {

        return new ResponseEntity<List<Product>>(productService.getTopNMostExpensiveProducts(n), HttpStatus.OK);
    }

    @GetMapping("/low-stock/{threshold}")
    public ResponseEntity<?> getLowStockProducts(@PathVariable Integer threshold) {

        return new ResponseEntity<>(productService.getProductsLowStockValue(threshold), HttpStatus.OK);
    }

}
