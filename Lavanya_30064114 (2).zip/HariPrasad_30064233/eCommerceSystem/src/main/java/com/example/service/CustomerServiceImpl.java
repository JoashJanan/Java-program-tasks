package com.example.service;

import com.example.model.Customer;
import com.example.model.Order;
import com.example.repository.CustomerRepository;
import com.example.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private OrderRepository orderRepository;

    public List<Customer> getCustomersPlacedOrdesAboveThresholdValue(Integer thresholdValue) {
        List<Customer> customerList = customerRepository.findAll();

        return customerRepository.findAll().stream()
                .filter(customer -> orderRepository.findAll().stream()
                        .filter(order -> order.getCustomer().getId().equals(customer.getId()))
                        .mapToDouble(Order::getTotalAmount)
                        .sum() > thresholdValue)
                .collect(Collectors.toList());
    }


    public Map<Boolean, List<Order>> partitionCustomersBasedOnOrderValues(Integer threshold) {
        List<Customer> customerList = customerRepository.findAll();
        List<Order> orderList = orderRepository.findAll();

        return orderList.stream().collect(Collectors.partitioningBy(order -> order.getCustomer().getId() > threshold));
    }

}
