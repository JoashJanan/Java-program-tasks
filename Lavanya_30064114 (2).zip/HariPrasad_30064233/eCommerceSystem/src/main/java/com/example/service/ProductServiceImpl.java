package com.example.service;

import com.example.model.Product;
import com.example.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl {

    @Autowired
    private ProductRepository productRepository;


    public List<Product> getAllProductsByCategory(String category) {
        List<Product> productList = productRepository.findAll();

        if(!CollectionUtils.isEmpty(productList)) {

            return productList.stream().filter(product -> product.getCategory().equalsIgnoreCase(category)).collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    public List<Product> getProductsWithThresholdValue(Double threshold) {
        List<Product> productList = productRepository.findAll();
        if(!CollectionUtils.isEmpty(productList)) {

            return productList.stream().filter(product -> product.getPrice() > threshold).collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    public List<Product> getTopMostExpensiveProducts(Integer n) {
        List<Product> productList = productRepository.findAll();
        if(!CollectionUtils.isEmpty(productList)) {

            return productList.stream().filter(product -> product.getQuantityAvailable()==n).collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    public List<Product> getLowStockProducts(Integer thresholdValue) {
        return productRepository.findAll().stream()
                .filter(product -> product.getQuantityAvailable() < thresholdValue)
                .collect(Collectors.toList());

    }

    public Map<String, List<Product>> getProductsByCategory() {
        List<Product> productList = productRepository.findAll();

        return productList.stream().collect(Collectors.groupingBy(Product::getCategory, Collectors.toList()));
    }

    public Double getTotalPriceOfAllProducts() {
        List<Product> productList =  productRepository.findAll();

        return productList.stream().mapToDouble(Product::getPrice).sum();
    }

    public String getProductNames() {
        List<Product> productList =   productRepository.findAll();

        return productList.stream().map(Product::getName).collect(Collectors.joining(", "));
    }

    public Map<String, Long> averagePriceByCategory() {
        List<Product> productList =   productRepository.findAll();

        return productList.stream().collect(Collectors.groupingBy(Product::getCategory, Collectors.counting()));
    }

    public List<Product> getCountByCategory(String category, Integer threshold) {
        List<Product> productList =   productRepository.findAll();

        return productList.stream().filter(p -> p.getCategory().equalsIgnoreCase(category) && p.getQuantityAvailable() > threshold).collect(Collectors.toList());
    }

    public List<Product> getProductsAboveOrderValue(Integer value) {
        List<Product> productList = productRepository.findAll();

        return productList.stream().filter(p->p.getQuantityAvailable() > value).collect(Collectors.toList());
    }


    public List<Product> getTopNMostExpensiveProducts(Integer n) {
        List<Product> productList = productRepository.findAll();

        return productList.stream().sorted(Comparator.comparingDouble(Product::getPrice).reversed()).limit(n).collect(Collectors.toList());
    }

    public List<Product> getProductsLowStockValue(Integer value) {
        List<Product> productList = productRepository.findAll();

        return productList.stream().filter(p->p.getQuantityAvailable() < value).collect(Collectors.toList());
    }




}
