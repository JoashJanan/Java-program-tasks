package com.example.eCommerceSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
