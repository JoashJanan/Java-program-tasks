package com.example.service;

import com.example.model.Category;

import java.util.List;

public interface ICategoryService {

    Category createCategory(Category category);

    List<Category> getAllCategories();

    Category getCategoryById(Integer id);
}
