package com.example.controller;

import com.example.model.Product;
import com.example.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/product")
public class ProductController {

    @Autowired
    public IProductService productService;

    @PostMapping
    public ResponseEntity<?> createProducts(@RequestBody Product product) {

        return new ResponseEntity<Product>(productService.createProduct(product), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getAllProducts() {

        return new ResponseEntity<List<Product>>(productService.getAllProducts(), HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> getProductsById(@PathVariable Integer id) {

        return new ResponseEntity<Product>(productService.getProductById(id), HttpStatus.OK);
    }
}
