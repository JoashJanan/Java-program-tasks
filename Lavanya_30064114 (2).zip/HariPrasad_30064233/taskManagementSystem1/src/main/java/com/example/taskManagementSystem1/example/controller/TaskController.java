package com.example.taskManagementSystem1.example.controller;

import com.example.taskManagementSystem1.example.model.Task;
import com.example.taskManagementSystem1.example.service.ITaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/tasks")
public class TaskController {


    @Autowired
    private ITaskService taskService;

    @PostMapping
    public ResponseEntity<?> createTask(@RequestBody Task task) {

        return new ResponseEntity<Task>(taskService.createTask(task), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getTasks() {

        return new ResponseEntity<List<Task>>(taskService.getTasks(), HttpStatus.OK);
    }


    @GetMapping("/{taskId}")
    public ResponseEntity<?> getTasksById(@PathVariable("taskId") Long taskId) {
        Task task = taskService.getTaskByTaskId(taskId);
        if (!ObjectUtils.isEmpty(task)) {
            return new ResponseEntity<Task>(task, HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("No Data found for given TaskId: " + taskId, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{taskId}")
    public ResponseEntity<?> deleteTaskById(@PathVariable("taskId") Long taskId) {
        taskService.deleteTaskByTaskId(taskId);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
