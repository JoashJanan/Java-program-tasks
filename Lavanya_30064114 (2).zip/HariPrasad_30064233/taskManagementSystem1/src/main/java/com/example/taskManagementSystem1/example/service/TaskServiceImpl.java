package com.example.taskManagementSystem1.example.service;

import com.example.taskManagementSystem1.example.model.Task;
import com.example.taskManagementSystem1.example.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TaskServiceImpl implements ITaskService {

    @Autowired
    private TaskRepository taskRepository;


    @Override
    public Task createTask(Task task) {

        return taskRepository.save(task);
    }

    @Override
    public List<Task> getTasks() {
        List<Task> taskList = taskRepository.findAll();

        return !CollectionUtils.isEmpty(taskList) ? taskList.stream().sorted(Comparator.comparing(Task::getPriority).reversed()).collect(Collectors.toList()) : new ArrayList<>();
    }

    @Override
    public Task getTaskByTaskId(Long taskId) {
        Optional<Task> optTask = taskRepository.findById(taskId);

        if(optTask.isPresent()) {
            return optTask.get();
        } else {
            throw new IllegalArgumentException("Task not found with the taskId : "+taskId);
        }
    }

    @Override
    public void deleteTaskByTaskId(Long taskId) {

        if(taskRepository.existsById(taskId)) {
            taskRepository.deleteById(taskId);
        }
    }
}
