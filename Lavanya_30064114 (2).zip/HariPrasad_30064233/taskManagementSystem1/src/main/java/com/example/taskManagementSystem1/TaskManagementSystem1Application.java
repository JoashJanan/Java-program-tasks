package com.example.taskManagementSystem1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagementSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(TaskManagementSystem1Application.class, args);
	}

}
