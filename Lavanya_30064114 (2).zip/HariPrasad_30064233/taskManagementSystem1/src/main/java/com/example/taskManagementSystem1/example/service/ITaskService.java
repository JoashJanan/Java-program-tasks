package com.example.taskManagementSystem1.example.service;

import com.example.taskManagementSystem1.example.model.Task;

import java.util.List;

public interface ITaskService {

    Task createTask(Task task);

    List<Task> getTasks();

    Task getTaskByTaskId(Long taskId);

    void deleteTaskByTaskId(Long taskId);
}
