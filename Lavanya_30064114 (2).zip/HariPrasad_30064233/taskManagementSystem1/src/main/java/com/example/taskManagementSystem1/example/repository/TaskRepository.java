package com.example.taskManagementSystem1.example.repository;

import com.example.taskManagementSystem1.example.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task, Long> {


}
