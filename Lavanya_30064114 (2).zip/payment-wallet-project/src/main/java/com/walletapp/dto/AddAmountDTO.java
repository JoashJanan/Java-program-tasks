package com.walletapp.dto;

import lombok.Data;

@Data
public class AddAmountDTO {
    private String emailId;
    private double amount;
}