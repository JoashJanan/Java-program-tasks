package com.walletapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserResponse {
    private int userId;
    private String username;
    private String emailId;
    private String message;
}