package com.walletapp.dto;

import lombok.Data;

@Data
public class TransferDTO {
    private int fromWalletId;
    private int toWalletId;
    private double amount;
}