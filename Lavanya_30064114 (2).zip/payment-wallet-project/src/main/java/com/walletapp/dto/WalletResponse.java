package com.walletapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WalletResponse {
    private int walletId;
    private int userId;
    private String currency;
    private double balance;
}