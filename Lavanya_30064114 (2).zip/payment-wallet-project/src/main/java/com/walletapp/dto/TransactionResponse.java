package com.walletapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@AllArgsConstructor
public class TransactionResponse {
    private int transactionId;
    private int walletId;
    private String status;
    private double amount;
    private LocalDate date;
    private LocalTime time;
}