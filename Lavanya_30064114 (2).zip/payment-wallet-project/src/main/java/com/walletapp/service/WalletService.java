package com.walletapp.service;

import com.walletapp.dto.*;

public interface WalletService {
    UserResponse registerUser(UserRequest request);
    WalletResponse addAmount(AddAmountDTO request);
    WalletResponse getBalance(String emailId);
    TransactionResponse transferAmount(TransferDTO request);
}
