package com.walletapp.service.impl;

import com.walletapp.dto.*;
import com.walletapp.entity.*;
import com.walletapp.repository.*;
import com.walletapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private WalletRepository walletRepo;

    @Autowired
    private CurrencyRepository currencyRepo;

    @Autowired
    private TransactionRepository transactionRepo;

    @Override
    public UserResponse registerUser(UserRequest request) {
        if (userRepo.findByEmailId(request.getEmailId()).isPresent()) {
            return new UserResponse(0, "", request.getEmailId(), "User with the given email id already exists");
        }
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setEmailId(request.getEmailId());
        user = userRepo.save(user);

        Currency currency = currencyRepo.findById(1).orElseThrow();
        Wallet wallet = new Wallet();
        wallet.setUser(user);
        wallet.setCurrency(currency);
        wallet.setBalance(0.0);
        walletRepo.save(wallet);

        return new UserResponse(user.getId(), user.getUsername(), user.getEmailId(), "User registered successfully");
    }

    @Override
    public WalletResponse addAmount(AddAmountDTO request) {
        User user = userRepo.findByEmailId(request.getEmailId()).orElseThrow(() -> new RuntimeException("User not found"));
        Wallet wallet = walletRepo.findByUser(user).orElseThrow(() -> new RuntimeException("Wallet not found"));
        wallet.setBalance(wallet.getBalance() + request.getAmount());
        walletRepo.save(wallet);
        return new WalletResponse(wallet.getId(), user.getId(), wallet.getCurrency().getAbbreviation(), wallet.getBalance());
    }

    @Override
    public WalletResponse getBalance(String emailId) {
        User user = userRepo.findByEmailId(emailId).orElseThrow(() -> new RuntimeException("User not found"));
        Wallet wallet = walletRepo.findByUser(user).orElseThrow(() -> new RuntimeException("Wallet not found"));
        return new WalletResponse(wallet.getId(), user.getId(), wallet.getCurrency().getAbbreviation(), wallet.getBalance());
    }

    @Override
    public TransactionResponse transferAmount(TransferDTO request) {
        Wallet fromWallet = walletRepo.findById(request.getFromWalletId()).orElseThrow(() -> new RuntimeException("From wallet not found"));
        Wallet toWallet = walletRepo.findById(request.getToWalletId()).orElseThrow(() -> new RuntimeException("To wallet not found"));

        if (fromWallet.getBalance() < request.getAmount()) {
            throw new RuntimeException("Insufficient balance. You have Rs " + fromWallet.getBalance() + " balance in your wallet");
        }

        fromWallet.setBalance(fromWallet.getBalance() - request.getAmount());
        toWallet.setBalance(toWallet.getBalance() + request.getAmount());
        walletRepo.save(fromWallet);
        walletRepo.save(toWallet);

        Transaction transaction = new Transaction();
        transaction.setWallet(fromWallet);
        transaction.setAmount(request.getAmount());
        transaction.setStatus("SUCCESS");
        transaction.setDate(LocalDate.now());
        transaction.setTime(LocalTime.now());
        transaction = transactionRepo.save(transaction);

        return new TransactionResponse(transaction.getId(), fromWallet.getId(), transaction.getStatus(), transaction.getAmount(), transaction.getDate(), transaction.getTime());
    }
}