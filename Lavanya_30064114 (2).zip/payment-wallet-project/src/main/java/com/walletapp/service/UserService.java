package com.walletapp.service;

import com.walletapp.dto.*;

public interface UserService {
    UserResponse registerUser(UserRequest request);
    WalletResponse addAmount(AddAmountDTO request);
    WalletResponse getBalance(String emailId);
    TransactionResponse transferAmount(TransferDTO request);
}