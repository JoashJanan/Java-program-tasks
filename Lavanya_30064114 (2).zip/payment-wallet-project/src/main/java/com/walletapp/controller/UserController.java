package com.walletapp.controller;

import com.walletapp.dto.*;
import com.walletapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public UserResponse registerUser(@RequestBody UserRequest request) {
        return userService.registerUser(request);
    }

    @PostMapping("/add-amount")
    public WalletResponse addAmount(@RequestBody AddAmountDTO request) {
        return userService.addAmount(request);
    }

    @GetMapping("/balance")
    public WalletResponse getBalance(@RequestParam String emailId) {
        return userService.getBalance(emailId);
    }

    @PostMapping("/transfer")
    public TransactionResponse transfer(@RequestBody TransferDTO request) {
        return userService.transferAmount(request);
    }
}