package com.employeedetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeedetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
