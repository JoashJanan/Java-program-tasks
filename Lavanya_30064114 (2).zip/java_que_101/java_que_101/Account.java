package java_que_101;

public abstract class Account {

	public abstract Account manage(String accountHolder);
}
