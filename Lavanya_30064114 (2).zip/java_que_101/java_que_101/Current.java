package java_que_101;

public class Current extends Account {

    String accountHolder = "";

    public void setAccountHolder(String accountHolder) {
        this.accountHolder = accountHolder;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    @Override
    public Current manage(String accountHolder) {
        setAccountHolder(accountHolder);
        return this;
    }


}
