package java_que_101;

@SuppressWarnings("serial")
public class UnmanageableAccountRequestException extends Exception{
	
	public UnmanageableAccountRequestException() {
		super();
	}
	
	public UnmanageableAccountRequestException(String message) {
		super(message);
	}

}
