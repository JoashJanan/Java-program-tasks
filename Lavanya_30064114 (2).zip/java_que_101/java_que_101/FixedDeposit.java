package java_que_101;

public class FixedDeposit extends Account{

    String accountHolder = "";

    public void setAccountHolder(String accountHolder) {
        this.accountHolder = accountHolder;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    @Override
    public FixedDeposit manage(String accountHolder) {
        setAccountHolder(accountHolder);
        return this;
	}

}
