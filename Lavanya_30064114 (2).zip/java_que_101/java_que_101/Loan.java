package java_que_101;

public class Loan extends Account{

    String accountHolder = "";

    public void setAccountHolder(String accountHolder) {
        this.accountHolder = accountHolder;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    @Override
    public Loan manage(String accountHolder) {
        setAccountHolder(accountHolder);
        return this;
    }


}
