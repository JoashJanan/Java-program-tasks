package com.example.controller;

import com.example.model.Player;
import com.example.model.Sport;
import com.example.repository.PlayerRepository;
import com.example.repository.SportRepository;
import com.example.service.IPlayerService;
import com.example.service.ISportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/players")
public class PlayerController {

    @Autowired
    private ISportService sportService;

    @Autowired
    private IPlayerService playerService;

    @Autowired
    private SportRepository sportRepository;

    @Autowired
    private PlayerRepository playerRepository;

    @PostMapping
    public ResponseEntity<?> createPlayer(@RequestBody Player player) {

        return new ResponseEntity<Player>(playerService.addPlayer(player), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getAllPlayers() {

        return new ResponseEntity<>(playerService.getAllPlayers(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sport> getPlayerById(@PathVariable Long id) {

        return new ResponseEntity<Sport>(playerService.getPlayerById(id), HttpStatus.OK);
        /*return playerRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());*/
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updatePlayer(@PathVariable Long id, @RequestBody Player playerDetails) {

        return new ResponseEntity<Player>(playerService.updatePlayer(id, playerDetails), HttpStatus.OK);
        /*return playerRepository.findById(id).map(player -> {
            player.setFirstName(playerDetails.getFirstName());
            player.setLastName(playerDetails.getLastName());
            player.setDateOfBirth(playerDetails.getDateOfBirth());
            return ResponseEntity.ok(playerRepository.save(player));
        }).orElse(ResponseEntity.notFound().build());*/
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlayer(@PathVariable Long id) {
        playerRepository.deleteById(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        //return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/sport")
    public ResponseEntity<Sport> getPlayerSport(@PathVariable Long id) {

        return new ResponseEntity<Sport>(playerService.getPlayerById(id), HttpStatus.OK);
       /* return playerRepository.findById(id)
                .map(player -> ResponseEntity.ok(player.getSport()))
                .orElse(ResponseEntity.notFound().build());*/
    }

    @PostMapping("/{id}/switch-sport/{newSportId}")
    public ResponseEntity<Player> switchPlayerSport(@PathVariable Long id, @PathVariable Long newSportId) {

        return new ResponseEntity<Player>(playerService.switchPlayerSport(id, newSportId), HttpStatus.OK);
        /*return playerRepository.findById(id).map(player -> {
            return sportRepository.findById(newSportId).map(newSport -> {
                player.setSport(newSport);
                return ResponseEntity.ok(playerRepository.save(player));
            }).orElse(ResponseEntity.badRequest().build());
        }).orElse(ResponseEntity.notFound().build());*/
    }
}
