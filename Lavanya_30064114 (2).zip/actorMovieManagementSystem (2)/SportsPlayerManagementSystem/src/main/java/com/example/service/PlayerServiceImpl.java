package com.example.service;

import com.example.model.Player;
import com.example.model.Sport;
import com.example.repository.PlayerRepository;
import com.example.repository.SportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.swing.text.html.Option;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class PlayerServiceImpl implements IPlayerService {

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private SportRepository sportRepository;

    @Override
    public Player addPlayer(Player player) {
        return playerRepository.save(player);
    }

    @Override
    public Player updatePlayer(Long playerId, Player player) {
        Optional<Player> optionalPlayer = playerRepository.findById(playerId);
        if (optionalPlayer.isPresent()) {
            Player playerFromDB = optionalPlayer.get();
            playerFromDB.setId(playerId);
            playerFromDB.setFirstName(player.getFirstName());
            playerFromDB.setLastName(player.getLastName());
            playerFromDB.setDateOfBirth(player.getDateOfBirth());
            playerFromDB.setSport(player.getSport());

            return playerRepository.save(playerFromDB);
        }
        return null;
    }

    @Override
    public List<Player> getAllPlayers() {
        List<Player> playersList = playerRepository.findAll();

        return !CollectionUtils.isEmpty(playersList) ? playersList : new ArrayList<>();
    }

    @Override
    public Sport getPlayerById(Long playerId) {
        Optional<Player> optionalPlayer = playerRepository.findById(playerId);
        if (optionalPlayer.isPresent()) {
            optionalPlayer.get().getSport();
        } else {
            throw new IllegalArgumentException("Player not found for playerId :" + playerId);
        }

        return null;
    }

    @Override
    public void deletePlayerById(Long playerId) {
        if (playerRepository.existsById(playerId)) {
            playerRepository.deleteById(playerId);
        }
    }

    @Override
    public Player switchPlayerSport(Long playerId, Long newSportId) {
        Optional<Player> optionalPlayer = playerRepository.findById(playerId);
        Player player = null;
        if(optionalPlayer.isPresent()) {
            player = optionalPlayer.get();
            Optional<Sport> optionalSport =  sportRepository.findById(newSportId);
            if(optionalSport.isPresent()) {
                player.setSport(optionalSport.get());
                return playerRepository.save(player);
            } else {
                throw new IllegalArgumentException("Sport not found for sportId : "+newSportId);
            }
        } else {
            throw new IllegalArgumentException("Player not found for playerId :"+playerId);
        }
    }
}
