package com.example.service;

import com.example.model.Sport;

import java.util.List;

public interface ISportService {

    Sport createSport(Sport sport);

    Sport updateSport(Long sportId, Sport sport);

    List<Sport> getAllSports();

    Sport getSportById(Long sportId);

    void deleteSport(Long sportId);

}
