package com.example.service;

import com.example.model.Player;
import com.example.model.Sport;

import java.util.List;

public interface IPlayerService {

    Player addPlayer(Player player);

    Player updatePlayer(Long playerId, Player player);

    List<Player> getAllPlayers();

    Sport getPlayerById(Long playerId);

    void deletePlayerById(Long playerId);

    Player switchPlayerSport(Long playerId, Long newSportId);
}
