package com.example.controller;


import com.example.model.Sport;
import com.example.service.ISportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sports")
public class SportController {

    @Autowired
    private ISportService sportService;

    @PostMapping
    public ResponseEntity<?> createSport(@RequestBody Sport sport) {

        return new ResponseEntity<Sport>(sportService.createSport(sport), HttpStatus.CREATED);
    }

    @PutMapping("/{sportId}")
    public ResponseEntity<?> updateSport(@PathVariable("sportId") Long sportId, @RequestBody Sport sport) {

        return new ResponseEntity<Sport>(sportService.updateSport(sportId, sport), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<?> getAllSports() {

        return new ResponseEntity<List<Sport>>(sportService.getAllSports(), HttpStatus.OK);
    }

    @GetMapping("/{sportId}")
    public ResponseEntity<?> getSportDetailsById(@PathVariable("sportId") Long sportId) {

        return new ResponseEntity<Sport>(sportService.getSportById(sportId), HttpStatus.OK);
    }

    @DeleteMapping("/{sportId}")
    public ResponseEntity<?> deleteSportBySportId(@PathVariable("sportId") Long sportId) {
        sportService.deleteSport(sportId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
