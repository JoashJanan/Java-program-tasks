package com.example.service;

import com.example.model.Sport;
import com.example.repository.SportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class SportServiceImpl implements ISportService {

    @Autowired
    private SportRepository sportRepository;

    @Override
    public Sport createSport(Sport sport) {
        Sport saveSportObj = sportRepository.save(sport);
        saveSportObj.setName(sport.getName());
        saveSportObj.setType(sport.getType());

        return saveSportObj;
    }

    @Override
    public Sport updateSport(Long sportId, Sport sport) {
        Optional<Sport> optionalSport = sportRepository.findById(sportId);
        Sport sportDBObj = null;
        if(optionalSport.isPresent()) {
            sportDBObj = optionalSport.get();
            sportDBObj.setId(sportId);
            sportDBObj.setName(sport.getName());
            sportDBObj.setType(sport.getType());

            return sportRepository.save(sportDBObj);
        }
        return null;
    }

    @Override
    public List<Sport> getAllSports() {
        List<Sport> sportList = sportRepository.findAll();

        return !CollectionUtils.isEmpty(sportList) ? sportList : new ArrayList<>();
    }

    @Override
    public Sport getSportById(Long sportId) {
        Optional<Sport> optionalSport = sportRepository.findById(sportId);
        if (optionalSport.isPresent()) {
            optionalSport.get();
        } else {
            return new Sport();
        }
        return null;
    }

    @Override
    public void deleteSport(Long sportId) {
        if(sportRepository.existsById(sportId)) {
            sportRepository.deleteById(sportId);
        }
    }
}
