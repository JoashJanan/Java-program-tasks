package com.example.SportsPlayerManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsPlayerManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
