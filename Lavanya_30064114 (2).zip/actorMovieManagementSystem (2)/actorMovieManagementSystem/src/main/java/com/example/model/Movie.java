package com.example.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.Set;

@Entity
@Data
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotBlank(message = "Title cannot be empty")
    private String title;
    @Min(value = 1900, message = "Release year must be >= 1900 ")
    private Integer releaseYear;
    @NotBlank(message = "Genre cannot be empty")
    private String genre;
    @DecimalMin(value = "0.0", message = "Rating must be between 0.0 and 10.0")
    @DecimalMax(value = "10.0", message = "Rating must be between 0.0 and 10.0")
    private Double rating;
    private Set<Actor> actors;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public @NotBlank(message = "Title cannot be empty") String getTitle() {
        return title;
    }

    public void setTitle(@NotBlank(message = "Title cannot be empty") String title) {
        this.title = title;
    }

    public @Min(value = 1900, message = "Release year must be >= 1900 ") Integer getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(@Min(value = 1900, message = "Release year must be >= 1900 ") Integer releaseYear) {
        this.releaseYear = releaseYear;
    }

    public @NotBlank(message = "Genre cannot be empty") String getGenre() {
        return genre;
    }

    public void setGenre(@NotBlank(message = "Genre cannot be empty") String genre) {
        this.genre = genre;
    }

    public @DecimalMin(value = "0.0", message = "Rating must be between 0.0 and 10.0") @DecimalMax(value = "10.0", message = "Rating must be between 0.0 and 10.0") Double getRating() {
        return rating;
    }

    public void setRating(@DecimalMin(value = "0.0", message = "Rating must be between 0.0 and 10.0") @DecimalMax(value = "10.0", message = "Rating must be between 0.0 and 10.0") Double rating) {
        this.rating = rating;
    }

    public Set<Actor> getActors() {
        return actors;
    }

    public void setActors(Set<Actor> actors) {
        this.actors = actors;
    }
}
