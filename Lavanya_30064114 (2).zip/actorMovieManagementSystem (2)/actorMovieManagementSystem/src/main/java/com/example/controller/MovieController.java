package com.example.controller;

import com.example.model.Movie;
import com.example.service.ActorServiceImpl;
import com.example.service.MovieServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/movies")
public class MovieController {

    @Autowired
    private MovieServiceImpl movieService;

    @Autowired
    private ActorServiceImpl actorService;

    @PostMapping
    public ResponseEntity<?> createMovie(@RequestBody Movie movie) {

        return new ResponseEntity<Movie>(movieService.saveMovie(movie), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getAllMovies() {

        return new ResponseEntity<List<Movie>>(movieService.getMoviesList(), HttpStatus.OK);
    }

    @GetMapping("/{movieId}")
    public ResponseEntity<?> getMovieByMovieId(@PathVariable("movieId") Long movieId) {
        Movie movie = movieService.getMovieById(movieId);
        if (!ObjectUtils.isEmpty(movie)) {
            return new ResponseEntity<Movie>(movie, HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("Movie does not exist with movieId " + movieId, HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{movieId}/actors")
    public ResponseEntity<?> updateMovieActors(@PathVariable Long movieId, @RequestBody List<Long> actorIds) {

        return new ResponseEntity<Movie>(actorService.updateMovieActors(movieId, actorIds), HttpStatus.OK);
    }
}
