package com.example.service;

import com.example.model.Movie;
import com.example.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MovieServiceImpl {


    @Autowired
    private MovieRepository movieRepository;


    public Movie saveMovie(Movie movie) {

        return movieRepository.save(movie);
    }

    public List<Movie> getMoviesList() {
        List<Movie> movieList =  movieRepository.findAll();

        return !CollectionUtils.isEmpty(movieList) ? movieList : new ArrayList<>();
    }

    public Movie getMovieById(Long movieId) {
        Optional<Movie> optionalMovie = movieRepository.findById(movieId);
        if(optionalMovie.isPresent()) {
            return optionalMovie.get();
        } else {
            throw new IllegalArgumentException("No Movie found with movieId : "+movieId);
        }
    }


}
