package com.example.actorMovieManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActorMovieManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActorMovieManagementSystemApplication.class, args);
	}

}
