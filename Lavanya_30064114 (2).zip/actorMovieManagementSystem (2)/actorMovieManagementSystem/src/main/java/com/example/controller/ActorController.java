package com.example.controller;

import com.example.model.Actor;
import com.example.model.Movie;
import com.example.service.ActorServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/actors")
public class ActorController {

    @Autowired
    private ActorServiceImpl actorService;

    @PostMapping
    public ResponseEntity<?> createNewActor(@RequestBody Actor actor) {

        return new ResponseEntity<Actor>(actorService.saveActor(actor), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getAllActors() {

        return new ResponseEntity<List<Actor>>(actorService.getAllActors(), HttpStatus.OK);
    }

    @GetMapping("/{actorId}")
    public ResponseEntity<?> getActorByActorId(@PathVariable("actorId") Long actorId) {
        Actor actor = actorService.getActorByActorId(actorId);
        if (!ObjectUtils.isEmpty(actor)) {
            return new ResponseEntity<Actor>(actor, HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("Actor not found with actorId : " + actorId, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{actorId}/movies")
    public ResponseEntity<?> getMoviesByActor(@PathVariable("actorId") Long actorId) {

        return new ResponseEntity<Set<Movie>>(actorService.getMoviesByActor(actorId), HttpStatus.OK);
    }

    @PutMapping("/{actorId}/movies")
    public ResponseEntity<?> updateActorMovies(@PathVariable("actorId") Long actorId, @RequestBody List<Long> movieIds) {

        return new ResponseEntity<Actor>(actorService.updateActorMovies(actorId, movieIds), HttpStatus.OK);
    }
}
