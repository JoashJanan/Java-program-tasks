package com.example.service;

import com.example.model.Actor;
import com.example.model.Movie;
import com.example.repository.ActorRepository;
import com.example.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ActorServiceImpl {

    @Autowired
    private ActorRepository actorRepository;

    @Autowired
    private MovieRepository movieRepository;

    public Actor saveActor(Actor actor) {

        return actorRepository.save(actor);
    }

    public List<Actor> getAllActors() {
        List<Actor> actorList = actorRepository.findAll();

        return !CollectionUtils.isEmpty(actorList) ? actorList : new ArrayList<>();
    }

    public Actor getActorByActorId(Long actorId) {
        Optional<Actor> optionalActor = actorRepository.findById(actorId);
        if (optionalActor.isPresent()) {

            return optionalActor.get();
        } else {
            throw new IllegalArgumentException("Actor not found with actorId : " + actorId);
        }
    }

    public Set<Movie> getMoviesByActor(Long actorId) {
        Optional<Actor> optionalActor = actorRepository.findById(actorId);
        if (optionalActor.isPresent()) {
            Set<Movie> movieList = optionalActor.get().getMovies();

            return movieList.stream().sorted(Comparator.comparing(Movie::getId)).collect(Collectors.toSet());
        } else {
            throw new IllegalArgumentException("No actor found for actorId : " + actorId);
        }
    }

    public Actor updateActorMovies(Long actorId, List<Long> movieIds) {
        Optional<Actor> optionalActor = actorRepository.findById(actorId);
        Actor actor = null;
        if (optionalActor.isPresent()) {
            actor = optionalActor.get();
        }
        List<Movie> movieList = movieRepository.findAllById(movieIds);
        if (movieList.size() != movieIds.size()) {
            throw new IllegalArgumentException("One or more movies not found");
        }

        actor.setMovies(new HashSet<>(movieList));

        return actorRepository.save(actor);
    }

    public Movie updateMovieActors(Long movieId, List<Long> actorIds) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new IllegalArgumentException("Movie not found"));

        List<Actor> actors = actorRepository.findAllById(actorIds);

        if (actors.size() != actorIds.size()) {
            throw new IllegalArgumentException("One or more actors not found");
        }

        movie.setActors(new HashSet<>(actors));

        return movieRepository.save(movie);
    }


}
