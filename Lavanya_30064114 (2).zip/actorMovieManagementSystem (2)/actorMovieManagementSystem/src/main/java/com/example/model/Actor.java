package com.example.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.Set;

@Entity
@Data
public class Actor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotBlank(message = "First name cannot be empty")
    private String firstName;
    @NotBlank(message = "Last name cannot be empty")
    private String lastName;
    @Min(value = 1900, message = "Birth year must be >= 1900")
    private Integer birthYear;

    @ManyToMany
    @JoinTable(name = "actor_movies",
    joinColumns = @JoinColumn(name = "actor_id"),
    inverseJoinColumns = @JoinColumn(name = "movie_id"))
    private Set<Movie> movies;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public @NotBlank(message = "First name cannot be empty") String getFirstName() {
        return firstName;
    }

    public void setFirstName(@NotBlank(message = "First name cannot be empty") String firstName) {
        this.firstName = firstName;
    }

    public @NotBlank(message = "Last name cannot be empty") String getLastName() {
        return lastName;
    }

    public void setLastName(@NotBlank(message = "Last name cannot be empty") String lastName) {
        this.lastName = lastName;
    }

    public @Min(value = 1900, message = "Birth year must be >= 1900") Integer getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(@Min(value = 1900, message = "Birth year must be >= 1900") Integer birthYear) {
        this.birthYear = birthYear;
    }

    public Set<Movie> getMovies() {
        return movies;
    }

    public void setMovies(Set<Movie> movies) {
        this.movies = movies;
    }
}
