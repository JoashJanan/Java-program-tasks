package com.example.service;

import com.example.model.TouristDestination;
import com.example.repository.TouristDestinationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TouristDestinationServiceImpl implements ITouristDestination{

    @Autowired
    private TouristDestinationRepository touristDestinationRepository;

    @Override
    public TouristDestination createTouristDestination(TouristDestination touristDestination) {

        TouristDestination saveTouristDestination = touristDestinationRepository.save(touristDestination);
        touristDestination.setId(saveTouristDestination.getId());

        return touristDestination;
    }

    @Override
    public List<TouristDestination> getAllTouristDestion() {
        List<TouristDestination> touristDestinationList = touristDestinationRepository.findAll();

        return !CollectionUtils.isEmpty(touristDestinationList) ? touristDestinationList.stream().sorted(Comparator.comparing(TouristDestination::getId)).collect(Collectors.toList()) : new ArrayList<>();
    }

    @Override
    public void deleteTouristDestinationById(Long destinationId) {
        if(touristDestinationRepository.existsById(destinationId)) {

            touristDestinationRepository.deleteById(destinationId);
        }
    }

    @Override
    public List<TouristDestination> getAllTouristDestinationRecordsWithVisitorCount() {
        List<TouristDestination> touristDestinationList = touristDestinationRepository.findAll();

        return !CollectionUtils.isEmpty(touristDestinationList) ? touristDestinationList.stream().sorted(Comparator.comparing(TouristDestination::getVisitorCount).reversed()).toList() : new ArrayList<>();
    }
}
