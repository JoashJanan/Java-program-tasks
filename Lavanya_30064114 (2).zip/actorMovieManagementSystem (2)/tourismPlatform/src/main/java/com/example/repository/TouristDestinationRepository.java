package com.example.repository;

import com.example.model.TouristDestination;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TouristDestinationRepository extends JpaRepository<TouristDestination, Long> {


}
