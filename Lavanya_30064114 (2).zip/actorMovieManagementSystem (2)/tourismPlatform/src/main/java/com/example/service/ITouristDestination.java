package com.example.service;

import com.example.model.TouristDestination;

import java.util.List;

public interface ITouristDestination {


    TouristDestination createTouristDestination(TouristDestination touristDestination);

    List<TouristDestination> getAllTouristDestion();

    void deleteTouristDestinationById(Long destinationId);

    List<TouristDestination> getAllTouristDestinationRecordsWithVisitorCount();

}
