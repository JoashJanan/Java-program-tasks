package com.example.controller;


import com.example.model.TouristDestination;
import com.example.service.ITouristDestination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tourism/platform/v1/destinations")
public class TouristDestinationController {

    @Autowired
    private ITouristDestination touristDestinationService;

    @PostMapping
    public ResponseEntity<?> createTouristDestination(@RequestBody TouristDestination touristDestination) {

        return new ResponseEntity<TouristDestination>(touristDestinationService.createTouristDestination(touristDestination), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getAllTouristDestionationsWithId() {

        return new ResponseEntity<List<TouristDestination>>(touristDestinationService.getAllTouristDestion(), HttpStatus.OK);
    }

    @DeleteMapping("/{destinationId}")
    public ResponseEntity<?> deleteTouristDestinationById(@PathVariable("destinationId") Long destinationId) {

        touristDestinationService.deleteTouristDestinationById(destinationId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/sorted")
    public ResponseEntity<?> getAllTouristDestinationWithVisitorCount() {
        touristDestinationService.getAllTouristDestinationRecordsWithVisitorCount();

        return new ResponseEntity<List<TouristDestination>>(touristDestinationService.getAllTouristDestinationRecordsWithVisitorCount(), HttpStatus.OK);
    }

}
