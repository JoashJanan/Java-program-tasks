package com.example.tourismPlatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourismPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourismPlatformApplication.class, args);
	}

}
