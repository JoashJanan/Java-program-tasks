package com.example.tourismPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourismPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
