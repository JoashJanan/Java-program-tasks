package com.artist.dto;

public record ArtistRequest(String firstName, String lastName) {
}
