import React from 'react';
import { Card, Button, Badge } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const BookCard = ({ book, onBorrow, onReturn}) => {
  const { user } = useAuth();
  const isMember = user?.role === 'member';
  const isAdmin = user?.role === 'admin';

  const coverSrc = book.imageBase64 || book.imageUrl || null;

  const handleBorrow = () => {
    if (onBorrow) onBorrow(book);
  };

  const handleReturn = () => {
    if (onReturn) onReturn(book);
  };

  return (
    <Card className="h-100 shadow-sm" data-testid={`book-card-${book.id}`}>
      {/* Cover image (supports Base64 or external URL). Hidden if broken. */}
      
      {coverSrc && (
        <div className='image-container'>
        <Card.Img
          variant="top"
          src={coverSrc}
          alt={`${book.title} cover`}
          style={{width:"fit-content", objectFit: 'fill'  }}
          onError={(e) => {
            // Hide the broken image element to keep the card neat
            e.currentTarget.style.display = 'none';
          }}
        />
        </div>
      )}

      <Card.Body className='card-Body-container'>
        <div className="d-flex justify-content-between align-items-start">
          <Card.Title className="mb-0" style={{ maxWidth: '75%' }}>
            {book.title}
          </Card.Title>
          <Badge bg={book.available ? 'success' : 'secondary'}>
            {book.available ? 'Available' : 'Unavailable'}
          </Badge>
        </div>

        <Card.Subtitle className="mt-1 text-muted">by {book.author}</Card.Subtitle>

        <div className="d-flex gap-2 flex-wrap mt-3">
          {/* Details - always visible */}
          <Button
            as={Link}
            to={`/books/${book.id}`}
            variant="outline-primary"
            size="sm"
          >
            Details
          </Button>

          {/* Member actions */}
          {(isMember || isAdmin) && (
            <>
              {book.available && onBorrow && (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleBorrow}
                >
                  Borrow
                </Button>
              )}

              {/* Optional return action if you wire it via props */}
              {!book.available && onReturn && (
                <Button
                  variant="success"
                  size="sm"
                  onClick={handleReturn}
                >
                  Return
                </Button>
              )}
            </>
          )}
        </div>
      </Card.Body>
    </Card>
  );
};

export default BookCard;
