import React from 'react';
import { Navbar, Container, Nav, Button } from 'react-bootstrap';
import { Link, NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const AppNavbar = () => {
  const { user, logout } = useAuth();

  return (
    <Navbar bg="lib" sticky="top" variant="dark" expand="md">
      <Container>
        <Navbar.Brand as={Link} to="/">📚 Library</Navbar.Brand>
        <Navbar.Toggle aria-controls="lms-navbar" />
        <Navbar.Collapse id="lms-navbar">
          <Nav className="me-auto">
            <Nav.Link as={NavLink} to="/">Home</Nav.Link>
            {user?.role === 'admin' && (
              <Nav.Link as={NavLink} to="/dashboard">Dashboard</Nav.Link>
            )}
            {user && (
              <Nav.Link as={NavLink} to="/my-borrowings">My Borrowings</Nav.Link>
            )}
          </Nav>
          <Nav>
            {!user ? (
              <>
                <Nav.Link as={NavLink} to="/login">Login</Nav.Link>
                <Nav.Link as={NavLink} to="/register">Register</Nav.Link>
              </>
            ) : (
              <>
                <Navbar.Text className="me-3">
                  Signed in as: <strong>{user.name}</strong> ({user.role})
                </Navbar.Text>
                <Button variant="outline-light" onClick={logout}>Logout</Button>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default AppNavbar;
