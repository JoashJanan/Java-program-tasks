import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ProtectedRoute from '../components/ProtectedRoute';
import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import MyBorrowings from '../pages/MyBorrowings';

const Dashboard = lazy(() => import('../pages/Dashboard'));
const BookDetails = lazy(() => import('../pages/BookDetails'));

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Suspense fallback={<div className="text-center p-5">Loading...</div>}>
        <Routes>
          {/* Public */}
          <Route path="/" element={<Home />} />
          <Route path="/books/:id" element={<BookDetails />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Protected: Admin */}
          <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
            <Route path="/dashboard" element={<Dashboard />} />
          </Route>

          {/* Protected: Member */}
          <Route element={<ProtectedRoute allowedRoles={['member', 'admin']} />}>
            <Route path="/my-borrowings" element={<MyBorrowings />} />
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Home />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
};

export default AppRoutes;
