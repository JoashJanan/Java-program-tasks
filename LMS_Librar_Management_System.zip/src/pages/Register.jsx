import React from 'react';
import { Container, Row, Col, Card, Form, Button } from 'react-bootstrap';
import AppNavbar from '../components/Navbar';
import { useForm } from 'react-hook-form';
import { emailRules, passwordRules, nameRules } from '../utils/validators';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const { register: rhfRegister, handleSubmit, formState: { errors } } = useForm();
  const { register: signup, loading } = useAuth();
  const navigate = useNavigate();

  const onSubmit = async (values) => {
    const created = await signup({
      name: values.name,
      email: values.email,
      password: values.password,
      role: values.role
    });
    if (created) navigate('/login');
  };

  return (
    <>
      <AppNavbar />
      <Container className="py-4">
        <Row className="justify-content-center">
          <Col md={6} lg={5}>
            <Card className='shadow-sm'>
              <Card.Body>
                <Card.Title className="mb-3">Register</Card.Title>
                <Form onSubmit={handleSubmit(onSubmit)}>
                  <Form.Group className="mb-3">
                    <Form.Label>Name</Form.Label>
                    <Form.Control placeholder="Jane Doe"
                      {...rhfRegister('name', nameRules)} isInvalid={!!errors.name} />
                    <Form.Control.Feedback type="invalid">
                      {errors.name?.message}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Email</Form.Label>
                    <Form.Control type="email" placeholder="you@example.com"
                      {...rhfRegister('email', emailRules)} isInvalid={!!errors.email} />
                    <Form.Control.Feedback type="invalid">
                      {errors.email?.message}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="••••••"
                      {...rhfRegister('password', passwordRules)} isInvalid={!!errors.password} />
                    <Form.Control.Feedback type="invalid">
                      {errors.password?.message}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Role</Form.Label>
                    <Form.Select defaultValue="member" {...rhfRegister('role')}>
                      <option value="member">Member</option>
                      <option value="admin">Admin</option>
                    </Form.Select>
                  </Form.Group>

                  <Button type="submit" disabled={loading}>
                    {loading ? 'Creating...' : 'Create Account'}
                  </Button>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Register;
