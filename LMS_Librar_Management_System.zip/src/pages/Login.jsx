import React from 'react';
import { Container, Row, Col, Card, Form, Button } from 'react-bootstrap';
import AppNavbar from '../components/Navbar';
import { useForm } from 'react-hook-form';
import { emailRules, passwordRules } from '../utils/validators';
import { useAuth } from '../context/AuthContext';
import { useLocation, useNavigate } from 'react-router-dom';

const Login = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const { login, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/';

  const onSubmit = async (values) => {
    const authUser = await login(values);
    if (authUser) {
      // redirect back
      navigate(from, { replace: true });
    }
  };

  return (
    <>
      <AppNavbar />
      <Container className="py-4">
        <Row className="justify-content-center">
          <Col md={6} lg={5}>
            <Card className='shadow-sm'>
              <Card.Body>
                <Card.Title className="mb-3">Login</Card.Title>
                <Form onSubmit={handleSubmit(onSubmit)}>
                  <Form.Group className="mb-3">
                    <Form.Label>Email</Form.Label>
                    <Form.Control type="email" placeholder="you@example.com"
                      {...register('email', emailRules)} isInvalid={!!errors.email} />
                    <Form.Control.Feedback type="invalid">
                      {errors.email?.message}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="••••••"
                      {...register('password', passwordRules)} isInvalid={!!errors.password} />
                    <Form.Control.Feedback type="invalid">
                      {errors.password?.message}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Button type="submit" disabled={loading}>
                    {loading ? 'Logging in...' : 'Login'}
                  </Button>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Login;
