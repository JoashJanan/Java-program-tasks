import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Spinner } from 'react-bootstrap';
import AppNavbar from '../components/Navbar';
import BookCard from '../components/BookCard';
import { api } from '../services/api';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';

const Home = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();


  const loadBooks = async () => {
    try {
      const { data } = await api.get('/books');
      setBooks(data);
    } catch {
      toast.error('Failed to load books');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBooks();
  }, []);

  const handleBorrow = async (book) => {
    if (!user) {
      toast.info('Please login to borrow');
      return;
    }
    if (!book.available) {
      toast.error('Book is not available');
      return;
    }
    try {
      const today = new Date().toISOString().slice(0, 10);
      await api.patch(`/books/${book.id}`, { available: false });
      await api.post('/borrowings', {
        userId: user.id,
        bookId: book.id,
        userName:user.name,
        bookTitle:book.title,
        borrowDate: today,
        returnDate: null
      });
      toast.success('Book borrowed');
      loadBooks();
    } catch {
      toast.error('Borrow failed');
    }
  };

  return (
    <>
      <AppNavbar />
      <Container className="py-4">
        <h1 className="mb-3 welcome-title">Welcome to the Library</h1>
        {loading ? (
          <div className="text-center py-5">
            <Spinner animation="border" />
          </div>
        ) : (
          <Row xs={1} sm={2} md={3} lg={3} className="g-3">
            {books.map((b) => (
              <Col key={b.id}>
                <BookCard book={b} onBorrow={handleBorrow} />
              </Col>
            ))}
          </Row>
        )}
      </Container>
    </>
  );
};

export default Home;
