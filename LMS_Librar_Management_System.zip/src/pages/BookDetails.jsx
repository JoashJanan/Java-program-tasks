import React, { useEffect, useState } from 'react';
import AppNavbar from '../components/Navbar';
import { Container, Card, Button, Badge } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import { api } from '../services/api';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';

const BookDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [book, setBook] = useState(null);
  const [myActiveBorrowing, setMyActiveBorrowing] = useState(null);
  const [coverSrc,setCoverSrc] = useState(null);

  const load = async () => {
    try {
      const { data } = await api.get(`/books/${id}`);
      setBook(data);
      setCoverSrc(data.imageBase64 || data.imageUrl || null);
      if (user) {
        const { data: br } = await api.get('/borrowings', {
          params: { userId: user.id, bookId: Number(id), returnDate: null }
        });
        setMyActiveBorrowing(br[0] || null);
      }
    } catch {
      toast.error('Failed to load book');
    }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [id, user?.id]);

  const borrow = async () => {
    if (!user) return toast.info('Please login to borrow');
    if (!book.available) return toast.error('Book not available');

    const today = new Date().toISOString().slice(0, 10);
    try {
      await api.patch(`/books/${book.id}`, { available: false });
      await api.post('/borrowings', {
        userId: user.id,
        bookId: book.id,
        borrowDate: today,
        returnDate: null
      });
      toast.success('Book borrowed');
      load();
    } catch {
      toast.error('Borrow failed');
    }
  };

  const returnBook = async () => {
    if (!user || !myActiveBorrowing) return;
    const today = new Date().toISOString().slice(0, 10);
    try {
      await api.patch(`/borrowings/${myActiveBorrowing.id}`, { returnDate: today });
      await api.patch(`/books/${book.id}`, { available: true });
      toast.success('Book returned');
      load();
    } catch {
      toast.error('Return failed');
    }
  };

  if (!book) return (
    <>
      <AppNavbar />
      <Container className="py-4">Loading...</Container>
    </>
  );

  return (
    <>
      <AppNavbar />
      <Container className="py-4 details-main-container">
        <Card className='shadow-sm details-card-container'>
          <div className='image-container'>
           {coverSrc && (
                  <Card.Img
                    variant="top"
                    src={coverSrc}
                    alt={`${book.title} cover`}
                    style={{ width:"fit-content", objectFit: 'fill' }}
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                )}
                </div>
          <Card.Body className='card-Body-container'>
            <Card.Title className="d-flex justify-content-between">
              <span>{book.title}</span>
              <Badge bg={book.available ? 'success' : 'secondary'}>
                {book.available ? 'Available' : 'Unavailable'}
              </Badge>
            </Card.Title>
            <Card.Subtitle className="mb-2 text-muted">by {book.author}</Card.Subtitle>

            <div className="d-flex gap-2 mt-3">
              {user?.role === 'member' && (
                <>
                  {book.available ? (
                    <Button onClick={borrow}>Borrow</Button>
                  ) : myActiveBorrowing ? (
                    <Button variant="success" onClick={returnBook}>Return</Button>
                  ) : (
                    <Button variant="secondary" disabled>Not available</Button>
                  )}
                </>
              )}
            </div>
          </Card.Body>
        </Card>
      </Container>
    </>
  );
};

export default BookDetails;
