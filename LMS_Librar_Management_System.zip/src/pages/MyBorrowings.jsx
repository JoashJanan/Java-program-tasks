import React, { useEffect, useState } from 'react';
import AppNavbar from '../components/Navbar';
import { Container, Table, Button } from 'react-bootstrap';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const MyBorrowings = () => {
  const { user } = useAuth();
  const [items, setItems] = useState([]);

  const load = async () => {
    try {
      const { data } = await api.get(`/borrowings?userId=${user.id}`);
      setItems(data);
    } catch {
      toast.error('Failed to load borrowings');
    }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [user?.id]);

  const returnBook = async (borrowing) => {
    try {
      const today = new Date().toISOString().slice(0, 10);
      await api.patch(`/borrowings/${borrowing.id}`, { returnDate: today });
      await api.patch(`/books/${borrowing.bookId}`, { available: true });
      toast.success('Book returned');
      load();
    } catch {
      toast.error('Return failed');
    }
  };

  return (
    <>
      <AppNavbar />
      <Container className="py-4">
        <h3 className="mb-3 welcome-sub-title">My Borrowings</h3>
        <Table bordered responsive className='myBorrow-table'>
          <thead>
            <tr>
              <th>Book</th>
              <th>Borrowed</th>
              <th>Returned</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {items.map((br) => (
              <tr key={br.id}>
                <td>{br.bookTitle}</td>
                <td>{br.borrowDate}</td>
                <td>{br.returnDate || '-'}</td>
                <td>
                  {!br.returnDate ? (
                    <Button size="sm" onClick={() => returnBook(br)}>Return</Button>
                  ) : (
                    <Button size="sm" disabled variant="secondary">Returned</Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Container>
    </>
  );
};

export default MyBorrowings;
