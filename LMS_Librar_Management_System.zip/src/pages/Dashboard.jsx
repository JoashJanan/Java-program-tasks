// src/pages/Dashboard.js
import React, { useEffect, useState } from 'react';
import AppNavbar from '../components/Navbar';
import { Container, Row, Col, Card, Form, Button, Table, Badge, Image } from 'react-bootstrap';
import { api } from '../services/api';
import { toast } from 'react-toastify';
import { useForm } from 'react-hook-form';
import { requiredRule } from '../utils/validators';
import { useAuth } from '../context/AuthContext';
import { compressImageFile, isValidImageFile } from '../utils/image';

const Dashboard = () => {
  const { user } = useAuth(); // ProtectedRoute should ensure admin; keep for future role checks.
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  
  const [editingId, setEditingId] = useState(null);
const [searchTerm, setSearchTerm] = useState('');


  // ---------- Add Book form ----------
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { isSubmitting: isAdding }
  } = useForm({
    defaultValues: { title: '', author: '', imageBase64: '' }
  });
  const [addPreview, setAddPreview] = useState(null);

  const onSelectAddImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!isValidImageFile(file)) {
      toast.error('Use JPG/PNG/WebP under ~1.5MB');
      return;
    }
    try {
      const dataUrl = await compressImageFile(file, { maxWidth: 480, quality: 0.8 });
      setValue('imageBase64', dataUrl, { shouldDirty: true });
      setAddPreview(dataUrl);
    } catch {
      toast.error('Could not process image');
    }
  };

  // ---------- Edit Book form (inline per row) ----------
  const {
    register: regEdit,
    handleSubmit: submitEdit,
    setValue: setEditValue,
    formState: { isSubmitting: isSavingEdit }
  } = useForm();
  const [editPreviews, setEditPreviews] = useState({}); // { [id]: dataUrl }

  const onSelectEditImage = (id) => async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!isValidImageFile(file)) {
      toast.error('Use JPG/PNG/WebP under ~1.5MB');
      return;
    }
    try {
      const dataUrl = await compressImageFile(file, { maxWidth: 480, quality: 0.8 });
      setEditPreviews((prev) => ({ ...prev, [id]: dataUrl }));
      setEditValue(`imageBase64_${id}`, dataUrl, { shouldDirty: true });
    } catch {
      toast.error('Could not process image');
    }
  };

  // ---------- Data loaders ----------
  const loadBooks = async () => {
    try {
      const { data } = await api.get('/books');
      setBooks(data);
      setFilteredBooks(data);
    } catch {
      toast.error('Failed to load books');
    }
  };

  useEffect(() => {
    loadBooks();
  }, []);

  // ---------- Actions: Add / Delete / StartEdit / SaveEdit ----------
  const addBook = async (values) => {
    try {
      await api.post('/books', {
        title: values.title,
        author: values.author,
        available: true,
        imageBase64: values.imageBase64 || ''
      });
      toast.success('Book added');
      reset();
      setAddPreview(null);
      loadBooks();
    } catch {
      toast.error('Failed to add book');
    }
  };

  const deleteBook = async (id) => {
    try {
      await api.delete(`/books/${id}`);
      toast.success('Book deleted');
      loadBooks();
    } catch {
      toast.error('Failed to delete book');
    }
  };

  const startEdit = (book) => {
    setEditingId(book.id);
    setEditPreviews((prev) => ({ ...prev, [book.id]: book.imageBase64 || '' }));
    setEditValue(`imageBase64_${book.id}`, book.imageBase64 || '');
  };

  const saveEdit = async (values) => {
    try {
      const id = editingId; // <— critical fix: do NOT read id from a hidden input
      const payload = {
        title: values[`title_${id}`],
        author: values[`author_${id}`]
      };

      // Include image field if present (allow clearing)
      if (values[`imageBase64_${id}`] !== undefined) {
        payload.imageBase64 = values[`imageBase64_${id}`] || '';
      }

      await api.patch(`/books/${id}`, payload);
      toast.success('Book updated');
      setEditingId(null);
      setEditPreviews((prev) => {
        const p = { ...prev };
        delete p[id];
        return p;
      });
      loadBooks();
    } catch {
      toast.error('Failed to update book');
    }
  };

  // ---------- Admin view of borrowings ----------
  const [borrowings, setBorrowings] = useState([]);
  const loadBorrowings = async () => {
    try {
      // NOTE: must be &_expand (not &amp;_expand)
      const { data } = await api.get('/borrowings?_expand=book&_expand=user');
      setBorrowings(data);

      console.log(data);
    } catch {
      /* ignore for now */
    }
  };

  useEffect(() => {
    loadBorrowings();
  }, []);

useEffect(() => {
  const data = books.filter(
    (b) =>
      b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.author.toLowerCase().includes(searchTerm.toLowerCase())
  );
  setFilteredBooks(data);
}, [searchTerm]);

return (
    <>
      <AppNavbar />
      <Container className="py-4">
        <h2 className="mb-3 welcome-sub-title">Admin Dashboard</h2>
        <Row>
          {/* Add Book */}
          <Col md={5}>
            <Card className="mb-4 shadow-sm">
              <Card.Body>
                <Card.Title>Add New Book</Card.Title>
                <Form onSubmit={handleSubmit(addBook)}>
                  <Form.Group className="mb-2">
                    <Form.Label>Title</Form.Label>
                    <Form.Control {...register('title', requiredRule('Title'))} />
                  </Form.Group>

                  <Form.Group className="mb-2">
                    <Form.Label>Author</Form.Label>
                    <Form.Control {...register('author', requiredRule('Author'))} />
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Cover Image</Form.Label>
                    <Form.Control type="file" accept="image/*" onChange={onSelectAddImage} />
                    {/* <Form.Text muted>Stored as compressed Base64 in JSON Server.</Form.Text> */}
                    {/* RHF hidden store for the Base64 value */}
                    <input type="hidden" {...register('imageBase64')} />
                    {addPreview && (
                      <div className="mt-2">
                        <Image src={addPreview} alt="Preview" thumbnail style={{ maxWidth: 160 }} />
                      </div>
                    )}
                  </Form.Group>

                  <Button type="submit" disabled={isAdding}>
                    {isAdding ? 'Adding…' : 'Add Book'}
                  </Button>
                </Form>
              </Card.Body>
            </Card>
          </Col>

          {/* Books Table */}
          <Col md={7}>
            <Card className="mb-4 shadow-sm">
              <Card.Body>
                <Card.Title>Books</Card.Title>
<Form.Control
  type="text"
  placeholder="Search by title or author"
  value={searchTerm}
  onChange={(e) => setSearchTerm(e.target.value)}
  className="mb-3"
/>

                <Form onSubmit={submitEdit(saveEdit)}>
                  <Table responsive bordered size="sm" className="align-middle">
                    <thead>
                      <tr>
                        <th style={{ width: 120 }}>Cover</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Availability</th>
                        <th style={{ width: 240 }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredBooks.map((b) => (
                        <tr key={b.id}>
                          <td>
                            {editingId === b.id ? (
                              <>
                                {editPreviews[b.id] ? (
                                  <Image
                                    src={editPreviews[b.id]}
                                    alt="Preview"
                                    thumbnail
                                    style={{ width: 72, height: 100, objectFit: 'cover' }}
                                  />
                                ) : (
                                  <span className="text-muted d-block mb-2">No image</span>
                                )}
                                <Form.Control
                                  type="file"
                                  accept="image/*"
                                  onChange={onSelectEditImage(b.id)}
                                  className="mt-2"
                                />
                                {/* RHF hidden field to hold Base64 value */}
                                <input type="hidden" {...regEdit(`imageBase64_${b.id}`)} />
                              </>
                            ) : b.imageBase64 ? (
                              <Image
                                src={b.imageBase64}
                                alt={`${b.title} cover`}
                                thumbnail
                                style={{ width: 56, height: 80, objectFit: 'cover' }}
                              />
                            ) : (
                              <span className="text-muted">No image</span>
                            )}
                          </td>

                          <td>
                            {editingId === b.id ? (
                              <Form.Control defaultValue={b.title} {...regEdit(`title_${b.id}`)} />
                            ) : (
                              b.title
                            )}
                          </td>

                          <td>
                            {editingId === b.id ? (
                              <Form.Control defaultValue={b.author} {...regEdit(`author_${b.id}`)} />
                            ) : (
                              b.author
                            )}
                          </td>

                          <td>
                            <Badge bg={b.available ? 'success' : 'secondary'}>
                              {b.available ? 'Available' : 'Unavailable'}
                            </Badge>
                          </td>

                          <td className="table-button-input">
                            {editingId === b.id ? (
                              <>
                              <div className="table-button">
                                 <input type="hidden" {...regEdit('id')} value={b.id} readOnly />
                                 <Button size="sm" type="submit" variant="success">Save</Button>
                                <Button
                                  size="sm"
                                  type="button" 
                                  variant="outline-secondary"
                                  onClick={() => {
                                    setEditingId(null);
                                    setEditPreviews((prev) => {
                                      const p = { ...prev };
                                      delete p[b.id];
                                      return p;
                                    });
                                  }}
                                >
                                  Cancel
                                </Button>
                                </div>
                              </>
                            ) : (
                              <>
                              <div className="table-button">
                                <Button size="sm"  type="button" variant="warning" onClick={() => startEdit(b)}>
                                  Edit
                                </Button>
                                <Button size="sm"  type="button"  variant="danger" onClick={() => deleteBook(b.id)}>
                                  Delete
                                </Button>
                                </div>
                              </>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Form>
              </Card.Body>
            </Card>

            <Card className='shadow-sm'>
              <Card.Body>
                <Card.Title>All Borrowings</Card.Title>
                <Table responsive bordered size="sm">
                  <thead>
                    <tr>
                      <th>User Id</th>
                      <th>User Name</th>
                      <th>Book Title</th>
                      <th>Borrow Date</th>
                      <th>Return Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {borrowings.map((br) => (
                      <tr key={br.userId}>
                        <td>{br.userId}</td>
                        <td>{br.userName}</td>
                        <td>{br.bookTitle}</td>
                        <td>{br.borrowDate}</td>
                        <td>{br.returnDate || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Dashboard;
