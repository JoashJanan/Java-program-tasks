import React, { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../services/api';
import { toast } from 'react-toastify';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem('lms_user');
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) localStorage.setItem('lms_user', JSON.stringify(user));
    else localStorage.removeItem('lms_user');
  }, [user]);

  const login = async ({ email, password }) => {
    setLoading(true);
    try {
      const { data } = await api.get(`/users`, {
        params: { email, password }
      });
      if (data?.length === 1) {
        setUser(data[0]);
        toast.success('Logged in successfully');
        return data[0];
      } else {
        toast.error('Invalid credentials');
        return null;
      }
    } catch (e) {
      toast.error('Login failed. Try again.');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const register = async ({ name, email, password, role }) => {
    setLoading(true);
    try {
      // check if email exists
      const { data: existing } = await api.get('/users', { params: { email } });
      if (existing.length > 0) {
        toast.error('Email already in use');
        return null;
      }
      const { data: newUser } = await api.post('/users', {
        name,
        email,
        password,
        role: role || 'member'
      });
      toast.success('Registration successful. Please login.');
      return newUser;
    } catch (e) {
      toast.error('Registration failed');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    toast.info('Logged out');
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
