export const emailRules = {
    required: 'Email is required',
    pattern: {
      value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      message: 'Enter a valid email'
    }
  };
  
  export const passwordRules = {
    required: 'Password is required',
    minLength: { value: 6, message: 'At least 6 characters' }
  };
  
  export const nameRules = {
    required: 'Name is required',
    minLength: { value: 2, message: 'At least 2 characters' }
  };
  
  export const requiredRule = (field) => ({
    required: `${field} is required`
  });
  