// src/utils/image.js
export const fileToDataUrl = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
  
  export const compressImageFile = (file, { maxWidth = 480, quality = 0.8, outputType = 'image/jpeg' } = {}) =>
    new Promise((resolve, reject) => {
      try {
        const img = new Image();
        img.onload = () => {
          const scale = Math.min(1, maxWidth / img.width);
          const targetW = Math.round(img.width * scale);
          const targetH = Math.round(img.height * scale);
          const canvas = document.createElement('canvas');
          canvas.width = targetW;
          canvas.height = targetH;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, targetW, targetH);
          const dataUrl = canvas.toDataURL(outputType, quality);
          resolve(dataUrl);
        };
        img.onerror = () => reject(new Error('Invalid image'));
        const fr = new FileReader();
        fr.onload = () => { img.src = fr.result; };
        fr.readAsDataURL(file);
      } catch (e) {
        reject(e);
      }
    });
  
  export function isValidImageFile(file, { maxSizeMB = 1.5 } = {}) {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    const tooBig = file.size > maxSizeMB * 1024 * 1024;
    return allowed.includes(file.type) && !tooBig;
  }
  