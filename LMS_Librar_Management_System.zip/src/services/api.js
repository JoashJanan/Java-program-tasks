import axios from 'axios';

const API_URL =  'http://localhost:5000';

export const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' }
});

// Optional: attach interceptors for logging
api.interceptors.response.use(
  (res) => res,
  (err) => {
    // You can centralize error handling here if desired
    return Promise.reject(err);
  }
);
