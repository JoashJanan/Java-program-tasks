package com.taskmanagementsystemupdate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskmanagementsystemupdateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskmanagementsystemupdateApplication.class, args);
	}

}
