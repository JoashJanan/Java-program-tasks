1.Difference between HashMap and ConcurrentHashMap?
The HashMap is non-thread-safe and can not be used in a Concurrent multi-threaded environment.
Comparatively, ConcurrentHashMap is a thread-safe and specially designed for use in multi-threaded and Concurrent environment.
2.Program: Find smallest number and Bigger number from Array?
3.Datasource?
A DataSource is an interface in Java used to manage database connections efficiently. 
Instead of using DriverManager (which creates a new connection every time), 
DataSource helps in connection pooling, meaning it reuses connections, making applications faster and more scalable.
4.Stream API?Process the collection of objects.
5.Difference between Volatile and transient ?
6.Java 8 features(stream api,lamda,interface(default,static))
7.diff in interface(core java and java8)
8.Program:Anagram program
9.how to create api?
10.explain REST API and SOAP?
Feature	           REST	                                         SOAP
Protocol	Architectural style (uses HTTP/HTTPS)	       Protocol (uses XML-based messaging)
Data Format	JSON (mostly) or XML	                       XML
Complexity	Simple, lightweight, easy to use	           More complex, with strict rules
State	    Stateless (each request is independent)	       Can be stateful (tracks state across requests)
Security	Basic security through HTTPS	               Built-in security features (e.g., WS-Security)
Performance	Faster (due to lighter payloads, e.g., JSON)   Slower (due to XML, more overhead)
Use Cases	Web apps, mobile apps, public APIs	           Enterprise applications, banking, secure transactions

11.The SOAP approach is highly structured and uses XML data format ?
12.REST is more flexible and allows applications to exchange data in multiple formats.
13.bean scope?single ton?
What it is: A bean with singleton scope is created once for the entire Spring container. That means only one instance of the bean exists in the Spring context.

When it’s used: This is the most common scope used in Spring because it's efficient and ensures that the same bean is shared across the entire application.

Lifecycle: The bean is created when the Spring container is initialized (during the application startup) and is destroyed when the container is shut down.


14.abstraction and encapsulation usage in realtime program?car and Bag
15.get() and post()
16.json and xml?which one effective?
17.what is microservices?
18.exception?Interrupt the normal flow of execution.Using try-catch we can handle the exception.
Is it possible to handle 3 type of exception in try and catch? ex:(normal,Insufficient,Filenotfound)
19.what are the you handled in you project which file you used?
20.Program:print 2nd largest element array in java
21.stream API intermediate and terminate?
22.spring Annotation?
23.spring security?oauth and jwttoken?
Sure! **JSON Web Token (JWT)** is a compact, self-contained way to securely transmit information between parties. It consists of **three parts**, separated by dots (`.`):

### **JWT Structure**
1. **Header** 🏷️
   - Contains metadata about the token.
   - Specifies the **algorithm** used for signing (e.g., `HS256`, `RS256`).
   - Example:
     ```json
     {
       "alg": "HS256",
       "typ": "JWT"
     }
     ```
   - This JSON is **Base64Url encoded** to form the first part of the JWT.

2. **Payload** 📦
   - This is the main content—it holds user details or claims.
   - Could store things like username, roles, expiration time, etc.

   - Example:
     ```json
     { "sub": "user123", "name": "John Doe", "admin": true, "exp": 1718502400 }
     ```
   - This JSON is **Base64Url encoded** to form the second part of the JWT.

3. **Signature** 🔏
  - Ensures nobody has modified the token after creation.
  - Created using a secret key, combining header + payload, then encrypting.

   - Example (using HMAC SHA256):
     ```
     HMACSHA256(
       base64UrlEncode(header) + "." + base64UrlEncode(payload),
       secret
     )
     ```
   - This forms the third part of the JWT.

### **Final JWT Format**
A JWT looks like this:

xxxxx.yyyyy.zzzzz

24.microservice?
25.springboot exception handling?
26.Jpa and hibernate difference?
JPA sets the guidelines while Hibernate provides the actual code to store and retrieve data from the database.
- JPA is just a set of rules (a specification) that says how Java objects should be stored in a database.
- Hibernate is a tool (a framework) that follows JPA’s rules and actually does the work.

- JPA = Rules (Defines how ORM should work)
- Hibernate = Implementation (Actually does the ORM work)

27.request param and path param?
28.spring profile?
# application.properties
server.port=8080
spring.profiles.active=dev

# application-dev.properties
server.port=8081

29.detail in kafka in microservice?
30.detail in circuit breaker and saga pattern?
31.circuit breaker architecture?
How It Works
- Normal Operation (Closed State): Requests flow normally when the service is healthy.
- Failure Detection (Open State): If failures exceed a threshold, the circuit breaker trips and blocks further requests.
- Recovery Check (Half-Open State): After a cooldown period, a few test requests are allowed to check if the service is back online.
- Reset (Closed State): If the service responds successfully, the circuit breaker resets and resumes normal operation

32.spring profiles explanation where we are used?
33.transient keyword in code where we are used?
34.HashMap difference in core java and java8?
- Handling Collisions:
- Java 7: Uses a linked list to store multiple entries in the same bucket, leading to O(n) complexity in worst-case scenarios.
- Java 8: Introduces balanced trees (Red-Black Trees) when collisions exceed a threshold (TREEIFY_THRESHOLD = 8), improving worst-case complexity to O(log n).

Java8 have a so many in-built methods like map(),sorted(),ifPresent....But earlier java dont have a in-built methods.

35.flat map?
import java.util.*;
import java.util.stream.Collectors;

class Employee {
    String name;
    List<String> skills;

    Employee(String name, List<String> skills) {
        this.name = name;
        this.skills = skills;
    }

    public List<String> getSkills() {
        return skills;
    }
}

public class FlatMapCustomExample {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("Alice", Arrays.asList("Java", "Spring")),
            new Employee("Bob", Arrays.asList("Docker", "Kubernetes")),
            new Employee("Charlie", Arrays.asList("AWS", "Kafka"))
        );

        List<String> allSkills = employees.stream()
            .flatMap(emp -> emp.getSkills().stream())
            .collect(Collectors.toList());

        System.out.println(allSkills);
    }
}
36.@qualifier what and where we used?
37.Design pattern?
- Creational Patterns – Help create objects efficiently (e.g., Singleton, Factory).
- Structural Patterns – Define relationships between objects to make code more flexible (e.g., Adapter, Composite).
- Behavioral Patterns – Focus on communication between objects (e.g., Observer, Strategy).

38.Singleton pattern
39.explain Agile methodology ?
40.how handling the conflict in your team?
  1.Stay Calm and Focused on Solutions
  2.Stay Neutral and Be a Mediator
  3.Address Conflicts Early
  4.Encourage Open Communication
41.monolothic vs microservices?
42.custom exception handson?
A custom exception in Java is a user-defined exception that extends either Exception (for checked exceptions) or RuntimeException (for unchecked exceptions). It helps handle specific application errors in a meaningful way.
Step 1: Create a Custom Exception Class
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}

step 2:Handle the Exception Globally with @ControllerAdvice
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<String> handleResourceNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }

    @ExceptionHandler(Exception.class)


43.Program:Repeated chars using stream api-handson?
44.java 8 features?
45.Program:Find the second highest salary from the list of object using stream and sql query-handson?
46.Spring Security?
Spring Security is a powerful framework that provides authentication, authorization, and protection for web applications in Spring.

47.Multithreading -Runnable vs Callable?
48.Lifecycle of threads?
[ New ] → [ Runnable ] → [ Running ] → [ Waiting/Timed Waiting/Blocked ] → [ Terminated ]
New -> When a thread is created but hasn’t started yet.
Runnable -> The thread is ready to run and waiting for CPU allocation.
Blocked ->The thread is waiting for another thread to release a lock.
Waiting -> The thread is waiting indefinitely for another thread to signal it.
Timed Waiting ->The thread waits for a specified time before resuming execution.
Terminated -> The thread has finished execution or has been stopped.

49.Class overloading?
50.what are the java versions you used and the features of it?
51.struct,spring and springBoot.Compare this why springboot is more popular?

### **Comparison Table**
| Feature          | Structs (C/C++)             | Spring (Java)                      | Spring Boot (Java) |
|----------------|----------------|--------------|----------------|----------------------------------------------
| **Purpose**   | Groups variables in C/C++      | Java framework for enterprise apps | Simplifies Spring framework |
| **Complexity** | Simple, but manual management | Complex, requires lots of setup    | Easy, automatic configuration |
| **Flexibility** | Limited to structured data   | Highly flexible for web & backend  | Adds auto-configuration & microservices support |
| **Use Case**  | Memory-efficient data grouping | Large Java applications            | Rapid development with built-in tools |

### **Why is Spring Boot More Popular?**
✅ **Easy to Use** → No need for complex XML configurations.  
✅ **Built-in Features** → Embedded servers (Tomcat, Jetty), making deployment easier.  
✅ **Microservices Ready** → Ideal for modern cloud applications.  
✅ **Fast Development** → Less boilerplate code, making coding quicker.  

52.Which design pattern is trending now?
53.what is the method overloading and over riding?
54.how to auto boxing and unboxing works in java with a code?
55.what is the difference between sql and nosql DB and which scenario will you use it?
Great question! **SQL and NoSQL databases** serve different purposes based on their structure and scalability.

### **Key Differences**   
| Aspect         |                                     SQL (Relational) |              NoSQL (Non-relational) |
|--------------|----------------|------------------|------------------------------------------------------------------
| **Data Structure** |                       Tables with rows & columns | Document-based, key-value, column-family, or graph-based |
| **Schema** |                      Fixed schema (predefined structure) | Flexible schema (dynamic and adaptable) |
| **Scalability** |            Vertically scalable (upgrading hardware) | Horizontally scalable (adding more servers) |
| **Data Integrity** |              ACID-compliant (strong consistency) | BASE-compliant (more available, less consistent) |
| **Query Language** |                  SQL (Structured Query Language) | Varies (e.g., MongoDB uses its own query language) |
| **Performance** |        Efficient for complex queries & transactions | Better for large-scale data & fast read/write operations |
| **Use Case** |    Best for transactional systems (banking, ERP, etc.) | Ideal for big data, real-time web apps, and data lakes |
| **Examples** |               MySQL, PostgreSQL, Oracle, MS SQL Server | MongoDB, Cassandra, CouchDB, Neo4j |



56.what is the microservice and why do we use it?
57.Team handling of exsisting projects?
58.Program:Second largest int value in the given list of values using stream API?
59.Program:To get a character which is most repeated more than once in the given string using java stream API?
60.Program:To get an employee from a list of employees using stream API by filtering a name?
61.What is embedded server in springboot?
62.how to change one server to another server in springboot?
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
    <exclusions>
        <exclusion>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-tomcat</artifactId>
        </exclusion>
    </exclusions>
</dependency>
63.microservice architecture:
64.zookeeper uses in microservice version?it is required or not?
- ZooKeeper 3.5.x and 3.6.x support Java 8.
- Yes, if your microservices need dynamic service discovery, distributed coordination, or leader election.(Kafka)
- No, if you're using alternatives like Kubernetes, Consul, or Netflix Eureka, which offer similar functionalities.(Docker)

65.microservice full explain?
66.kafka explain and version are you used?- Kafka 3.x versions support Java 8.
67.springboot and java version? - Spring Boot 2.x versions (like 2.5, 2.6, 2.7)
68.restapi security in your project?
69.JWT token?
70.tomcat server deployment?
71.java fully Object oriented?No, because it have a primittive ,static and garbage collector.
72.object creation method? ==> new keyword,clone(),class.forName().
73.Abstraction and interface?
74.Java8 features?
75.Functional interface?
76.row set and result set?
Use ResultSet when working directly with a database.
Use RowSet when you need offline access or caching.
77.iterator and list iterator?
78.drop,delete and truncate?
79.Rollback,commit?
- Commit saves changes permanently.
- Rollback cancels changes to maintain consistency.
80.Springboot object creation?
81.generator()?It will generate unique next values in table.
 public static void main(String[] args) {
        NumberGenerator generator = new NumberGenerator();
        System.out.println(generator.next()); // 1
        System.out.println(generator.next()); // 2
        System.out.println(generator.next()); // 3
    }

82.Overriding?overloading?
83.String is immutable why?
84.In interface ,what is the purpose of default method?
85.maven?
- Simplifies project setup and dependency handling.
- Ensures consistency across development environments.
- Supports integration with various IDEs like Eclipse and IntelliJ.

86.rest API?controller?
87.how to create the api?
88.dependency injection?
89.spring mvc?
90.sonar qube?
It is a software.It acts like a "code quality checker" for Java (and other programming languages). 
It analyzes your code,gives feedback on any potential problems, and helps you improve the overall quality, readability, and security of your code.
91.solid design?
92.Junit?JUnit is a framework for writing and running tests in Java to ensure code quality and correctness.

import org.junit.Assert;
import org.junit.Test;

class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
}

public class CalculatorTest {
    @Test
    public void testAddition() {
        Calculator calculator = new Calculator();
        int result = calculator.add(2, 3);
        Assert.assertEquals(5, result);
    }
}
- @Test Annotation: Marks the method as a test case.
- Assertions (Assert.assertEquals): Verifies expected vs. actual results.
- Test Execution: Running this test ensures the add() method works correctly.

93.CICD pipeline?

### **Steps in a Java CI/CD Pipeline**
1. **Version Control** → Developers push code to a repository (e.g., GitHub, GitLab).
2. **Build Automation** → Tools like **Maven** or **Gradle** compile the code.
3. **Automated Testing** → Unit tests and integration tests run using **JUnit** or **TestNG**.
4. **Code Quality Checks** → Tools like **SonarQube** analyze code for bugs and vulnerabilities.
5. **Containerization** → Docker packages the application for deployment.
6. **Deployment** → CI/CD tools like **Jenkins, GitHub Actions, or GitLab CI/CD** deploy the app.

🧪 Example Flow
- 👨 Developer pushes code to GitHub
- ⚙️ Jenkins detects the change and starts a build
- 🧪 JUnit tests run automatically
- 📦 Build artifacts are created (e.g., Docker image)
- 🚀 Code is deployed to staging
- ✅ After approval, it’s deployed to production


94.program:how you return salary details from employee table based on department?
95.Insert query?
96.program, In one sentence have to print the position of vowels?using java code
97.List,set and map which one is effective?
98.drawbacks of map?
99.autowired internal flow?
100.recursion internal flow?
Recursion is a technique where a function calls itself until a base condition is met. 
- Function Call – The recursive function is invoked with an initial argument.
- Base Case Check – If the base condition is met, recursion stops and returns a value.
- Recursive Case Execution – If the base case is not met, the function calls itself with a modified argument.
- Stack Frame Creation – Each recursive call creates a new stack frame, storing local variables and execution state.
- Returning Values – Once the base case is reached, the function starts returning values back up the call stack.
- Stack Unwinding – The recursive calls resolve one by one, returning results to the previous function calls.

101.Program:write a program using restapi retrive the employee id and update the employee details in controller part?
102.what are the challanges you faced in 5 yrs experience?
 Common challenges with legacy code:
- Poor documentation: Hard to understand what the code does.
- Tightly coupled logic: Everything is interconnected, making changes risky.
- No automated tests: You can't easily verify if changes break something.

103.Anonymous class in java?
When you create an anonymous class, you don’t explicitly declare a separate class, but instead, define its behavior inline.
Excellent observation — and you're right to question that! Let's clarify how **anonymous classes** work in Java and why it's valid to create them using an **interface** or an **abstract class**, not just a regular class.

---

### 🔍 What You're Thinking:
> “Anonymous class means we create an object using a class name, so how can we use an interface?”

That’s a common confusion — but here’s the key:

---

### ✅ Anonymous Class Can Be Based On:
- **An interface**
- **An abstract class**
- **A concrete class**

You're not creating an object of the interface itself — you're creating an object of a **new unnamed class** that **implements** the interface or **extends** the class.

---

### 🧪 Example with Interface

```java
interface Animal {
    void sound();
}

Animal dog = new Animal() {
    public void sound() {
        System.out.println("Woof!");
    }
};
```

Here:
- `new Animal() { ... }` creates an **anonymous class** that implements `Animal`.
- You're not instantiating `Animal` directly — you're creating a subclass on the fly.

---

### 🧪 Example with Abstract Class

```java
abstract class Bird {
    abstract void fly();
}

Bird eagle = new Bird() {
    void fly() {
        System.out.println("Flying high!");
    }
};
```

Same idea — you're creating a subclass of `Bird` without naming it.

---

### 🧠 Summary

| Base Type       | Can Use Anonymous Class? | Why?                          |
|-----------------|--------------------------|--------------------------------|
| Interface       | ✅ Yes                   | Implements methods inline      |
| Abstract Class  | ✅ Yes                   | Extends and overrides methods  |
| Concrete Class  | ✅ Yes                   | Extends and customizes behavior|

So yes — it's totally valid to use an interface as the base for an anonymous class. You're not creating an object of the interface, you're creating an object of a class that **implements** it.

104.Authencation authorization in simple way?
Authentication = Login verification.
Authorization = Role-based access control.
105.Projection in springBoot?
In Spring Boot, projection is used to retrieve specific fields from an entity rather than fetching the entire object.
This improves performance by reducing unnecessary data retrieval from the database.

106.What is the projection?
Streams API (Functional Projection)
You can use Java Streams to project certain attributes from a collection:
 List<String> groceryNames = groceries.stream()
            .map(Grocery::getName)  // Selecting only names //Its projecting 
            .collect(Collectors.toList());
			
107.logging in springboot application?
Logging in a Spring Boot application is crucial for tracking application behavior and debugging issues.

108.@Transactional in springboot?
In Spring Boot, @Transactional is an annotation used to manage transactions efficiently.
It ensures that operations within a method execute as a single unit, so if one operation fails, all changes are rolled back.

Great! Let's break down the **main keys (attributes)** of the `@Transactional` annotation in Spring Boot — in a simple and clear way 🧠✨

---

## ✅ Common Keys in `@Transactional`

| Key               | What It Does                                                                 |
|------------------|------------------------------------------------------------------------------|
| `readOnly`        | If `true`, marks the transaction as **read-only** (no updates allowed).     |
| `rollbackFor`     | Specifies which **checked exceptions** should trigger a rollback.           |
| `noRollbackFor`   | Specifies which exceptions **should NOT** trigger a rollback.               |
| `propagation`     | Defines how transactions behave when calling another transactional method.  |
| `isolation`       | Controls how data is **isolated** between transactions (e.g., dirty reads). |
| `timeout`         | Sets how long (in seconds) the transaction can run before timing out.       |

---

## 🧪 Example Usage

```java
@Transactional(
    readOnly = false,
    rollbackFor = Exception.class,
    propagation = Propagation.REQUIRED,
    isolation = Isolation.READ_COMMITTED,
    timeout = 30
)
public void processTransaction() {
    // your logic here
}
```

---

### 🧠 Simple Explanation of Each Key

- **`readOnly = true`** → Use for read-only operations like reports or queries.
- **`rollbackFor = Exception.class`** → Roll back even for checked exceptions.
- **`noRollbackFor = CustomException.class`** → Don’t roll back for specific exceptions.
- **`propagation = REQUIRED`** → Join existing transaction or start a new one.
- **`isolation = READ_COMMITTED`** → Prevent reading uncommitted data from other transactions.
- **`timeout = 30`** → Cancel the transaction if it takes more than 30 seconds.

---

Would you like help choosing the best settings for a banking or shopping app scenario?

@Transactional(propagation = Propagation.REQUIRED)
public void transferFunds() {
    // debit and credit logic
    logTransaction(); // joins the same transaction
}

@Transactional(propagation = Propagation.REQUIRES_NEW)
public void logTransaction() {
    // writes to audit table
}


- If logTransaction() fails:
- With REQUIRED: it rolls back the whole transfer.
- With REQUIRES_NEW: only logging rolls back, transfer stays safe.


109.stereotypes in java?
In Java, stereotypes are used in frameworks like Spring and CDI (Contexts and Dependency Injection) to define the role of a class in an application.
Spring Stereotypes
Spring provides stereotype annotations to categorize components:
- @Component – Generic annotation for any Spring-managed bean.
- @Service – Indicates a service layer component.
- @Repository – Marks a data access object (DAO).
- @Controller – Defines a web controller in Spring MVC.

These annotations help Spring automatically detect and manage beans in the application context.
CDI Stereotypes
In Java EE/CDI, stereotypes allow grouping multiple annotations into one:
- They define a default scope for beans.
- They can include interceptor bindings.
- They may use @Named for default EL naming.

110.When to use @EnableScan?
- If you query using a partition key(like a primary key), you don’t need @EnableScan.
- If you query using a non-partition key (e.g., searching by name instead of ID), you must use @EnableScan.

@EnableScan
public interface EmployeeRepository extends CrudRepository<Employee, String> {
    List<Employee> findByFirstName(String firstName);
}

111.What is reduce() in Java?
The reduce() function is used to combine all elements of a list into a single value. 
Think of it like shrinking a list into one result by applying a mathematical or logical operation.

List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
int sum = numbers.stream().reduce(0, (a, b) -> a + b);
System.out.println(sum); // Output: 15


112.Types of repository in spring boot?
- Use CrudRepository for simple CRUD operations.
- Use PagingAndSortingRepository when you need to paginate or sort results.
- Use JpaRepository for advanced JPA features like batch operations or flushing.
- Use ListCrudRepository if you prefer working with List over Iterable.
- Use ListPagingAndSortingRepository when you want both pagination and List return types.

113.Enable cache in spring boot?
Enabling caching in Spring Boot helps improve performance by storing frequently accessed data.

@Cacheable ==> Using this retrive the data from cache.
@CacheEvict ==> to remove cached data when needed:

114.Other way of Component scan?
In Spring Boot, **component scanning** is used to automatically detect and register beans. Apart from the default `@ComponentScan`, here are other ways to scan components:

### **1. Using `@SpringBootApplication` (Default)**
Spring Boot automatically scans components in the same package as the main class.
```java
@SpringBootApplication
public class MyApp {
    public static void main(String[] args) {
        SpringApplication.run(MyApp.class, args);
    }
}
```
This scans all components in the package of `MyApp`.

### **2. Using `@ComponentScan` with Specific Packages**
You can manually specify packages to scan:
```java
@ComponentScan(basePackages = {"com.example.service", "com.example.repository"})
public class AppConfig {
}
```
This scans only the specified packages.

### **3. Using `@ComponentScan` with Filters**
You can filter components based on annotations or classes:
```java
@ComponentScan(includeFilters = @Filter(type = FilterType.ANNOTATION, classes = MyCustomAnnotation.class))
public class AppConfig {
}
```
This scans only components annotated with `@MyCustomAnnotation`.

### **4. Scanning Components from External JARs**
If components are in a different module or JAR, specify their package explicitly:
```java
@ComponentScan(basePackages = {"com.external.module"})
public class AppConfig {
}
```

115. Controller DDOS in springboot?
To prevent DDoS (Distributed Denial of Service) attacks in a Spring Boot controller, 
you can implement rate limiting to restrict excessive requests from a single source.

==>Using Bucket4j for Rate Limiting
Bucket4j is a Java library that helps limit requests per IP.
- Limits requests to 100 per minute.
- Returns HTTP 429 (Too Many Requests) if the limit is exceeded.

==>Using Spring Boot Throttling
Another approach is using Spring Boot Throttling, which allows limiting requests per user or IP.

==> Using Web Server Rate Limiting
- Configure Nginx or Apache to limit requests per IP.
- Use Cloudflare or AWS WAF for DDoS protection.

116.- How can organizations protect against DDoS attacks?
- Using firewalls, rate limiting, cloud-based DDoS protection, and traffic filtering.

117.BOT attacks? 
Bot attacks are when automated programs (bots) are used to steal data, break into accounts, or overwhelm websites with fake traffic.
Bot attacks in Java often involve automated malicious requests targeting web applications, APIs, or services. A common real-time example is DDoS (Distributed Denial of Service) attacks, where bots flood a server with requests, causing it to slow down or crash.

118.Client side and Server side load balancing ?
Load balancing helps distribute website traffic evenly so no single server gets overloaded. 

### **Client-Side Load Balancing**  
The **user’s device** decides where to send the request. It picks a server based on available options.  
🔹 Example: Your web browser checks a list of servers and picks one randomly to load a website.

### **Server-Side Load Balancing**  
The **server** decides where to send the request. A load balancer distributes incoming traffic to different servers.  
🔹 Example: When you visit an online store, a load balancer sends your request to the least busy server, ensuring smooth performance.

119.consul can we consider client side balancing ?
Yes, Consul, a popular service discovery and networking tool, supports client-side load balancing by providing information about available services.

120.what is the consul in microservices?
Consul is a service networking tool used in microservices architecture to help services communicate efficiently. It provides:
🔹 Service Discovery – Helps microservices find and connect with each other dynamically.
🔹 Health Checks – Monitors services to ensure they are running properly.
🔹 Load Balancing – Distributes traffic among multiple service instances.
🔹 Service Mesh – Secures communication between services using encryption and authentication.

121.Difference between api gate way and load balancing ?
API Gateway :When you use an app, an API gateway ensures your request goes to the correct service (like login or search).
Load Balancer : When a website gets high traffic, a load balancer spreads users across multiple servers to keep it running smoothly.

In short, API gateways manage API requests, while load balancers distribute network traffic efficiently.

122.Leaky bucket rate limiter?
A leaky bucket rate limiter helps control the flow of requests to prevent system overload.
It processes requests at a steady rate, allowing extra traffic to "leak" out slowly instead of overwhelming the system.

Where to Configure Leaky Rate Limit?
- API Gateway – Often configured in tools like Kong, NGINX, or AWS API Gateway.
- Load Balancer – Some load balancers support rate limiting for incoming traffic.
- Application Code – Implemented directly using libraries in frameworks like Express.js, Spring Boot, or Django.
- Middleware – Applied in request-handling layers like Redis or Envoy Proxy for better control.

123. Token and leaky bucket in microservices?
In microservices, tokens and the leaky bucket algorithm are used for security and rate limiting.
Token:JWT (JSON Web Token) allows a microservice to verify if a request is coming from an authorized user.
Use Case: A payment service in microservices requires a valid token before processing any transaction.

Leaky Bucket :A leaky bucket controls the rate of incoming requests to prevent overload.
🔹 Requests enter the bucket, but only leak out at a steady rate to avoid spikes.
🔹 Example: An API receiving too many requests uses leaky bucket to process only a few at a time and prevent crashes.

124. API Security:
API security is crucial for protecting data and services from cyber threats. Here are some major building blocks of API security:

🔹 **Authentication & Authorization** – Ensuring only authorized users can access APIs using methods like OAuth, JWT, and API keys.  
🔹 **Rate Limiting & Throttling** – Preventing abuse by limiting the number of requests a user can make in a given time.  
🔹 **Encryption** – Securing data in transit and at rest using HTTPS and TLS.  
🔹 **Input Validation** – Preventing attacks like SQL injection by validating user inputs.  
🔹 **Logging & Monitoring** – Tracking API activity to detect suspicious behavior.  
🔹 **Access Control** – Restricting API access based on roles and permissions. 

125.How do you ensure that a message is successfully delivered in Kafka?

✅ Message Confirmations (acks=all) → Kafka waits until all backup copies of the message are stored before confirming delivery.
✅ Backup Copies (replication.factor) → Each message is stored on multiple Kafka servers, so even if one crashes, data is safe.
✅ Automatic Retries (retries=n) → If a message fails to send, Kafka tries again automatically.
✅ Preventing Duplicates (enable.idempotence=true) → Ensures no message gets sent twice accidentally.
✅ Consumer Tracking (auto-offset-reset) → Keeps a bookmark of processed messages, so if a system restarts, it resumes from the last message.

application.properties:
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.producer.acks=all
spring.kafka.producer.retries=5
spring.kafka.producer.enable-idempotence=true
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer
spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerializer
  
126.Can you explain the Kafka architecture you are using in producer and consumer console?
 Producer → Sends messages (data) to Kafka topics.
✅ Broker → Kafka server that stores and manages messages.
✅ Topic → Logical grouping of messages.
✅ Partitions → Topic is divided into partitions for scalability.
✅ Consumer → Reads messages from topics.
✅ Zookeeper → Managing metadata, coordinating brokers, and ensuring fault tolerance.

Producer Console Workflow
- The producer uses the Kafka Producer API to send messages like this:
bin/kafka-console-producer.sh --broker-list localhost:` --topic my_topic

Consumer Console Workflow
- Consumers read messages using:
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic my_topic --from-beginning

127.How do you replay messages from a Kafka topic?

✅ `--from-beginning`: Reads messages **from the start**  

bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic my_topic --from-beginning
 

✅ **Reset consumer offsets** to restart from the earliest message  

bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --group my_consumer_group --reset-offsets --to-earliest --execute
 

✅ **Seek manually in code**  

consumer.seek(new TopicPartition("my_topic", 0), 0);
 
128.How do you implement a retry mechanism in Kafka?
- The Kafka Producer can automatically retry sending messages if failures occur.
- Configure retries in the producer properties:
Properties props = new Properties();
props.put("bootstrap.servers", "localhost:9092");
props.put("retries", 3);  // Retries sending the message up to 3 times
props.put("acks", "all");  // Ensures all 

Consumer Retries Using Dead Letter Queues (DLQ)
- If a consumer fails to process a message, instead of discarding it, you send it to a Dead Letter Queue (DLQ).
- Later, you can reprocess DLQ messages:
try {
    processMessage(record);
} catch (Exception e) {
    sendToDLQ(record);  // Moves unprocessed messages to a separate topic
}


✅ Prevents message loss and allows later retries.

129.What is a heap memory error?
A heap memory error happens when there is an issue with memory allocation in the heap, which is the area of memory used for dynamically allocated objects in a Java program.
1.OutOfMemoryError
2.Memory Leak 
3.Excessive Garbage Collection

130.What is an out-of-memory error?
An OutOfMemoryError in Java occurs when the Java Virtual Machine (JVM) runs out of heap memory and cannot allocate more space for objects.

131.what is executorservice in java(why it is used)?
- Thread Pooling: Reduces overhead by reusing threads instead of creating new ones for each task.
- Future & Callable Support: Enables retrieving results from asynchronous tasks using Future.

ExecutorService executor = Executors.newFixedThreadPool(10);

132.Consider a redbus how many restapi you will create ?

POST /users/register       - Register new users
POST /users/login         - User authentication
GET /buses/search        - Search buses based on criteria
GET /buses/{id}/seats    - Get available seats for a bus
POST /booking            - Book a seat
GET /booking/{id}        - Get booking details
POST /payment/process    - Handle payments
DELETE /booking/{id}     - Cancel a booking

133.Insteadof autowired which one is suitable?
- If using Spring, @Autowired or constructor-based injection is recommended.
- For Jakarta EE-based projects, @Inject or @Resource is better.
- Constructor-based injection is preferred for unit testing and maintaining immutability.

134. spring security ?how to secure based on the role?

- Location: src/main/java/com/example/config/SecurityConfig.java

- This class automatically configures user authentication for your project.
- Spring Security will use this UserDetailsService to authenticate users.


import org.springframework.context.annotation.Bean;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Bean
public UserDetailsService userDetailsService() {
    UserDetails admin = User.withUsername("admin")
                            .password(new BCryptPasswordEncoder().encode("admin123"))
                            .roles("ADMIN")  // Assign "ADMIN" role
                            .build();

    UserDetails user = User.withUsername("user")
                           .password(new BCryptPasswordEncoder().encode("user123"))
                           .roles("USER") // Assign "USER" role
                           .build();

    return new InMemoryUserDetailsManager(admin, user);
}


package com.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration  // Marks this class as a configuration class
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/admin/**").hasRole("ADMIN")  // Only ADMIN can access /admin
                .requestMatchers("/user/**").hasAnyRole("USER", "ADMIN")  // USER & ADMIN can access /user
                .anyRequest().authenticated()  // Everything else needs authentication
            )
            .formLogin();  // Enable default login page
        return http.build();
    }
}

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/dashboard")
    public String adminDashboard() {
        return "Welcome, Admin!";
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/user/profile")
    public String userProfile() {
        return "Welcome, User!";
    }
}

135. Junit:("return" keyword use)

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MathTest {

    @Test
    void testAddition() {
        int result = add(2, 3);
        assertEquals(5, result); // No need to return anything in test
    }

    // Sample method for testing
    int add(int a, int b) {
        return a + b;
    }
}
✔️ return is used inside methods that are being tested.
✔️ Test methods in JUnit should not return anything (void).
✔️ Use assertions (assertEquals, assertTrue, etc.) to validate output instead of returning values.

136. Junit:("when" keyword use)

Using when in Mockito (JUnit Tests)
- when(...).thenReturn(...) → Tells the mock to return a specific value when a method is called.
- when(...).thenThrow(...) → Tells the mock to throw an exception when called.

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository; // Mocked dependency

    @InjectMocks
    private UserService userService; // Class under test

    @Test
    void testGetUserById() {
        // Arrange: Define mock behavior
        when(userRepository.findUserById(1)).thenReturn(new User(1, "John Doe"));

        // Act: Call method being tested
        User user = userService.getUserById(1);

        // Assert: Verify expected result
        assertEquals("John Doe", user.getName());

        // Verify interaction
        verify(userRepository).findUserById(1);
    }
}

137. What is Hadoop?
Hadoop is a big data framework that allows processing large amounts of data efficiently across multiple computers. It works by distributing data and computations, making it ideal for handling huge datasets.
Real-Time Example: Online Shopping (Amazon, Flipkart)
- Imagine Amazon needs to process millions of orders daily.
- Each order contains customer details, products, payments, and delivery addresses.
- Problem: If all this data is stored in one system, it will be slow and expensive to process.
- Solution: Hadoop divides the data across many servers and processes it in parallel.
- One system handles customer details.
- Another system processes payments.
- Another handles deliveries.

138. What is PySpark?
PySpark is the Python API for Apache Spark, a fast big data processing framework. Unlike Hadoop, which reads data from disk, Spark processes data in memory, making it much faster.
Real-Time Example: Fraud Detection in Banking
- Banks handle millions of transactions every second.
- They need to detect fraud (e.g., unusual credit card activity).
- Problem: If fraud detection runs slowly, criminals can withdraw money before detection happens.
- Solution: PySpark processes transactions in real time using machine learning models.
- It checks for suspicious patterns (e.g., sudden withdrawals from different locations).
- It can immediately block fraudulent transactions.
- This makes PySpark ideal for real-time data analysis.

Hadoop = Best for storing and processing large data (e.g., e-commerce, social media).
✔ PySpark = Best for real-time analysis (e.g., fraud detection, stock market predictions).


139. Http/Rest Api how communicating in spring rest API concept?
In a **Spring Boot REST API microservices architecture**, microservices interact **synchronously** via HTTP requests. Here’s how you can implement it:

---

### **Step-by-Step Approach**
#### **1. Create Individual Microservices**
- **Order Service** → Manages orders and calls Inventory Service before placing an order.
- **Inventory Service** → Handles stock information and updates inventory.

Each service will expose REST APIs using Spring Boot.

---

#### **2. Define REST APIs for Communication**
Each microservice needs a REST API endpoint for interaction:

📌 **Order Service calls Inventory Service**
```java
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private InventoryClient inventoryClient;

    @PostMapping("/placeOrder")
    public String placeOrder(@RequestBody OrderRequest request) {
        boolean isAvailable = inventoryClient.checkStock(request.getProductId());
        if (isAvailable) {
            return "Order placed successfully!";
        }
        return "Stock unavailable!";
    }
}
```

📌 **Inventory Service API**
```java
@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @GetMapping("/checkStock/{productId}")
    public boolean checkStock(@PathVariable String productId) {
        // Assume stock availability logic here
        return true;
    }
}
```

---

#### **3. Use Feign Client for Inter-Service Calls**
Spring Boot provides **Feign Client**, which simplifies HTTP requests between microservices.

📌 **Order Service calls Inventory Service using Feign**
```java
@FeignClient(name = "inventory-service")
public interface InventoryClient {

    @GetMapping("/inventory/checkStock/{productId}")
    boolean checkStock(@PathVariable("productId") String productId);
}
```

✅ **With Feign**, Order Service can call Inventory Service without manually handling HTTP requests.

---

#### **4. Register Microservices with Service Discovery**
- Use **Eureka Server** for dynamic service discovery.
- Define each service in `application.yml`:
```yaml
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
```

✅ This ensures that microservices can locate and communicate with each other dynamically.

---

#### **5. API Gateway for Centralized Routing**
- Use **Spring Cloud Gateway** to route requests efficiently.
- Clients interact with **API Gateway**, which forwards requests to respective microservices.

Example Gateway configuration:
```yaml
routes:
  - id: inventory-service
    uri: lb://inventory-service
    predicates:
      - Path=/inventory/**
```

🔹 **Load Balancing & Security**: API Gateway helps with centralized authentication and load balancing across instances.

---

### **Final Execution Flow**
1️⃣ **Client sends request → Order Service**  
2️⃣ **Order Service calls Inventory Service via Feign Client**  
3️⃣ **Inventory Service checks stock → Returns availability**  
4️⃣ **Order Service processes response → Places order**  

---

### **Why REST APIs (Synchronous)?**
- Simple & direct HTTP-based communication.
- Best for scenarios where immediate response is needed.
- Works well for microservices handling business processes.

If real-time event-driven handling is needed, **asynchronous messaging (Kafka/RabbitMQ)** is preferred.

140. Docker and kubernetes:
Docker 
Docker is a containerization tool that allows you to package an application with all its dependencies into a lightweight, portable container. This ensures the application runs consistently across different environments, whether it's your local machine or a cloud server.
Kubernetes 
Kubernetes (often called K8s) is an orchestration platform that helps manage and scale Docker containers automatically. It ensures applications run smoothly by handling load balancing, scaling, and deployment across multiple servers.
Simple Analogy 
- Docker → Think of it as a lunchbox that neatly packs all ingredients (app + dependencies) so you can take it anywhere.
- Kubernetes → A restaurant kitchen that manages multiple lunchboxes, ensuring they are served efficiently.
Would you like an example of how to use them together? 


141. GitHub ?
**GitHub** is an online platform for storing, managing, and collaborating on code using **Git**. 
It helps developers work together, track changes, and contribute to projects efficiently. 


142.@component and @bean?
- @Component is a class-level annotation used for automatic component scanning. When a class is annotated with @Component, Spring automatically detects and registers it as a bean in the application context.
- @Bean is a method-level annotation used inside a @Configuration class. It explicitly defines a bean and allows customization of its instantiation logic

143.@bean used for which scenario?
 @Bean as a way to manually tell Spring how to create an object when it can't do it automatically. You use it inside a special configuration class.
For example, if you're using a third-party library and need to create an object from it, Spring won't know what to do on its own.
 With @Bean, you write a method that creates and provides that object.

In spring, how to call super class from sub class
@Component
class Parent {
    @Autowired
    private SomeService someService;

    void show() {
        System.out.println("Service: " + someService.getInfo());
    }
}

@Component
class Child extends Parent {
    void display() {
        super.show(); // Calls Parent's method
        System.out.println("Hello from Child");
    }
}

144. To connect the database and springboot which one is mandatory?
application.properties:
spring.datasource.url=jdbc:mysql://localhost:3306/your_db
spring.datasource.username=root
spring.datasource.password=your_password
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

pom.xml:
For SQL:spring-boot-starter-data-jpa , For jdbc: spring-boot-starter-jdbc

145. Asynchoronous thread ?
- The main thread starts executing first.
- A new thread (MyTask) starts running in parallel when .start() is called.
- Both threads run asynchronously, meaning they interleave execution without blocking each other.

146. Synchoronous thread ?
Use .join() if working with Thread objects.
✔ Use .get() in ExecutorService or CompletableFuture for structured execution.
✔ Use invokeAll() to sequentially execute multiple tasks in an executor thread pool.

// Synchronous (runs one after another)
class SyncExample {
    void printNumbers() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Sync: " + i);
            try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }
        }
    }
}

// Asynchronous (runs concurrently)
class AsyncExample extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Async: " + i);
            try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }
        }
    }
}

public class ThreadExample {
    public static void main(String[] args) {
        // Synchronous execution
        SyncExample sync = new SyncExample();
        sync.printNumbers();

        // Asynchronous execution
        AsyncExample async = new AsyncExample();
        async.start(); // Runs in parallel
    }
}

- Synchronous: Calls printNumbers() and waits for it to finish before proceeding.
- Asynchronous: Creates a thread (AsyncExample) and runs independently.

147. Cache:
**Caching** is a technique used to store frequently accessed data in memory for faster retrieval.

### **🔹 Why Use Caching in Your Banking System?**
✅ **Reduces load on the database** by storing frequently requested customer data.  
✅ **Improves response time** for users accessing account details.  
✅ **Enhances scalability** by reducing redundant computations.

---

### **🔹 How to Implement Caching in Spring Boot?**
Spring Boot provides **Spring Cache** for easy integration. Follow these steps:

#### **1️⃣ Add Cache Dependencies in `pom.xml`**
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-cache</artifactId>
</dependency>

<dependency>
    <groupId>org.ehcache</groupId>
    <artifactId>ehcache</artifactId>
</dependency>
```
✅ **EhCache** is used for caching data in-memory.

---

#### **2️⃣ Enable Caching in Application (`Application.java`)**
```java
@SpringBootApplication
@EnableCaching  // Enables Spring Cache
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```
✅ This tells Spring Boot to **start using caching**.

---

#### **3️⃣ Cache Customer Data in `CustomerService.java`**
```java
@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    @Cacheable(value = "customers", key = "#accountNumber")
    public Optional<Customer> getCustomerByAccountNumber(String accountNumber) {
        System.out.println("Fetching customer from DB...");
        return customerRepository.findByAccountNumber(accountNumber);
    }
}
```
✅ **First request** fetches from the database.  
✅ **Subsequent requests** return cached data **without hitting the DB**.

---

#### **4️⃣ Clearing Cache After Update (`CustomerService.java`)**
When updating customer details, cache needs to be **removed and refreshed**.

```java
@CacheEvict(value = "customers", key = "#accountNumber")
public Customer updateCustomer(Long id, Customer updatedCustomer) {
    return customerRepository.findById(id).map(customer -> {
        customer.setName(updatedCustomer.getName());
        customer.setEmail(updatedCustomer.getEmail());
        customer.setBalance(updatedCustomer.getBalance());
        return customerRepository.save(customer);
    }).orElseThrow(() -> new RuntimeException("Customer not found"));
}

@CachePut(cacheNames = "employees", key = "#employee.id")
public Employee updateEmployee(Employee employee) {
    return employeeRepository.save(employee);
}

```
✅ Clears cache after updating the customer, ensuring **fresh data is retrieved next time**.

---

### **🔹 Summary: Caching in Your Banking App**
✔ **Spring Cache for performance optimization** ✅  
✔ **EhCache for in-memory caching** ✅  
✔ **`@Cacheable` to store customer details** ✅  
✔ **`@CacheEvict` to clear cache on updates** ✅  

148.What is RestTemplate in springboot?
In Spring Boot, RestTemplate is a tool used to make REST API calls. Think of it as a browser that can send requests and receive responses programmatically.

1. Create a RestTemplate Object
RestTemplate restTemplate = new RestTemplate();


2. Making a GET Request
String response = restTemplate.getForObject("https://api.example.com/data", String.class);
System.out.println(response);

3. Making a POST Request
String response = restTemplate.postForObject("https://api.example.com/create", entity, String.class);

149. DynamoDB:
Amazon DynamoDB is a serverless, NoSQL database service provided by AWS. It is designed for high performance, scalability, and flexibility, making it ideal for applications that require fast and predictable responses.

150.CompletableFuture ?
CompletableFuture is a powerful feature in Java that allows you to handle asynchronous programming efficiently. 
It was introduced in Java 8 and is part of the java.util.concurrent package.

Key Methods in CompletableFuture:
- supplyAsync() – Runs a task asynchronously and returns a result.
- thenApply() – Transforms the result of a previous computation.
- thenAccept() – Consumes the result without returning anything.
- thenCombine() – Combines results from two CompletableFuture instances.
- exceptionally() – Handles errors in asynchronous tasks.

Example: Chaining Multiple Tasks
CompletableFuture.supplyAsync(() -> "Hello")
    .thenApply(greeting -> greeting + " World")
    .thenAccept(System.out::println);


This prints:
Hello World

151.Key Benefits of Static Analysis
- Finds bugs early before runtime failures occur.
- Improves security by detecting vulnerabilities like SQL injection.
- Enhances performance by identifying inefficient code patterns.
- Ensures coding standards by enforcing best practices.


152. how to validate annotation is used in controller?how to validate the particular field ?
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class AccountRequest {
    @NotNull(message = "Account number cannot be null")
    @Pattern(regexp = "\\d{10,16}", message = "Account number must be 10-16 digits")
    private String accountNumber;

    // Getters and Setters
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
}

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/accounts")
@Validated
public class AccountController {

    @PostMapping("/validate")
    public String validateAccount(@Valid @RequestBody AccountRequest request) {
        return "Account number " + request.getAccountNumber() + " is valid!";
    }
}

153.how to mark id and name as a primary key in entity file springboot restapi ?

import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class AccountKey implements Serializable {
    private Long id;
    private String name;

    // Constructors, Getters, Setters, Equals & HashCode
}

Then, embed it in the entity:
import jakarta.persistence.*;

@Entity
public class Account {
    
    @EmbeddedId
    private AccountKey accountKey;

    private String email;

    // Getters, Setters, and other properties
}

154.custom annotations

You define an annotation using the @interface keyword:
import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME) // Specifies annotation retention policy
@Target(ElementType.METHOD) // Specifies applicable element types
public @interface MyAnnotation {
    String value() default "Default Value"; // Annotation element with default value
}


Using the Custom Annotation
You can apply the annotation to methods, classes, or fields:
class Example {
    @MyAnnotation(value = "Hello, Annotation!")
    public void myMethod() {
        System.out.println("Method executed.");
    }
}


Processing the Annotation
You can retrieve and process annotations using Java Reflection:
import java.lang.reflect.Method;

public class AnnotationProcessor {
    public static void main(String[] args) throws Exception {
        Method method = Example.class.getMethod("myMethod");
        MyAnnotation annotation = method.getAnnotation(MyAnnotation.class);
        
        if (annotation != null) {
            System.out.println("Annotation Value: " + annotation.value());
        }
    }
}


This will output:
Annotation Value: Hello, Annotation!

155.How to filter out of ppl with age above 18 and below 50 through custom validators annotation in sprinboot

You can create a **custom validation annotation** in Spring Boot to filter out people whose age is **above 18 and below 50**. Here's how you can do it:

- @Constraint: Marks an annotation as a validation constraint.
- validatedBy = AgeValidator.class: Specifies the class that contains the logic to validate the constraint.
So when you create a custom 


### **Step 1: Create a Custom Annotation**
Define an annotation `@ValidAge` that enforces the age constraint.

```java
import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Constraint(validatedBy = AgeValidator.class)
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidAge {
    String message() default "Age must be between 18 and 50";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
```

### **Step 2: Implement the Validator**
Create a class `AgeValidator` that implements the validation logic.

```java
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class AgeValidator implements ConstraintValidator<ValidAge, Integer> {
    @Override
    public boolean isValid(Integer age, ConstraintValidatorContext context) {
        return age != null && age >= 18 && age <= 50;
    }
}
```

### **Step 3: Apply the Annotation**
Use `@ValidAge` in your entity class.

```java
public class User {
    private Long id;
    private String name;

    @ValidAge
    private Integer age;

    // Getters and Setters
}
```

### **Step 4: Validate in Controller**
Ensure validation is applied when handling requests.

```java
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/users")
public class UserController {
    @PostMapping("/")
    public ResponseEntity<String> createUser(@Valid @RequestBody User user) {
        return ResponseEntity.ok("User created successfully!");
    }
}
```

### **Step 5: Test the API**
Try sending a request with an invalid age (e.g., 55), and Spring Boot will return a validation error.

This approach ensures that only users with **age between 18 and 50** are accepted.


156.Collision handling in java?
To find the **next empty slot** in a hash table, you can use **Open Addressing** techniques. Here are the common methods:

### **1. Linear Probing (Simple & Common)**
- If a slot is occupied, check the **next slot** sequentially.
- Formula:  
  ```
  new_index = (current_index + 1) % table_size
  ```
- Example:
  ```java
  int index = key.hashCode() % tableSize;
  while (hashTable[index] != null) { // If occupied, move to next slot
      index = (index + 1) % tableSize;
  }
  ```

### **2. Quadratic Probing (Avoids Clustering)**
- Instead of checking the next slot, jump in **quadratic steps** (`1^2, 2^2, 3^2...`).
- Formula:  
  ```
  new_index = (current_index + i^2) % table_size
  ```
- Example:
  ```java
  int index = key.hashCode() % tableSize;
  int i = 1;
  while (hashTable[index] != null) {
      index = (index + i * i) % tableSize;
      i++;
  }
  ```

### **3. Double Hashing (Uses a Second Hash Function)**
- If a collision occurs, use a second hash function to find the next slot.
- Formula:  
  ```
  new_index = (hash1 + i * hash2) % table_size
  ```
- Example:
  ```java
  int index = key.hashCode() % tableSize;
  int hash2 = 7 - (key.hashCode() % 7); // Second hash function
  int i = 1;
  while (hashTable[index] != null) {
      index = (index + i * hash2) % tableSize;
      i++;
  }
  ```

### **Which Method Should You Use?**
- **Linear Probing** is simple but can cause clustering.
- **Quadratic Probing** reduces clustering but requires careful tuning.
- **Double Hashing** is efficient but needs a good second hash function.


157. how does red black binary tree work?
Handling conflicts in a Red-Black Tree involves maintaining its balance after insertions or deletions. The tree follows strict rules to ensure efficient operations, and when violations occur, we fix them using rotations and recoloring

What is a Red-Black Tree?
- It's a self-balancing binary search tree used in data structures like TreeMap in Java.
- It keeps operations fast (O(log n) time) by balancing itself automatically.
How Does It Work?
Every node is either Red or Black. It follows these rules:
- The root is always black.
- No two red nodes can be together (prevents long chains).
- Every path from a node to its children has the same number of black nodes. (keeps it balanced)

158. scheduler in microservice?
- For simple tasks → Use @Scheduled in Spring Boot.
- For complex scheduling → Use Quartz.
- For cloud-native scheduling → Use Kubernetes CronJobs.
- For event-driven scheduling → Use Kafka or RabbitMQ.

Using Spring Boot Scheduler (@Scheduled)
- Spring Boot provides the @Scheduled annotation for scheduling tasks.
- Example:
@Scheduled(fixedRate = 5000) // Runs every 5 seconds
public void scheduledTask() {
    System.out.println("Task executed at: " + new Date());
}
- You need to enable scheduling with @EnableScheduling in your main class.

158. Parent child table update using jpa?

1. Define Parent & Child Entities
Parent Entity:
@Entity
public class Parent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Child> children = new ArrayList<>();

    // Getters & Setters
}


Child Entity:
@Entity
public class Child {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "parent_id")
    private Parent parent;

    // Getters & Setters
}

 Updating Parent & Child Data When updating, ensure that:
- CascadeType.ALL allows automatic updates to child entities.
- orphanRemoval = true removes child entities when removed from the parent list.

159. Upper and lower bounded wildcards in Java generics ?

- Use ? extends T when the collection produces data (you only read).
- Use ? super T when the collection consumes data (you only write).


Upper Bounded Wildcard: <? extends T>
Meaning: Accepts T or any subclass of T.
Use case: When you want to read from a collection but not modify it.

public static double sum(List<? extends Number> list) {
    double total = 0;
    for (Number num : list) {
        total += num.doubleValue();
    }
    return total;
}

Lower Bounded Wildcard: <? super T>
Meaning: Accepts T or any superclass of T.
Use case: When you want to write to a collection.

public static void addNumbers(List<? super Integer> list) {
    for (int i = 1; i <= 5; i++) {
        list.add(i);
    }
}

160. who is introduced the map in java ?

The Map interface in Java was introduced as part of the Java Development Kit (JDK) 1.2, during the launch of the Java Collections Framework.
This major update was led by Joshua Bloch, a key engineer at Sun Microsystems at the time, who played a pivotal role in designing and implementing the collections framework.

161.Which variable has default value?
In Java, instance variables and static variables have default values, but local variables do not.

162. how will use the lamda expression in functional interface ?

Using a **lambda expression** with a **functional interface** in Java is one of the most elegant features introduced in Java 8. Let’s break it down with a simple example:

---

### 🧩 Step 1: Define a Functional Interface

A functional interface is any interface with **exactly one abstract method**.

```java
@FunctionalInterface
interface Greeting {
    void sayHello(String name);
}
```

---

### ⚡ Step 2: Use a Lambda Expression to Implement It

Instead of writing a full class or anonymous inner class, you can use a lambda:

```java
Greeting greet = (name) -> System.out.println("Hello, " + name + "!");
```

Here:
- `(name)` is the parameter list.
- `->` is the lambda arrow.
- The right side is the method body.

---

### 🚀 Step 3: Call the Method

```java
greet.sayHello("Java");
```

**Output:**
```
Hello, Java!
```

---

### 🧠 Why Use Lambda with Functional Interfaces?

- **Less boilerplate**: No need for anonymous classes.
- **More readable**: Focuses on behavior, not structure.
- **Powerful with streams**: Used heavily in `Stream` API and event handling.

163. Blocked vs waiting thread ?

- Blocked = waiting for a lock
- Waiting = waiting for a signal

 Blocked State
- A thread is blocked when it’s trying to enter a synchronized block or method, but another thread is already holding the lock.
- It’s like waiting outside a locked bathroom—you're ready to go, but someone else is inside.

Waiting State
- A thread is in the waiting state when it calls wait(), join(), or LockSupport.park() and is waiting for another thread to notify it.
- It’s like putting your name on a waiting list and sitting down—you’re not even trying to enter the bathroom until someone calls your name.

164. - what is a thread?
A thread is a small part of a program that runs independently.

165. Sequences in sql?
In SQL, a sequence is a database object that generates a series of unique numeric values, often used for primary keys or other identifiers. Unlike AUTO_INCREMENT (which is tied to a specific table), sequences are independent and can be reused across multiple tables.

CREATE SEQUENCE seq_employee_id
START WITH 1
INCREMENT BY 1
MINVALUE 1
MAXVALUE 99999
CYCLE;

166.  application.yml & application.properties ?

- application.yml uses YAML syntax, which is more structured and supports nesting.
- application.properties uses key-value pairs, which are simpler but can get verbose for complex configurations.
So appli.yml and appli.proper (if you meant application.properties) are not the same—and appli.yml or appli.proper won’t be recognized unless you explicitly configure Spring Boot to load them. Stick with the standard names (application.yml or application.properties) unless you have a specific reason to customize.

167. API gateway code:

Add the dependency:(gateway)
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-gateway</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>

application.properties:

server.port=8080
spring.application.name=api-gateway
spring.cloud.gateway.discovery.locator.enabled=true
spring.cloud.gateway.discovery.locator.lower-case-service-id=true

    (or)
	
server:
  port: 8080

spring:
  application:
    name: api-gateway
  cloud:
    gateway:
      routes:
        - id: user-service
          uri: http://localhost:8081
          predicates:
            - Path=/users/**
        - id: order-service
          uri: http://localhost:8082
          predicates:
            - Path=/orders/**

168. Service Discovery code:

1.Add the dependency:
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>

2.

@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
    }
}

3. application.properties
server.port=8761
spring.application.name=eureka-server
eureka.client.register-with-eureka=false
eureka.client.fetch-registry=false

169. Circuit breaker code ?

1. Add the Dependency
In your pom.xml, include:
<dependency>
  <groupId>org.springframework.cloud</groupId>
  <artifactId>spring-cloud-starter-circuitbreaker-resilience4j</artifactId>
</dependency>

2. Annotate the Method
Let’s say you want to apply the circuit breaker to the getAll() method. You can annotate it like this:
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    @CircuitBreaker(name = "employeeServiceCB", fallbackMethod = "fallbackGetAll")
    public List<Employee> getAll() {
        List<Employee> emp = employeeRepo.findAll();
        return emp.stream()
                  .filter(e -> e.getAge() > 20 && e.getName().startsWith("A"))
                  .toList();
    }

    public List<Employee> fallbackGetAll(Throwable t) {
        // Return an empty list or cached data as fallback
        return List.of();
    }
}

3. Configure in application.yml or application.properties
resilience4j.circuitbreaker:
  instances:
    employeeServiceCB:
      registerHealthIndicator: true
      slidingWindowSize: 5
      failureRateThreshold: 50
      waitDurationInOpenState: 10s


This config tells Resilience4j how to behave:
Closed state: Watch the last 5 calls (slidingWindowSize)  
Open state: If 3 or more fail (50% threshold), open the circuit
Half open: Wait 10 seconds before trying again

170. Rest template() code ?

Step 1: Define a RestTemplate Bean
In a configuration class:
@Configuration
public class AppConfig {
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}


Step 2: Autowire RestTemplate in Your Service
Update your EmployeeService:

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private RestTemplate restTemplate;

    public Employee create(Employee employee) {
        Employee saved = employeeRepo.save(employee);

        // Example: Notify another service
        String notifyUrl = "http://external-service/api/notify";
        restTemplate.postForObject(notifyUrl, saved, String.class);

        return saved;
    }

    public List<Employee> getAll() {
        List<Employee> emp = employeeRepo.findAll();
        return emp.stream()
                  .filter(e -> e.getAge() > 20 && e.getName().startsWith("A"))
                  .toList();
    }
}

171. @value springboot ?
The @Value annotation in Spring Boot is used to inject values into fields, method parameters, or constructor arguments from external sources like application.properties, environment variables, or system properties.
 Ex:
 @Value("${app.modules}")
private List<String> modules;

app.modules=HR,Finance,Payroll

With Default Value
@Value("${app.version:1.0}")
private String appVersion;


If app.version is not defined, it defaults to "1.0".

🧮 With Expressions (SpEL)
@Value("#{2 * 10}")
private int calculatedValue; // Injects 20


You can even access system properties:
@Value("#{systemProperties['user.name']}")
private String systemUser;

172. Rest template(), web client() and kafka () used in Rest api ?

Great question! Let’s enhance your `EmployeeService` by integrating **RestTemplate**, **WebClient**, and **Kafka**—each for a different purpose so you can see how they fit into a real-world Spring Boot service.

---

### ✅ 1. Using **RestTemplate** – Call Another REST API (Synchronous)

Let’s say you want to notify an external HR system when a new employee is created.

#### Add Bean Configuration

```java
@Configuration
public class AppConfig {
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
```

#### Modify `EmployeeService`

```java
@Autowired
private RestTemplate restTemplate;

public Employee create(Employee employee) {
    Employee saved = employeeRepo.save(employee);

    // Notify external system
    String url = "http://external-service/api/notify";
    restTemplate.postForObject(url, saved, String.class);

    return saved;
}
```

---

### ⚡ 2. Using **WebClient** – Call REST API (Asynchronous/Reactive)

Same use case, but non-blocking.

#### Add WebClient Bean

```java
@Configuration
public class WebClientConfig {
    @Bean
    public WebClient webClient() {
        return WebClient.builder().baseUrl("http://external-service").build();
    }
}
```

#### Modify `EmployeeService`

```java
@Autowired
private WebClient webClient;

public Employee create(Employee employee) {
    Employee saved = employeeRepo.save(employee);

    // Asynchronous call
    webClient.post()
             .uri("/api/notify")
             .bodyValue(saved)
             .retrieve()
             .bodyToMono(String.class)
             .subscribe(); // Fire and forget

    return saved;
}
```

---

### 📣 3. Using **Kafka** – Publish Event to a Topic

Let’s say you want to publish an event when an employee is created.

#### Kafka Producer

```java
@Service
public class KafkaProducer {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendEmployeeEvent(String message) {
        kafkaTemplate.send("employee-topic", message);
    }
}
```

#### Modify `EmployeeService`

```java
@Autowired
private KafkaProducer kafkaProducer;

public Employee create(Employee employee) {
    Employee saved = employeeRepo.save(employee);

    // Publish event
    kafkaProducer.sendEmployeeEvent("New employee created: " + saved.getName());

    return saved;
}
```

#### Kafka Config (`application.properties`)

```properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer
spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerializer


| Tool         | Purpose                          | Style         |
|--------------|----------------------------------|---------------|
| RestTemplate | Call REST API (sync)             | Blocking      |
| WebClient    | Call REST API (async/reactive)   | Non-blocking  |
| Kafka        | Publish/consume events           | Asynchronous  |

To write a **Kafka consumer** for your `EmployeeService` example, you’ll need a class that listens to the Kafka topic where employee events are published. Here's a simple and clear implementation:

---

### 🧩 Step 1: Add Kafka Consumer Configuration

In `application.properties`:

```properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=employee-group
spring.kafka.consumer.auto-offset-reset=earliest
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer
```

---

### 🧠 Step 2: Create the Consumer Class

```java
package com.example.Sample;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class EmployeeConsumer {

    @KafkaListener(topics = "employee-topic", groupId = "employee-group")
    public void consume(String message) {
        System.out.println("📥 Received Kafka message: " + message);
        // You can add logic here to process or store the message
    }
}
```

This method will automatically be triggered whenever a message is published to the `employee-topic`.

---

### 🛠️ Optional: Enable Kafka Support

If not already done, annotate a config class with:

```java
@EnableKafka
@Configuration
public class KafkaConfig {
    // You can define custom consumer factories here if needed
}
```

---

### 🧪 Test Flow

1. Your `EmployeeService` creates an employee.
2. It publishes a message using `KafkaProducer`.
3. `EmployeeConsumer` listens and logs or processes the message.


173. Executer service vs Fixed threadpool?
1. ExecutorService = The Manager Desk
This is just the interface—it doesn't cook, it just takes orders and says,
"I'll find a way to cook this. Trust me."
It can use any kind of kitchen setup behind the scenes:
- A single chef
- A team of chefs
- A chef that only works on Sundays
All of these are different implementations of ExecutorService.

2. FixedThreadPool = A Team of Exactly N Chefs
When you say:
ExecutorService executor = Executors.newFixedThreadPool(3);


You're telling the manager: "I want exactly 3 chefs. No more, no less. Use them to handle all orders."
- 3 orders come in ➡️ all get cooked at once.
- 5 orders ➡️ 3 cook, 2 wait in line.
- Still using ExecutorService, just with fixed resources.

174. Singleton design pattern code?

Early instantiation:
class Abc
{
	 static Abc obj= new Abc();  ==> step 1
	 
	 private Abc()               ==> step 2
	 {
	 }
	 
     public static Abc getObj()  ==> step 3
	 {
		 return obj;
	 }
}
public class Main {
    public static void main(String[] args) {
        Abc instance1 = Abc.getObj();
        Abc instance2 = Abc.getObj();

        System.out.println(instance1 == instance2); // Output: true
    }
}

Lazy instantiation:
class Abc {
    private static Abc obj;

    private Abc() {
        // Private constructor
    }

    public static Abc getObj() {
        if (obj == null) {
            obj = new Abc();  // Object created only when first accessed
        }
        return obj;
    }
}

175. For create we are using postmapping right in springboot controller? it is possible to use getmapping ?
For getmapping, It might work, but it's not safe.
GET requests can be cached, bookmarked, or triggered unintentionally (e.g., by a browser preloading a link), which could lead to accidental user creation.
Browsers and proxies may cache GET requests, leading to unexpected behavior if used for data submission.

176. Executer service syntax :
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) {
        // Create a thread pool with 5 threads
        ExecutorService executor = Executors.newFixedThreadPool(5);

        // Submit a task to the executor
        executor.submit(() -> {
            System.out.println("Running task in thread: " + Thread.currentThread().getName());
        });

        // Shutdown the executor after task completion
        executor.shutdown();
    }
}

177. Executors.newFixedThreadPool() vs Executors.newSingleThreadExecutor()
ExecutorService executor = Executors.newFixedThreadPool(3);
- Creates a pool with a fixed number of threads (e.g., 3).
- Multiple tasks can run in parallel.
- Ideal for CPU-intensive or concurrent tasks.
- Tasks are queued if all threads are busy.

🧵 Single Thread Executor
ExecutorService executor = Executors.newSingleThreadExecutor();
- Only one thread is used to execute tasks.
- Tasks run sequentially, one after another.
- Useful when tasks must not run concurrently (e.g., writing to a file).
- Guarantees order of execution.

178. what is blocking queue?
A BlockingQueue is a thread-safe queue that supports blocking operations:
- 🔼 When adding (put) an element, it can block if the queue is full.
- 🔽 When removing (take) an element, it can block if the queue is empty.
So if one thread tries to take an item and there’s none, it’ll wait until another thread adds one. Likewise, if you try to add to a full queue, the thread waits until space becomes available.

| Class                 | Behavior | 
| ArrayBlockingQueue    | Fixed-size, backed by array | 
| LinkedBlockingQueue   | Optionally bounded, linked nodes | 
| PriorityBlockingQueue | Ordered by priority, not FIFO | 
| DelayQueue            | Elements become available after delay | 
| SynchronousQueue      | No internal capacity; direct hand-off | 

179. How to deploy microservices application ?
- Containerize each service with Docker
- Use Kubernetes for orchestration
- Configure API Gateway
- Use service discovery (Eureka/Consul)
- Secure with Spring Security + JWT

180. How to handle data inconsistency in micorservices ?
- Use event-driven communication (e.g., Kafka)
- Apply SAGA pattern for distributed transactions
- Implement data validation and reconciliation jobs
- Use centralized logging and monitoring


181. object class contain how many method those are which situation you implemented in your project write code for it?
toString() method
hashCode() method
equals(Object obj) method
finalize() method
getClass() method
clone() method
wait(), notify() notifyAll() (Concurrency methods)

182. Any possible to use Can You Use POST Instead of GET?
Yes, but only if you're okay with:
- Not caching the response (POST responses aren’t cached by browsers)
- Not bookmarking or sharing the URL easily (POST data isn’t in the URL)
- Sending data in the request body instead of the URL
📌 Example:
POST /search
{
  "query": "laptops"
}


This works, but it’s less efficient than:
GET /search?query=laptops



🔁 Can You Use GET Instead of POST?
Technically yes, but it’s unsafe if:
- You’re sending sensitive data (GET exposes it in the URL)
- You’re modifying server state (GET should only retrieve data)
📌 Bad Practice:
GET /createUser?name=John&email=john@example.com


This could accidentally create users multiple times if bookmarked or cached.

| Method | Purpose          | Safe for Modifying Data | Caching | Data Location | 
| GET    | Retrieve data    | ❌ No                   | ✅ Yes  | URL query string | 
| POST   | Send/modify data | ✅ Yes                  | ❌ No   | Request body | 


Using them interchangeably can lead to security issues, unexpected behavior, or performance problems.

183. Stream vs parallel stream ?
Using stream().forEach(System.out::println);
This processes elements sequentially, so the output will always be in order.

Using parallelStream().forEach(System.out::println);
This processes elements in parallel, so the order may vary depending on thread scheduling. 
Great question! In Java, both `stream()` and `parallelStream()` are used to process collections, but they differ in how they execute operations:


### 🆚 Key Differences

| Feature              | `stream()`                | `parallelStream()`          |
|----------------------|---------------------------|-----------------------------|
| Execution            | Sequential(single thread) | Parallel (multiple threads) |
| Performance          | Slower on large data      | Faster on large data        |
| Order of Output      | Preserved                 | Not guaranteed              |
| Debugging            | Easier                    | More complex                |
| Use Case             | Small or ordered data     | Large, unordered data       |

184. How to disable password before running springboot application ?
Option 1: Exclude Security Auto-Configuration
If you don’t need Spring Security at all:
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
    (OR)
	
Option 2:Provide Custom Security Configuration
Create your own WebSecurityConfigurerAdapter or use SecurityFilterChain (for Spring Boot 3+):
Just want to temporarily disable login while keeping security components around, follow below steps.
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth.anyRequest().permitAll())
            .csrf().disable();
        return http.build();
    }
}

185.what is log4j?
Log4j is a powerful, flexible, and fast logging library developed by the Apache Software Foundation. It allows developers to log messages from their applications to various destinations like files, consoles, databases, or remote servers.
Logging is essential for:
- Debugging and troubleshooting
- Monitoring application behavior
- Auditing and compliance

How It Works
- Logger is created for each class or module:
private static final Logger logger = Logger.getLogger(MyClass.class);

- You log messages like:
logger.info("Starting process...");
logger.error("Something went wrong!", exception);
- 

186. Mode of autowired ?

Autowiring Modes in Spring
| Mode          | Description | 
| no            | Default mode. No autowiring is done; dependencies must be explicitly defined. | 
| byName        | Injects dependency by matching the property name with the bean name. | 
| byType        | Injects dependency by matching the property type with the bean type. | 
| constructor   | Injects dependencies via constructor arguments based on type. | 
| autodetect    | Deprecated. Tries constructor first, then byType if constructor fails. | 


187. Method reference ?
A method reference is a shorthand way to call a method using :: instead of writing a full lambda expression.

List<String> names = Arrays.asList("A", "B", "C");
names.forEach(name -> System.out.println(name)); // using lambda

names.forEach(System.out::println); // using method reference

188. What Is a Marker Interface?
A marker interface is an interface with no methods or fields. It’s used to mark or tag a class so that the Java runtime or frameworks can treat it differently.

✅ Common Marker Interfaces in Java
| Interface    | Purpose | 
| Serializable | Marks a class for object serialization | 
| Cloneable    | Marks a class as cloneable using .clone() | 
| Remote       | Marks a class for remote method invocation | 



📦 Sample Example: Serializable
import java.io.Serializable;

public class Student implements Serializable {
    private int id;
    private String name;

    // Constructor, getters, setters
}


Explanation:
- Serializable has no methods.
- By implementing it, the Student class can be converted into a byte stream (e.g., saved to a file or sent over a network).
- If you don’t mark the class, Java will throw an error during serialization.

🧠 Why Use Marker Interfaces?
- They provide metadata to the JVM or frameworks.
- They enable conditional behavior without adding logic to the class.
- They’re useful in legacy systems and frameworks like Spring or Hibernate.

189. 2-3 scenario was given and we need to identify what type of pattern can be used in those scenario ? how to understand in easy way ?

Great question! Understanding which **design pattern** fits a scenario becomes much easier when you break it down by the **problem type**. Here's a simple way to approach it:

---

### 🧠 Step-by-Step Guide to Identify Design Patterns

#### 1. **Ask: What is the problem trying to solve?**
- Is it about **creating objects**? → Think **Creational patterns**
- Is it about **structuring relationships**? → Think **Structural patterns**
- Is it about **behavior or communication**? → Think **Behavioral patterns**

#### 2. **Look for clues in the scenario**
Here are 3 common scenarios and how to match them:

---

### 📦 Scenario 1: "We need to create objects based on input, but hide the creation logic."

**Pattern**: **Factory Pattern**  
**Why**: You want to encapsulate object creation and return different types based on input.

**Example**:
```java
Shape shape = ShapeFactory.getShape("CIRCLE");
```

---

### 🔁 Scenario 2: "We want to notify multiple components when one changes."

**Pattern**: **Observer Pattern**  
**Why**: You need a publish-subscribe model where changes in one object notify others.

**Example**: UI components updating when data changes.

---

### 🧍 Scenario 3: "We need only one instance of a class throughout the app."

**Pattern**: **Singleton Pattern**  
**Why**: You want a single shared resource (e.g., config manager, logger).

**Example**:
```java
Logger logger = Logger.getInstance();
```

---

### 🧩 Quick Pattern Matching Table

| Scenario Type | Pattern | Use Case |
|---------------|---------|----------|
| Object creation | Factory, Builder, Singleton | Flexible object creation |
| Communication | Observer, Mediator | Event handling, decoupling |
| Behavior change | Strategy, State | Dynamic behavior at runtime |
| Structure | Adapter, Decorator | Wrapping or converting interfaces |

---

### 🎯 Pro Tip

When you're given a scenario:
- **Underline the verbs**: “create”, “notify”, “change”, “wrap”, “convert”
- Match them to the **intent** of the pattern

Instead of memorizing patterns, focus on the intent:
- “Am I trying to simplify object creation?” → Creational
- “Am I trying to manage communication or behavior?” → Behavioral
- “Am I trying to structure or modify objects?” → Structural

190. Fail fast & Fail safe ?

In Java, **fail fast** and **fail safe** are often discussed in the context of **iterators** and **concurrent modification**, especially when working with collections. Let’s break it down with Java-specific examples:

---

### ⚡ Fail-Fast in Java

**Definition:**  
A fail-fast system immediately throws an exception if it detects that the structure of a collection has been modified while iterating.

**Common in:**  
Collections from the `java.util` package like `ArrayList`, `HashMap`, etc.

**Behavior:**
- Throws `ConcurrentModificationException` if the collection is modified during iteration (except through the iterator itself).
- Helps catch bugs early during development.

**Example:**
```java
List<String> list = new ArrayList<>();
list.add("A");
list.add("B");

for (String item : list) {
    list.add("C"); // Modifying the list during iteration
    // This will throw ConcurrentModificationException
}
```

---

### 🛡️ Fail-Safe in Java

**Definition:**  
A fail-safe system allows modifications during iteration without throwing exceptions.

**Common in:**  
Concurrent collections like `CopyOnWriteArrayList`, `ConcurrentHashMap`.

**Behavior:**
- Iterators work on a **clone** or **snapshot** of the collection.
- Changes made during iteration do not affect the iterator.

**Example:**
```java
CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>();
list.add("A");
list.add("B");

for (String item : list) {
    list.add("C"); // No exception thrown
    System.out.println(item);
}
```

---

### 🧠 Summary Table

| Feature                  | Fail-Fast                               | Fail-Safe                          |
|--------------------------|-----------------------------------------|------------------------------------|
| Throws Exception         | Yes (`ConcurrentModificationException`) | No                                 |
| Iterator Type            | Direct reference to collection          | Snapshot or clone                  |
| Common Collections       | `ArrayList`, `HashMap`                  | `ConcurrentHashMap`, `CopyOnWriteArrayList` |
| Use Case                 | Debugging, strict consistency           | Concurrency, safe iteration        |

191. Procedures & Trigger ?
Procedures :
- A procedure is a saved set of SQL commands.
- You can run it anytime to perform tasks like inserting, updating, or deleting data.

Triggers
- A trigger automatically runs when something happens in the database (like insert, update, or delete).

192. SQL Injection ?
- A security risk where attackers insert harmful SQL into your queries.
- Happens when user input isn’t properly checked.
- Always use prepared statements to prevent it.

❌ Unsafe:
"SELECT * FROM Users WHERE name = '" + userInput + "'"


✅ Safe:
PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Users WHERE name = ?");
stmt.setString(1, userInput);

193. Primary vs Unique
- Primary Key: Uniquely identifies each row. Only one per table. Cannot be null.
- Unique Key: Also ensures uniqueness, but you can have multiple unique keys. Can contain nulls.

194. Unique Constraints
- A rule that prevents duplicate values in a column.
- Ensures data integrity.

ALTER TABLE Users ADD CONSTRAINT unique_email UNIQUE (email);

195. how do you handle  database migration in springboot ?

 Using Flyway (Most Common Approach)
Here’s how you can handle migrations step-by-step:
1. Add Flyway to your project
In your pom.xml (for Maven):
<dependency>
  <groupId>org.flywaydb</groupId>
  <artifactId>flyway-core</artifactId>
</dependency>


2. Create migration scripts
Place SQL files in src/main/resources/db/migration/
Example: V1__init.sql, V2__add_users_table.sql
Flyway will automatically detect and run these scripts in order.

3. Configure Flyway (optional)
In application.properties:
spring.flyway.enabled=true
spring.flyway.baseline-on-migrate=true
spring.flyway.locations=classpath:db/migration


196. SOLID principle ?

Absolutely! The **SOLID principles** are five simple rules that help you write clean, maintainable, and scalable object-oriented code in Java (or any OOP language). Here's a super simple breakdown:

---

### 🧱 S — Single Responsibility Principle (SRP)
**One class = One job.**
- A class should do **only one thing**.
- Example: Don’t mix file reading and data processing in the same class.

---

### 🧲 O — Open/Closed Principle (OCP)
**Open for extension, closed for modification.**
- You should be able to **add new features** without changing existing code.
- Example: Use interfaces or abstract classes so you can plug in new behavior.

---

### 🧩 L — Liskov Substitution Principle (LSP)
**Subclasses should behave like their parent.**
- If class B extends class A, it should **work anywhere A is expected**.
- Example: A `Bird` class with a `fly()` method shouldn’t be extended by `Penguin` unless you handle the flying part properly.

---

### 🔄 I — Interface Segregation Principle (ISP)
**Don’t force classes to implement things they don’t use.**
- Split big interfaces into smaller, focused ones.
- Example: Instead of one `Animal` interface with `fly()`, `swim()`, `run()`, create separate interfaces like `Flyable`, `Swimmable`.

---

### 🛠️ D — Dependency Inversion Principle (DIP)
**Depend on abstractions, not concrete classes.**
- High-level modules shouldn’t depend on low-level ones.
- Example: Use interfaces so your code depends on behavior, not specific implementations.

---

### 🎯 Summary Table

| Principle | What It Means                        | Why It Helps                     |
|-----------|--------------------------------------|----------------------------------|
| SRP       | One class, one job                   | Easier to maintain               |
| OCP       | Extend without changing              | Safer updates                    |
| LSP       | Subclasses must be substitutable     | Reliable inheritance             |
| ISP       | Keep interfaces small and focused    | Cleaner design                   |
| DIP       | Depend on interfaces, not classes    | More flexible and testable code  |


197.Explain the Model Mapper class and how it is used to handle the result data set DAO Layer in a springboot application. 
How to parse the resultset data from controller layer to view layer ?

 Entity: Talks to the Database
- Represents a table in your database.
- Contains all fields, including sensitive ones like password, salary, etc.
- Used in the DAO layer (Data Access Object) to perform CRUD operations.
You can return an Entity directly to the view, but it’s not recommended because:
- It exposes internal database structure.
- It might leak sensitive data.
- It tightly couples your frontend to your database schema.

📦 DTO (Data Transfer Object): Talks to the View
- A custom class that contains only the fields you want to expose.
- Used in the Controller layer to send clean, safe data to the frontend.
- Decouples your internal logic from external consumers.
Think of DTOs as a filter or wrapper around your Entity.


## 🧠 What Is ModelMapper?

ModelMapper is a tool that helps you automatically copy data from an Entity to a DTO (or vice versa), so you don’t have to manually write:

dto.setName(entity.getName());
dto.setEmail(entity.getEmail());


Instead, you just write:
EmployeeDTO dto = modelMapper.map(employeeEntity, EmployeeDTO.class);


It saves time and keeps your code clean.


---

## 🏗️ Step-by-Step Architecture

```
DAO Layer (Entity) → Service Layer → Controller Layer (DTO) → View Layer (JSON/HTML)
```

---

## 🔧 Step 1: Add ModelMapper Dependency

If you're using Maven, add this to your `pom.xml`:

```xml
<dependency>
    <groupId>org.modelmapper</groupId>
    <artifactId>modelmapper</artifactId>
    <version>3.1.1</version>
</dependency>
```

---

## 🧩 Step 2: Configure ModelMapper as a Spring Bean

```java
@Configuration
public class ModelMapperConfig {
    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }
}
```

This allows you to `@Autowired` ModelMapper wherever needed.

---

## 🧱 Step 3: Create Entity and DTO Classes

### 🗃️ Entity (DAO Layer)

```java
@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private double salary; // Sensitive field

    // Getters and Setters
}
```

### 📦 DTO (Controller/View Layer)

```java
public class EmployeeDTO {
    private Long id;
    private String name;
    private String email;

    // No salary field exposed
    // Getters and Setters
}
```

---

## 🧪 Step 4: Service Layer — Mapping Entity to DTO

```java
@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ModelMapper modelMapper;

    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return employees.stream()
                .map(emp -> modelMapper.map(emp, EmployeeDTO.class))
                .collect(Collectors.toList());
    }
}
```

🔍 This converts each `Employee` entity into an `EmployeeDTO` using ModelMapper.

---

## 🚪 Step 5: Controller Layer — Return DTO to View

```java
@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public ResponseEntity<List<EmployeeDTO>> getEmployees() {
        List<EmployeeDTO> employeeDTOs = employeeService.getAllEmployees();
        return ResponseEntity.ok(employeeDTOs);
    }
}
```

📤 This sends a clean, secure JSON response to the frontend or API consumer.

---

## 🖼️ Step 6: View Layer (Frontend or API Consumer)

If you're using a frontend like React, Angular, or even Thymeleaf, the response will look like:

```json
[
  {
    "id": 1,
    "name": "Harish",
    "email": "harish@example.com"
  },
  ...
]
```

No sensitive fields like `salary` are exposed—thanks to DTOs and ModelMapper.

---

## ✅ Summary

- **ModelMapper** automates conversion between Entity and DTO.
- Keeps your layers decoupled and secure.
- Mapping happens in the **Service Layer**, not Controller.
- Controller returns DTOs to the View Layer (JSON or HTML).

198.Don't use spring data jpa, h2 and hibernate?Use only JDBC Template to retrieve data from DB
 
Perfect! Let’s build a **Spring Boot application using only JDBC Template**—no JPA, no Hibernate, no H2. Just clean, direct SQL access using JDBC Template to retrieve data from a real database like MySQL or PostgreSQL.

---

## 🧱 Project Structure Overview

```
src/
├── main/
│   ├── java/
│   │   └── com.example.demo/
│   │       ├── model/         → Entity class
│   │       ├── dao/           → DAO class using JdbcTemplate
│   │       ├── service/       → Business logic
│   │       └── controller/    → REST API
└── resources/
    └── application.properties → DB config
```

---

## 🧩 Step 1: Add Dependencies in `pom.xml`

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-jdbc</artifactId>
</dependency>

<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
</dependency>
```

---

## ⚙️ Step 2: Configure Database in `application.properties`

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/testdb
spring.datasource.username=root
spring.datasource.password=yourpassword
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

---

## 🧾 Step 3: Create Entity Class (`Employee.java`)

```java
public class Employee {
    private int id;
    private String name;
    private String email;

    // Getters and Setters
}
```

This is a plain Java object—no annotations like `@Entity`.

---

## 🗃️ Step 4: DAO Layer Using JdbcTemplate (`EmployeeDAO.java`)

```java
@Repository
public class EmployeeDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Employee> getAllEmployees() {
        String sql = "SELECT * FROM employee";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Employee.class));
    }
}
```

🔍 `BeanPropertyRowMapper` maps SQL result columns to Java fields automatically.

---

## 🧠 Step 5: Service Layer (`EmployeeService.java`)

```java
@Service
public class EmployeeService {

    @Autowired
    private EmployeeDAO employeeDAO;

    public List<Employee> fetchEmployees() {
        return employeeDAO.getAllEmployees();
    }
}
```

This layer handles business logic and calls the DAO.

---

## 🚪 Step 6: Controller Layer (`EmployeeController.java`)

```java
@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public List<Employee> getEmployees() {
        return employeeService.fetchEmployees();
    }
}
```

This exposes a REST endpoint: `GET /employees` returns all employee records as JSON.

---

## 🧪 Sample Output

```json
[
  {
    "id": 1,
    "name": "Harish",
    "email": "harish@example.com"
  },
  {
    "id": 2,
    "name": "Priya",
    "email": "priya@example.com"
  }
]
```

---

## ✅ Summary

| Layer        | Role                                      |
|--------------|-------------------------------------------|
| Entity       | Plain Java class to hold data             |
| DAO          | Uses JdbcTemplate to run SQL queries      |
| Service      | Contains business logic                   |
| Controller   | Exposes REST API                          |

No JPA. No Hibernate. No H2. Just **pure JDBC** with Spring Boot.

Want to add insert/update/delete operations next? Or connect to PostgreSQL instead of MySQL? I can guide you through that too.

199. Multithread and concurrent multi-thread ?
Banking Example
- Multithreading: One ATM machine handles multiple users by switching between them quickly.
- Concurrent multithreading: Multiple ATM machines serve multiple users at the same time.

200.what is multi-tenancy in springboot ?
Multi-tenancy in Spring Boot means building an application that can serve multiple customers (tenants) from a single codebase, while keeping each tenant’s data isolated and secure.
Why Use Multi-Tenancy?
- ✅ Cost-effective: One app, many clients.
- ✅ Easier maintenance: Centralized updates.
- ✅ Scalable: Add new tenants without duplicating code.
Absolutely! Let me break it down in a **simple and clear way** so it makes sense:

---

### 🏢 What Is Multi-Tenancy?
Imagine you're building one app that serves **multiple companies or clients** (called "tenants"). Each tenant should feel like they have their own private space, but you're running **just one app**.


201. Event driven communication in micorservices ?
Got it! You're asking for a **step-by-step explanation** of the **event-driven code** I shared earlier using Spring Boot. Let's walk through it slowly and clearly 💡

---

## 🧩 Goal of the Code

We want to simulate **event-driven communication** between microservices using Spring Boot.  
When a user transfers money, we **publish an event**, and another service **listens** and reacts to it.

---

## ✅ Step-by-Step Breakdown

### 1. **Create the Event Class**

```java
public class MoneyTransferredEvent {
    public String from;
    public String to;
    public double amount;

    public MoneyTransferredEvent(String from, String to, double amount) {
        this.from = from;
        this.to = to;
        this.amount = amount;
    }
}
```

🔹 This is a simple Java class that holds the event data:  
- Who sent the money (`from`)  
- Who received it (`to`)  
- How much (`amount`)  

This class is like a **WhatsApp message** that carries the transaction info.

---

### 2. **Publish the Event (TransactionService)**

```java
@Autowired
private ApplicationEventPublisher publisher;

@PostMapping("/transfer")
public String transferMoney(@RequestParam String from, @RequestParam String to, @RequestParam double amount) {
    MoneyTransferredEvent event = new MoneyTransferredEvent(from, to, amount);
    publisher.publishEvent(event); // 🔔 Sends the event
    return "Money transferred!";
}
```

🔹 What happens here:
- You call `/transfer?from=A&to=B&amount=5000`
- Spring creates a `MoneyTransferredEvent` object
- `publisher.publishEvent(event)` sends the event to all listeners

This is like **sending a broadcast message** to all departments.

---

### 3. **Listen to the Event (NotificationService)**

```java
@Component
public class NotificationListener {

    @EventListener
    public void handleTransfer(MoneyTransferredEvent event) {
        System.out.println("📲 SMS: ₹" + event.amount + " transferred from " + event.from + " to " + event.to);
    }
}
```

🔹 What happens here:
- Spring sees that this method is marked with `@EventListener`
- When the event is published, Spring automatically calls this method
- It prints an SMS message to the console

This is like the **Notification Department** hearing the broadcast and sending an SMS.

---

## 🧠 Summary

| Role                  | What It Does                                |
|-----------------------|---------------------------------------------|
| `MoneyTransferredEvent` | Holds the transaction data                 |
| `ApplicationEventPublisher` | Sends the event to all listeners     |
| `@EventListener`      | Reacts to the event when it’s received      |

---

Would you like me to show how to add another listener (like AuditService) or how to send this event across real microservices using Kafka or RabbitMQ? We can build it step by step.

============================================================================================

Ah, now I understand! You're asking for the **typical class structure** in an **event-driven Spring Boot application**—just like we organize code into `Controller`, `Service`, `Repository`, etc.

Let’s lay out the **clean structure** for an event-driven setup 👇

---

## 🧱 Event-Driven Spring Boot Structure

### 1. **Event Class** (`event` package)
Defines the data that gets passed around.

```java
// 📦 com.example.event
public class MoneyTransferredEvent {
    private String from;
    private String to;
    private double amount;
    // Constructor, getters, setters
}
```

---

### 2. **Controller Class** (`controller` package)
Handles HTTP requests and triggers the event.

```java
// 📦 com.example.controller
@RestController
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/transfer")
    public String transfer(@RequestParam String from, @RequestParam String to, @RequestParam double amount) {
        return transactionService.transferMoney(from, to, amount);
    }
}
```

---

### 3. **Service Class** (`service` package)
Contains business logic and publishes the event.

```java
// 📦 com.example.service
@Service
public class TransactionService {

    @Autowired
    private ApplicationEventPublisher publisher;

    public String transferMoney(String from, String to, double amount) {
        MoneyTransferredEvent event = new MoneyTransferredEvent(from, to, amount);
        publisher.publishEvent(event);
        return "Money transferred!";
    }
}
```

---

### 4. **Listener Class** (`listener` package)
Listens for events and reacts.

```java
// 📦 com.example.listener
@Component
public class NotificationListener {

    @EventListener
    public void handleTransfer(MoneyTransferredEvent event) {
        System.out.println("📲 SMS: ₹" + event.getAmount() + " transferred from " + event.getFrom() + " to " + event.getTo());
    }
}
```

---

### 5. **Repository Class** (optional, if you store data) (`repository` package)

```java
// 📦 com.example.repository
@Repository
public interface TransactionRepository extends JpaRepository<TransactionEntity, Long> {
}
```

---

## 📦 Suggested Package Structure

```
com.example
├── controller
│   └── TransactionController.java
├── service
│   └── TransactionService.java
├── event
│   └── MoneyTransferredEvent.java
├── listener
│   └── NotificationListener.java
├── repository
│   └── TransactionRepository.java
```

---

Would you like me to generate all these files with full code so you can copy-paste them into your project? I’d be happy to help!

202. Pagination in sprinboot ?
Here’s a **simple syntax** for pagination in Spring Boot using Spring Data JPA:

---
* Create a Repository :
public interface ProductRepository extends JpaRepository<Product, Long> {
    Page<Product> findByNameContaining(String name, Pageable pageable);
}

### ✅ Controller Method with Pagination

```java
@GetMapping("/products")
public Page<Product> getProducts(
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "5") int size) {
    Pageable pageable = PageRequest.of(page, size);
    return productRepository.findAll(pageable);
}
```

---

### 🧠 Explanation

- `page`: Page number (starts from 0)
- `size`: Number of records per page
- `PageRequest.of(page, size)`: Creates a pagination object
- `findAll(pageable)`: Fetches paginated data

---

### 🖥️ Sample API Call

```
GET /products?page=1&size=5
```

203. static methods vs static variables
In Java, **static methods and static variables cannot be overridden**, but they **can be hidden or shadowed**. Here's a clear breakdown:

---

### 🚫 Static Methods: Cannot Be Overridden

- Static methods belong to the **class**, not the instance.
- If you define a static method with the same name in a subclass, it's called **method hiding**, not overriding.

#### Example:

```java
class Parent {
    static void show() {
        System.out.println("Parent static method");
    }
}

class Child extends Parent {
    static void show() {
        System.out.println("Child static method");
    }
}

public class Main {
    public static void main(String[] args) {
        Parent p = new Child();
        p.show(); // Output: Parent static method
    }
}
```

🧠 Even though `p` refers to a `Child` object, it calls `Parent.show()` because static methods are resolved at **compile time** using the reference type.

---

### 🚫 Static Variables: Cannot Be Overridden

- Static variables are also tied to the **class**, not the object.
- You can **declare a variable with the same name** in a subclass, but it **shadows** the parent’s variable.

#### Example:

```java
class Parent {
    static String role = "Admin";
}

class Child extends Parent {
    static String role = "User";
}

public class Main {
    public static void main(String[] args) {
        System.out.println(Parent.role); // Output: Admin
        System.out.println(Child.role);  // Output: User
    }
}
```

---

### ✅ Summary

| Feature          | Can Override? | Behavior         |
|------------------|---------------|------------------|
| Static Method     | ❌ No          | Hidden (compile-time binding) |
| Static Variable   | ❌ No          | Shadowed (class-level access) |

Let me know if you'd like to see how this differs from instance method overriding or polymorphism!

204. Kubernetes Architecture Overview ?
Kubernetes is an open-source platform that automates deployment, scaling, and management of containerized applications.

Kubernetes is made up of two main parts:

1. Control Plane (Brain of the cluster)
Manages the cluster and makes global decisions.
|  |  | 
| kube-apiserver |  | 
| etcd |  | 
| kube-scheduler |  | 
| kube-controller-manager |  | 
| cloud-controller-manager |  | 



2. Worker Nodes (Muscles of the cluster)
Run your actual applications inside containers.
|  |  | 
| kubelet |  | 
| kube-proxy |  | 
| Container Runtime |  | 



🔄 How It Works (Flow)
- You define a deployment or service using YAML or kubectl.
- The API server receives the request.
- The scheduler picks a node to run the pod.
- The kubelet on that node starts the container.
- The controller manager ensures the desired state is maintained.
- The proxy handles networking so services can talk to each other.

📦 Bonus Concepts
- Pod: Smallest deployable unit; one or more containers.
- Service: Stable endpoint to access pods.
- Deployment: Manages replicas and updates.
- Namespace: Logical grouping of resources.

Would you like a visual diagram or a YAML example to see how these components interact in practice?

204. Difference between synchronized and ReentrantLock ?
✅ synchronized Example
public synchronized void accessResource() {
    // Only one thread can enter here at a time
}


✅ ReentrantLock Example
ReentrantLock lock = new ReentrantLock();

public void accessResource() {
    lock.lock();
    try {
        // Critical section
    } finally {
        lock.unlock(); // Always unlock in finally block
    
When to Use What
- Use synchronized for simple locking needs — it's concise and built-in.
- Use ReentrantLock when you need:
- Try-lock or timed lock
- Interruptible lock
- Fairness or advanced signaling

205.Bulkhead threadpool in circuit breaker ?
Bulkhead threadpool in circuit breakers helps isolate failures and limit resource usage by assigning dedicated thread pools to service calls.

When combined with a circuit breaker, the bulkhead pattern adds an extra layer of protection:
- Circuit Breaker: Detects failures and stops calls to a failing service.
- Bulkhead Thread Pool: Limits the number of concurrent calls using a dedicated thread pool.
This setup ensures:
- One failing service doesn’t exhaust all threads.
- Other services remain responsive.


## 🧩 Updated Code with Bulkhead Thread Pool

```java
@Bulkhead(name = "calculatorServiceBulkhead", type = Bulkhead.Type.THREADPOOL)
@CircuitBreaker(name = "calculatorServiceCB", fallbackMethod = "fallbackWelcome")
@GetMapping("/getsampletest")
public String Sample() {
    return feignInterface.getWelcomeMessage();
}

public String fallbackWelcome(Throwable t) {
    return "Fallback response: Calculator service is currently unavailable.";
}
```

---

## ⚙️ Configuration in `application.yml`

```yaml
resilience4j:
  bulkhead:
    instances:
      calculatorServiceBulkhead:
        type: THREADPOOL
        maxThreadPoolSize: 10
        coreThreadPoolSize: 5
        queueCapacity: 20

  circuitbreaker:
    instances:
      calculatorServiceCB:
        slidingWindowSize: 10
        failureRateThreshold: 50
        waitDurationInOpenState: 10s
```

---

## ✅ What This Does

- **Bulkhead:** Limits concurrent calls using a thread pool (`calculatorServiceBulkhead`)
- **Circuit Breaker:** Opens if failure rate exceeds 50% (`calculatorServiceCB`)
- **Fallback:** Provides a safe response when the circuit is open or thread pool is exhausted






