1.What is microservices?
Microservice is a small, loosely coupled distributed service.
Independent services that communicate with each other over a network. 
Each microservice is designed to perform a specific business function and can be developed, deployed, and scaled independently. 

2.Benefits of Microservices?
scalability(Dynamic scaling), ease of maintenance, technology flexibility(New technology adoption), Faster Release cycle and improved fault isolation.
 
3.Microservices how communicates with each other?
Using HTTP/REST API
HTTP/REST: These are light-weight protocols used for perform communication between two services.(Synchoronized)
Message queues: Message queues such as Kafka or RabbitMQ used to make connection.(Asynchoronized)
RPC(Remote Procedure Call) Framework: RPC frameworks such as gRPC uses in services for communication purposes.(Synchoronized)

Http-> Rest template ->Synchoronized
       web client    ->ASynchoronized (we can block)
	   feign client   ->Synchoronized

4.What is the difference between monolithic and microservices architecture?
Monolithic architecture involves building an application as a single,tightly-coupled unit.
while microservices divide it into smaller, independent components.

5.Explain service discovery in microservices?
service discovery plays a crucial role in enabling communication and collaboration between these services

Service Registry
- Think of it as the address book 📖.
- It stores the locations (IP/port) of all services in your system.
- Services register themselves here when they start.
🧭 Service Discovery
- This is the lookup process 🔎.
- When one service wants to talk to another, it queries the registry to find where that service is running.
- It’s like asking, “Where’s the payment service?” and getting the current address.

- The registry is the list of restaurants and their addresses.
- Discovery is when the app checks that list to find where to send your order.
So they’re not the same, but they work together. Registry is the database; discovery is the search engine.

6.Explain the design patterns of Java Spring Boot Microservices?
Service Registry: Services automatically register in a central registry, allowing others to identify and interact with them dynamically.
API Gateway: It acts as a customer entry point and forwards requests to appropriate microservices to provide additional functionality such as authentication and rate limits.
Circuit Breaker: It monitors the availability of services and protects from failures by sending requests or by providing responses if service is unavailable.
CQRS (Command Query Responsibility Segregation): It separates the read and write operations. Also, it optimizes each and every operation separately for efficiency.
Saga Pattern: It manages distributed tasks by organizing a sequence of local transactions.
Database per service: Each of the services has separate databases. This ensures data isolation and also enables scaling and individual development.
Asynchronous messaging: Each services communicate with each other through message queues like Kafka or RabbitMQ.

7.What are the Main Components of Java Spring Boot Microservices?
Services
Service Registry
API Gateway
Cloud Infrastructure
Containerization and Orchestration
Message Broker
Security
Monitoring

8.Name three commonly used tools for Java Spring Boot Microservices?
Zookeeper also used.It is not always required in every microservice environment.Comparatively,below tools are efficient.
Docker
Kubernetes
Spring Cloud

9.How to Process the Request and Response between Two Services?
By establishing communication between the two services, microservices can handle requests and responses between any two services using XML (Extensible Mark-up Language) and JSON (JavaScript Object Notation).

XML and JSON are data exchange formats and it helps to generate requests and responses between two services.
Most important thing is the data exchange format and both the services have to know the data exchange format to request and respond accordingly.
If we compare both formats, JSON is very simple to use in Microservices.

10.How does Microservice Architecture work?
Working of Microservices Architecture - Microservices Interview Questions - Edureka
Fig 5: Architecture of Microservices

- Clients – These are the passengers (users) coming from different places (devices) and requesting a service (boarding their flight).
- Identity Providers – Like passport control, they verify a person's identity and issue a security token (boarding pass) that allows access.
- API Gateway – Acts like the airport check-in counter, handling client requests and directing them to the correct service.
- Static Content – The airport's information boards and kiosks where fixed details (like flight schedules) are stored.
- Management – The air traffic control tower, making sure everything runs smoothly, balancing services, and identifying problems (delays, failures).
- Service Discovery – Like a GPS for pilots, it helps services find each other and figure out the best route for communication.
- Content Delivery Networks (CDNs) – These are like multiple airports worldwide, ensuring fast and efficient access to essential information.
- Remote Service – Similar to a pilot remotely accessing navigation data and airport information over a network.

11.Disadvantage or challanges of Microservices?
Require heavy investment
Heavy Infrastructure Setup
Excessive Planning for managing operations overhead
Staff Selection and maintenance

12.Define coupling and how the microservices are coupled.
It represents proximity connected to two modules or coupled.The microservices are loosely coupled with one another.

13.what are the popular companies using the microservices?
Microsoft, Twitter, Amazon, Uber, Netflix.

14.Describe the three types of tests for Microservices?
General tests: In this category come the performance and unit tests at the bottom level. Such tests are fully automated.
Exploratory tests: These tests are performed at the middle level. Usability tests and stress tests fall into this category.
Acceptance tests: These tests are performed at the top level. Mostly, they are fewer in numbers. The same assists stakeholders in getting an idea of varied software features.

====================**************==================================================
- Unit Tests – These focus on individual components of a microservice, verifying that methods, functions, or modules work correctly in isolation. They're fast, automated, and provide immediate feedback.
- Integration Tests – These check interactions between microservices, ensuring they communicate as expected via APIs, message queues, or databases. They help identify issues with data flow and dependency management.
- End-to-End Tests – These evaluate the entire microservices system from the client's perspective, simulating real-world usage scenarios to confirm that all services work together seamlessly.


15.Why do Microservices use containers?
Containers are the easiest and most effective method to manage the microservice-based application. There are several reasons to support this:
Isolation: Containers provide lightweight, isolated environments for running individual microservices. Each microservice can be packaged as a container image along with its dependencies, libraries, and runtime environment.
Portability: Microservices packaged as containers can be easily moved and deployed across various infrastructure platforms, such as on-premises servers, public clouds, and hybrid environments.
Consistency: By packaging microservices as container images, organizations can maintain consistent runtime environments and dependencies across different stages of the software development lifecycle.
Resource Efficiency: Containers are lightweight and consume fewer resources compared to virtual machines (VMs). This resource efficiency is particularly beneficial in microservices architectures with large numbers of services and instances.
Scalability: Containers support horizontal scaling, allowing organizations to scale individual microservices independently based on demand.
Lifecycle Management: Containers provide tools and APIs for managing the lifecycle of microservices, including image creation, deployment, versioning, scaling, and orchestration.
DevOps Practices: Containers align with DevOps practices and enable organizations to automate the software delivery pipeline from development to production.


Note:Containers are a lightweight, efficient and standard way for applications to move between environments and run independently.

16.What is API Gateway?
Aggregation: The API gateway can combine multiple backend microservices' responses into a single cohesive response to fulfill a client request. This reduces round-trips.
Load balancing: The gateway can distribute incoming requests across multiple instances of the same microservice to ensure optimal resource utilization and high availability.
Authentication and authorization: It can handle security-related concerns by authenticating clients and authorizing access to specific microservices.
Caching: The API gateway can cache responses from microservices to improve performance and reduce redundant requests.
Protocol translation: It can translate client requests from one protocol (e.g., HTTP/REST) to the appropriate protocol used by the underlying microservices.

Note:An API Gateway acts as a middleman between clients and a group of backend services in a microservices setup.

17.What is end-to-end testing of Microservices? How to implement it for microservices applications?
End-to-end testing authenticates every workflow process to ensure everything works flawlessly.
The corresponding tests can encompass the gaps during integration testing or unit testing.

End-to-end testing of microservices involves validating the complete system workflow.
Ensuring all microservices interact correctly and meet business requirements in a production-like environment.

18.What Is Spring Boot? How to implement Microservices using Spring Boot?
Spring Boot is an open-sourced, Java-based framework that provides an excellent platform for developing a stand-alone and production-grade spring application.
It is easy to understand, increases productivity, and reduces development time.
It automatically configures a claim based on the added dependencies of an application.

19.What is Spring Cloud?
Spring Cloud provides tools for developers to quickly build some of the common patterns in distributed systems.

20.What is an Actuator?
The actuator is primarily used to render operational information regarding the various parameters of a running application.
These parameters are metrics, health, dump, info, env, etc.
For smooth interaction, it makes use of JMX beans or HTTP endpoints.

21.What is the need for reports and dashboards in Microservices?
Reports and dashboards are useful for monitoring and maintenance of microservices.

22.What is Distributed Transaction? What are its associated challenges?
A distributed transaction involves multiple services that need to work together to complete a transaction.
each service may have its own database, and transactions that require data from multiple services may need to coordinate the work of all these services to ensure that the transaction is completed successfully.
Challanges:
1.Complexity
2.Failure Handling
3.Scalability
4.Latency


23.What is OAuth?
OAuth is the full form of Open-standard Authorization Protocol.
It provides the framework to obtain limited access to a protected resource by a third-party application on behalf of the resource owner.
OAuth also enables access to the resources from the resource owner.
It does so by permitting the client applications on third-party providers like GitHub, Facebook, etc.

24.What do you understand about Cohesion and Coupling?
Cohesion is the concept of an intro-module. Coupling is the concept of inter-module. 
Cohesion represents the relationship within a module.Coupling represents the relationships between modules

25.what is kafka?
   producer         zookeeper tool
      /                 /
	  /             kafka cluster(Group of server working together called brokers)
                        /
  kafka broker1====kafka broker2
        /
		/   
   consumer
 
 
Kafka is like a server.Producing the message from producer or kafka cluster its manage the topics for kafka broker and send to proper order to consumer.
 

26.circuit Breaker architecture? (using resilience 4j implement the circuitbreaker)
            closed
			     
	open             half open
	

Closed(+ve) ==>If A and B services both are working fine circuitbreaker is working closed state.
open(-ve)   ==> B giving some error it will go to the open state.
halfopen    ==>Here,we setting time for 2 services for recovering incase,it is not recover again its going to the open.It               will recover means its going to the closed state.


27.Saga pattern?
Flight Service: Reserves a flight.
Payment Service: Charges the user.
Notification Service: Sends a confirmation email.

If the payment fails, the saga rolls back the flight reservation.
If any part of the saga fails (e.g., payment fails), compensating actions (e.g., canceling flight reservations or refunding payments) are triggered.
===========================================================


28.Bean Scope:
Singleton Scope.
Prototype Scope.
Request scope.
Session Scope.
Application Scope or Global scope

29.Fault tolerant:
Identify the failure service.

30.Setter Injection in Spring Boot
Setter Injection is one of the ways to inject dependencies into Spring beans. It is done by defining setter methods in your classes and annotating them with @Autowired. This allows Spring to inject the dependency after the bean is created (through setter methods).

31.@Transactional:
@Transactional: The annotation ensures that all database operations within the method are part of a single transaction. If an exception occurs, the transaction is rolled back.
Rollback behavior: In the example above, if the name is "error", an exception is thrown, which will trigger a rollback for the createUserWithTransaction method, meaning no user will be created in the database.



32.explain monolithic architecture:

 ----------------------------------------------
|                Monolithic Application        |
|----------------------------------------------|
|  UI Layer (Frontend)                         |
|  --------------------------                  |
|  Business Logic Layer (Backend)              |
|  --------------------------                  |
|  Data Access Layer (Database interaction)    |
|  --------------------------                  |
|  Data Storage (Database)                     |
 ----------------------------------------------
                |
                |
          Single Deployment
Explanation of the diagram:
Monolithic Application: The entire application is contained within a single unit, from the user interface (UI) to business logic to data access and database storage.
UI Layer (Frontend): Handles user interactions, displaying the user interface.
Business Logic Layer (Backend): Manages the application's core functionality, such as processing data, implementing rules, and making decisions.
Data Access Layer: Communicates with the database or any other data storage system to retrieve and persist data.
Data Storage: This is where all your data (e.g., database) resides. All components in the application interact with this storage.

33.Caching: Cache stores frequently accessed data close to the microservice which improved performance by reducing the repetitive queries.

34. Blue and green deployment?
Blue-Green Deployment is a clever strategy used in software development to release new versions with zero downtime and minimal risk. Think of it like having two identical stages — one live, one waiting in the wings.

How It Works:
- Deploy to Green: You deploy the new version to the green environment.
- Test in Green: Run all tests and validations without affecting users.
- Switch Traffic: Once you're confident, redirect user traffic from blue to green (via load balancer or DNS).
- Monitor: Watch the green environment closely for issues.
- Rollback if Needed: If something breaks, switch traffic back to blue instantly.

- Before deployment: Blue = primary, Green = secondary.
- After deployment: Green = primary, Blue = secondary.


35.KAFKA example program:
Got it! Let’s simplify the explanation using the **Kafka Producer** and **Kafka Consumer** Java code from earlier. This way, you’ll have a better understanding of how these components work together.

Setup Instructions
1. Kafka Installation
- You're starting Zookeeper and Kafka broker correctly.
- This enables message publishing and consumption.
# Start Zookeeper
bin/zookeeper-server-start.sh config/zookeeper.properties

# Start Kafka
bin/kafka-server-start.sh config/server.properties


2. Common Dependencies (pom.xml)
Add these to each microservice:
<dependency>
  <groupId>org.springframework.kafka</groupId>
  <artifactId>spring-kafka</artifactId>
</dependency>



3.OrderService (Producer)
OrderController.java
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @PostMapping
    public ResponseEntity<String> createOrder(@RequestBody String order) {
        kafkaTemplate.send("order-topic", order);
        return ResponseEntity.ok("Order created");
    }
}

application.properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer
spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerializer

4.InventoryService (Consumer)
InventoryListener.java
@Component
public class InventoryListener {

    @KafkaListener(topics = "order-topic", groupId = "inventory")
    public void listen(String order) {
        System.out.println("Inventory updated for order: " + order);
    }
}


application.properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=inventory
spring.kafka.consumer.auto-offset-reset=earliest //optional
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer


5.NotificationService (Consumer)
Similar to InventoryService, just change the group ID and logic inside the listener:
@KafkaListener(topics = "order-topic", groupId = "notification-group")
public void sendNotification(String order) {
    System.out.println("Notification sent for order: " + order);
}

application.properties:
# Kafka broker address
spring.kafka.bootstrap-servers=localhost:9092

# Unique group ID for NotificationService
spring.kafka.consumer.group-id=notification-group

# Deserializers for incoming messages
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer

# Optional: start reading from the beginning if no offset is found
spring.kafka.consumer.auto-offset-reset=earliest

 Event Flow Summary
[OrderService] --(order-topic)--> [Kafka Broker] --(order-topic)--> [InventoryService]
                                                   └───────────────> [NotificationService]

- OrderService publishes to order-topic.
- InventoryService and NotificationService consume independently using different group IDs.


✅ Benefits of This Architecture
- Loose coupling between services
- Scalability via Kafka partitions
- Resilience through asynchronous messaging


36. Saga pattern?

Perfect! Here's a complete **Spring Boot Kafka Saga Choreography example** using your preferred style — simple REST API producer and multiple consumers — with clean code and configuration.

## 🧾 1. **OrderService (Producer Only)**

### `OrderController.java`

```java
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @PostMapping
    public ResponseEntity<String> createOrder(@RequestBody String order) {
        kafkaTemplate.send("order-topic", order);
        return ResponseEntity.ok("Order created");
    }
}
```

### `application.properties`

properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer
spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerializer
```

---

## 💳 2. **PaymentService (Consumer Only)**

### `PaymentListener.java`

```java
@Component
public class PaymentListener {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @KafkaListener(topics = "order-topic", groupId = "payment-group")
    public void handleOrder(String order) {
        System.out.println("Received order for payment: " + order);

        boolean paymentSuccess = simulatePayment(order);

        if (paymentSuccess) {
            kafkaTemplate.send("payment-success-topic", order);
        } else {
            kafkaTemplate.send("payment-failure-topic", order);
        }
    }

    private boolean simulatePayment(String order) {
        return !order.contains("fail"); // simulate failure if order contains "fail"
    }
}
```

### `application.properties`

```properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=payment-group
spring.kafka.consumer.auto-offset-reset=earliest
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer
spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerializer
```

---

## 📦 3. **InventoryService (Consumer Only)**

### `InventoryListener.java`

```java
@Component
public class InventoryListener {

    @KafkaListener(topics = "payment-success-topic", groupId = "inventory-group")
    public void reserveInventory(String order) {
        System.out.println("Inventory reserved for order: " + order);
    }

    @KafkaListener(topics = "payment-failure-topic", groupId = "inventory-group")
    public void rollbackInventory(String order) {
        System.out.println("Inventory rollback for failed order: " + order);
    }
}
```

### `application.properties`

```properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=inventory-group
spring.kafka.consumer.auto-offset-reset=earliest
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer
```

---

## ❌ 4. **OrderCancelService (Consumer Only)**

### `OrderCancelListener.java`

```java
@Component
public class OrderCancelListener {

    @KafkaListener(topics = "payment-failure-topic", groupId = "order-cancel-group")
    public void cancelOrder(String order) {
        System.out.println("Order canceled due to payment failure: " + order);
    }
}
```

### `application.properties`

```properties
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=order-cancel-group
spring.kafka.consumer.auto-offset-reset=earliest
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer
```

---

## 🧪 How to Test

1. Start Kafka locally (e.g., using Docker) and all services.
2. Send a POST request to `http://localhost:8080/orders` with a JSON string
   - `"Order#123"` → triggers success flow
   - `"Order#fail"` → triggers failure flow
3. Watch logs in each service for correct event handling.


============================************************===========================================================

Absolutely! Here's a **simple Spring Boot orchestration-based Saga pattern** using REST APIs and Kafka. In this setup, a central **OrchestratorService** coordinates the flow between services.

---

## 🧭 Architecture Overview

- **OrchestratorService**: Receives order and coordinates the saga.
- **OrderService**: Creates the order.
- **PaymentService**: Processes payment.
- **InventoryService**: Reserves inventory.
- **NotificationService**: Sends confirmation.

Each service exposes REST endpoints. The orchestrator calls them in sequence.

---

## 🧾 1. OrchestratorService

### `OrchestratorController.java`

```java
@RestController
@RequestMapping("/saga")
public class OrchestratorController {

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("/start")
    public ResponseEntity<String> startSaga(@RequestBody String order) {
        try {
            restTemplate.postForEntity("http://localhost:8081/order", order, String.class);
            restTemplate.postForEntity("http://localhost:8082/payment", order, String.class);
            restTemplate.postForEntity("http://localhost:8083/inventory", order, String.class);
            restTemplate.postForEntity("http://localhost:8084/notification", order, String.class);
            return ResponseEntity.ok("Saga completed successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Saga failed: " + e.getMessage());
        }
    }
}


### `application.properties`

```properties
server.port=8080
```

---

## 📦 2. OrderService

### `OrderController.java`

```java
@RestController
public class OrderController {

    @PostMapping("/order")
    public ResponseEntity<String> createOrder(@RequestBody String order) {
        System.out.println("Order created: " + order);
        return ResponseEntity.ok("Order created");
    }
}
```

### `application.properties`

```properties
server.port=8081
```

---

## 💳 3. PaymentService

### `PaymentController.java`

```java
@RestController
public class PaymentController {

    @PostMapping("/payment")
    public ResponseEntity<String> processPayment(@RequestBody String order) {
        if (order.contains("fail")) {
            throw new RuntimeException("Payment failed");
        }
        System.out.println("Payment processed for: " + order);
        return ResponseEntity.ok("Payment successful");
    }
}
```

### `application.properties`

```properties
server.port=8082
```

---

## 📦 4. InventoryService

### `InventoryController.java`

```java
@RestController
public class InventoryController {

    @PostMapping("/inventory")
    public ResponseEntity<String> reserveInventory(@RequestBody String order) {
        System.out.println("Inventory reserved for: " + order);
        return ResponseEntity.ok("Inventory reserved");
    }
}
```

### `application.properties`

```properties
server.port=8083
```

---

## 📢 5. NotificationService

### `NotificationController.java`

```java
@RestController
public class NotificationController {

    @PostMapping("/notification")
    public ResponseEntity<String> sendNotification(@RequestBody String order) {
        System.out.println("Notification sent for: " + order);
        return ResponseEntity.ok("Notification sent");
    }
}
```

### `application.properties`

```properties
server.port=8084
```

---

## 🧪 How to Test

1. Run all services on ports 8080–8084.
2. Send a POST request to `http://localhost:8080/saga/start` with:
   - `"Order#123"` → success flow
   - `"Order#fail"` → payment fails, saga stops




Here’s a clear and concise **comparison table** between the **Saga Pattern using Choreography vs Orchestration** — perfect for interview prep:

---

### 🧭 Choreography vs Orchestration

| Feature                     | **Choreography** 🩰                            | **Orchestration** 🎯                       
|----------------------------|-----------------------------------------------|----------------------------------------------|
| **Control Flow**           | Decentralized — each service reacts to events | Centralized — one orchestrator controls flow |
| **Communication Style**    | Event-driven (e.g., Kafka, RabbitMQ)          | Direct API calls or commands                 |
| **Coupling**               | Loosely coupled                               | Tightly coupled to orchestrator              |
| **Scalability**            | High — easy to add new services               | Moderate — orchestrator can be a bottleneck |
| **Visibility**             | Harder to trace — events are scattered        | Easier to trace — logic is centralized       |
| **Error Handling**         | Distributed — each service handles its own    | Centralized — orchestrator manages rollback |
| **Flexibility**            | High — services evolve independently          | Lower — changes affect orchestrator logic   |
| **Debugging**              | Complex — needs event tracing tools           | Easier — single point of control             |
| **Best For**               | Reactive, scalable systems                    | Complex workflows with strict control        |
| **Example Tools**          | Kafka, RabbitMQ, EventBridge                  | Camunda, Temporal, Spring Orchestration     |

---

### 🧠 Interview Tip

You can say:
> “I’d choose choreography for modular, event-driven systems, and orchestration when I need centralized control and complex rollback logic. Both patterns are valuable depending on the business needs.”

Would you like a diagram or a mock interview question set next?

37. What Is CQRS?
CQRS is a design pattern that separates read operations (queries) from write operations (commands) in an application.
🔄 Traditional CRUD
- One service handles both reads and writes.
- Can become complex and hard to scale.
🧭 CQRS Approach
- Command Side: Handles writes (create, update, delete).
- Query Side: Handles reads (fetch, search).
- Each side can have its own model, database, and scaling strategy.


38. Synchoronized using Rest Template concept?
First service:

Main method:
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class CalculatorSecoundMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculatorSecoundMicroservicesApplication.class, args);
	}

}

Entity:

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class CalculatorEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private String name;
    private double mobileNo;

    public CalculatorEntity() {
    }

    public CalculatorEntity(int id, String name, double mobileNo) {
        this.id = id;
        this.name = name;
        this.mobileNo = mobileNo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(double mobileNo) {
        this.mobileNo = mobileNo;
    }
}


Interface:

import org.springframework.data.jpa.repository.JpaRepository;

public interface CalcualtorRepo extends JpaRepository<CalculatorEntity, Integer> {
}

Controller:

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class CalculatorController {

    @Autowired
    private CalcualtorRepo calcualtorRepo;

    @Value("${server.port}")
    private String port;
	
	@GetMapping("/getCalProdName/{id}")
    public ResponseEntity<CalculatorEntity> getById(@PathVariable int id) {
        Optional<CalculatorEntity> cal = calcualtorRepo.findById(id);
        System.out.println("Hello from port " + port);
        return cal.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    @PostMapping("/postCal")
    public ResponseEntity<CalculatorEntity> receiveCal(@RequestBody CalculatorEntity cal) {
        // You can add validation or processing logic here
        CalculatorEntity c=   calcualtorRepo.save(cal);
        return ResponseEntity.ok(c); // Echoes back the received object
    }


application.properties:
spring.application.name=CalculatorSecoundMicroservices
server.port=8082

eureka.client.service-url.defaultzone=http://localhost:8761/eureka
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=password
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
logging.level.feign=DEBUG
logging.level.org.springframework.cloud.openfeign=DEBUG

===============================================================================================================
Second service:

Main method:
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients(basePackages = "com.example.demo")
public class SampleMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleMicroservicesApplication.class, args);
	}

}

Entity:

Entity
public class CalculatorEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private String name;
    private double mobileNo;
    public CalculatorEntity() {
    }


    public CalculatorEntity(int id, String name, double mobileNo) {
        this.id = id;
        this.name = name;
        this.mobileNo = mobileNo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(double mobileNo) {
        this.mobileNo = mobileNo;
    }
}

Interface:

import com.example.demo.Entity.CalculatorEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SampleRepo extends JpaRepository<CalculatorEntity, Integer> {
}

Controller:

import com.example.demo.Entity.CalculatorEntity;
import com.example.demo.FeignInterface;
import com.example.demo.Repositary.SampleRepo;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;


import java.util.List;

@RestController
public class SampleController {

    @Autowired
    private SampleRepo sampleRepo;

    @Autowired
    private  RestTemplate restTemplate;

    @Value("${server.port}")
    private String port;
	
	@GetMapping("/getSampleMicro/{id}")
    public ResponseEntity<List<CalculatorEntity>> SampleProd(@PathVariable int id)
    {

        String url= "http://localhost:8082/getCalProdName/{id}" ;
        CalculatorEntity cal= restTemplate.getForObject(url,CalculatorEntity.class,id);
        List<CalculatorEntity> allEntities = sampleRepo.findAll();
        allEntities.add(cal);
        return ResponseEntity.ok(allEntities);
    }

    @PostMapping("/postSample")
    public ResponseEntity<CalculatorEntity> create(@RequestBody CalculatorEntity cal)
    {
        String url = "http://localhost:8082/postCal" ;
        CalculatorEntity ca=restTemplate.postForObject(url,cal, CalculatorEntity.class);
        return  ResponseEntity.ok(sampleRepo.save(ca));

    }


application.properties:
spring.application.name=SampleMicroservices
server.port=8081
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=password
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
logging.level.feign=DEBUG
logging.level.org.springframework.cloud.openfeign=DEBUG

eureka.client.service-url.defaultzone=http://localhost:8761/eureka
eureka.instance.hostname=localhost
eureka.instance.prefer-ip-address=true
management.endpoints.web.exposure.include=health,metrics
management.endpoint.health.show-details=always
management.health.circuitbreakers.enabled=true

39.Service Registry:


## 🧭 1. Eureka Server (Service Registry)

### ✅ `pom.xml`

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
</dependency>
```

### ✅ `EurekaServerApplication.java`

```java
@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
    }
}
```

### ✅ `application.properties`

server.port=8761

spring.application.name=eureka-server

eureka.client.register-with-eureka=false
eureka.client.fetch-registry=false
```

---

## 🧩 2. Eureka Client (Microservice)

### ✅ `pom.xml`

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
```

### ✅ `ClientServiceApplication.java`

```java
@SpringBootApplication
@EnableEurekaClient
public class ClientServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClientServiceApplication.class, args);
    }
}
```

### ✅ `application.properties`

```properties
server.port=8081

spring.application.name=client-service

eureka.client.service-url.defaultZone=http://localhost:8761/eureka
```

---

40.Service Discovery :
Service discovery means your application is able to find and communicate with other services dynamically — without hardcoding their URLs — by looking them up in a service registry like Eureka.

Using RestTemplate (or) load balancing:

### ✅ `RestTemplateConfig.java`

`@Configuration
public class SampleConfiguration {

    @LoadBalanced
    @Bean
    public RestTemplate restTemplate() {

        return new RestTemplate();
    }
}



## 🧪 How to Run

1. Start Eureka Server (`localhost:8761`)
2. Start `client-service` and `other-service` (each with unique `spring.application.name`)
3. Visit `http://localhost:8761` to see registered services
4. Call `/call-other` from `client-service` to reach `other-service`


41.Feign Interface:(By default its Synchoronous using - CompletableFuture we can achieve the Async).
A **Feign interface** is a declarative way to make HTTP requests between microservices in Spring Boot. Instead of manually writing `RestTemplate` or `WebClient` code, you define an interface, annotate it, and Spring Cloud Feign automatically generates the client implementation.

---

## 🧭 What Is Feign?

- Part of **Spring Cloud OpenFeign**
- Simplifies **service-to-service communication**
- Uses **interface + annotations** to define REST calls
- Integrates with **Eureka** for service discovery
- Supports **load balancing**, **fallbacks**, and **custom headers**

---

## 🛠️ Simple Feign Interface Example

### ✅ 1. Add Dependency

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-openfeign</artifactId>
</dependency>
```

---

### ✅ 2. Enable Feign in Main Class

```java
@SpringBootApplication
@EnableFeignClients
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

---

### ✅ 3. Create Feign Interface

```java
@FeignClient(name = "calculator-service", url = "http://localhost:8082")
public interface FeignInterface {

    @GetMapping("/getCalProdName/{id}")
    CalculatorEntity getCalculatorById(@PathVariable("id") int id);

    @PostMapping("/postCal")
    CalculatorEntity createCalculator(@RequestBody CalculatorEntity cal);


---

### ✅ 4. Use Feign Client in Your controller

@RestController
public class SampleController {

    @Autowired
    private FeignInterface feignInterface;

    @GetMapping("/getSampleMicro1/{id}")
    public CalculatorEntity getSample(@PathVariable int id) {
        return feignInterface.getCalculatorById(id);
    }

    @PostMapping("/postSample1")
    public CalculatorEntity postSample(@RequestBody CalculatorEntity cal) {
        return feignInterface.createCalculator(cal);
    }
}

## ✅ Benefits of Feign

- No boilerplate HTTP code
- Auto-integrates with Eureka and Ribbon
- Easy to test and mock
- Supports fallback with Hystrix or Resilience4j

42.Circuit Breaker
Absolutely! Here's a complete setup for using **Circuit Breaker with Feign Client** in a Spring Boot application using **Resilience4j**, including all required dependencies, annotations, and configuration.

---

## 🧱 1. Add Dependencies (Maven)

Add these to your `pom.xml`:

```xml
<!-- Feign Client -->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-openfeign</artifactId>
</dependency>

<!-- Resilience4j Circuit Breaker -->
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-spring-boot2</artifactId>
</dependency>

<!-- Spring Boot Actuator (optional for monitoring) -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

Also include Spring Cloud BOM in `dependencyManagement`:

```xml
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-dependencies</artifactId>
            <version>2021.0.8</version> <!-- Use latest compatible version -->
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>
```

---

## ⚙️ 2. Enable Feign Clients

In your main class:

```java
@SpringBootApplication
@EnableFeignClients
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

---

## 🧩 3. Feign Interface

```java
@FeignClient(name = "CalculatorSecoundMicroservices")
public interface FeignInterface {
    @GetMapping("/welcome")
    String getWelcomeMessage();
}
```

---

## 🚦 4. Controller with Circuit Breaker

```java
@RestController
public class SampleController {

    @Autowired
    private FeignInterface feignInterface;

    @CircuitBreaker(name = "calculatorServiceCB", fallbackMethod = "fallbackWelcome")
    @GetMapping("/getsampletest")
    public String Sample() {
        return feignInterface.getWelcomeMessage();
    }

    public String fallbackWelcome(Throwable t) {
        return "Fallback response: Calculator service is currently unavailable.";
    }
}
```

---

## 🛠️ 5. `application.properties`

```properties
spring.application.name=sample-client
server.port=8081

# Eureka Discovery (if used)
eureka.client.service-url.defaultZone=http://localhost:8761/eureka

# Enable Feign and Circuit Breaker
feign.client.config.default.connectTimeout=5000
feign.client.config.default.readTimeout=5000

# Resilience4j Circuit Breaker config (optional)
resilience4j.circuitbreaker.instances.calculatorServiceCB.register-health-indicator=true
resilience4j.circuitbreaker.instances.calculatorServiceCB.sliding-window-size=10
resilience4j.circuitbreaker.instances.calculatorServiceCB.failure-rate-threshold=50
resilience4j.circuitbreaker.instances.calculatorServiceCB.wait-duration-in-open-state=10000
```

---

## ✅ Summary

- You’ve now got a **Feign Client** calling another service.
- If the service fails, **Resilience4j Circuit Breaker** triggers the fallback method.
- You can monitor it via **Spring Boot Actuator** or customize thresholds.

43.API Gateway ?

1. Dependency
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-gateway</artifactId>
</dependency>

2.Main method
@SpringBootApplication
@EnableDiscoveryClient
public class ApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayApplication.class, args);
	}

}

3.application.properties
spring.application.name=APIGateway
server.port=8083

eureka.client.service-url.defaultZone=http://localhost:8761/eureka
spring.cloud.gateway.discovery.locator.enabled=true
spring.cloud.gateway.discovery.locator.lower-case-service-id=true


44.Webclient() ?
WebClient is a non-blocking, reactive HTTP client introduced in Spring 5 (part of the Spring WebFlux library). It is used in Java applications to make HTTP requests (GET, POST, PUT, DELETE) to REST APIs and handle responses asynchronously. It is the modern replacement for RestTemplate.

 What WebClient Does
- Makes HTTP calls: Connects to external APIs or services.
- Reactive & Non-blocking: Uses reactive streams, so it doesn’t block threads while waiting for responses.
- Fluent API: Provides a functional style for building requests and handling responses.
- Supports both sync & async: Can be used in reactive pipelines or in traditional blocking style.


Perfect — let’s build a **complete Spring Boot flow** using `WebClient` for both **GET** and **POST**, showing synchronous and asynchronous styles. I’ll walk you through **dependency → main class → entity → service → controller**.

---

## 1️⃣ Dependency (Maven)
Add **Spring WebFlux** to `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-webflux</artifactId>
</dependency>
```

---

## 2️⃣ Main Application
```java
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebClientDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebClientDemoApplication.class, args);
    }
}
```

---

## 3️⃣ Entity (Data Model)
Let’s model a simple `Post` object:

```java
public class Post {
    private int userId;
    private int id;
    private String title;
    private String body;

    // Constructors
    public Post() {}
    public Post(int userId, String title, String body) {
        this.userId = userId;
        this.title = title;
        this.body = body;
    }

    // Getters and setters
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }
}
```

---

## 4️⃣ WebClient Configuration
```java
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {
    @Bean
    public WebClient webClient(WebClient.Builder builder) {
        return builder.baseUrl("https://jsonplaceholder.typicode.com").build();
    }
}
```

---

## 5️⃣ Service Layer
Here we implement **GET** and **POST** in both sync and async styles.

```java
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class PostService {
    private final WebClient webClient;

    public PostService(WebClient webClient) {
        this.webClient = webClient;
    }

    // ✅ GET - Asynchronous
    public Mono<Post> getPostAsync(int id) {
        return webClient.get()
                .uri("/posts/{id}", id)
                .retrieve()
                .bodyToMono(Post.class);
    }

    // ✅ GET - Synchronous
    public Post getPostSync(int id) {
        return webClient.get()
                .uri("/posts/{id}", id)
                .retrieve()
                .bodyToMono(Post.class)
                .block(); // blocking call
    }

    // ✅ POST - Asynchronous
    public Mono<Post> createPostAsync(Post post) {
        return webClient.post()
                .uri("/posts")
                .bodyValue(post)
                .retrieve()
                .bodyToMono(Post.class);
    }

    // ✅ POST - Synchronous
    public Post createPostSync(Post post) {
        return webClient.post()
                .uri("/posts")
                .bodyValue(post)
                .retrieve()
                .bodyToMono(Post.class)
                .block(); // blocking call
    }
}
```

---

## 6️⃣ Controller Layer
Expose REST endpoints for both sync and async flows.

```java
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/posts")
public class PostController {
    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    // ✅ GET Async
    @GetMapping("/async/{id}")
    public Mono<Post> getPostAsync(@PathVariable int id) {
        return postService.getPostAsync(id);
    }

    // ✅ GET Sync
    @GetMapping("/sync/{id}")
    public Post getPostSync(@PathVariable int id) {
        return postService.getPostSync(id);
    }

    // ✅ POST Async
    @PostMapping("/async")
    public Mono<Post> createPostAsync(@RequestBody Post post) {
        return postService.createPostAsync(post);
    }

    // ✅ POST Sync
    @PostMapping("/sync")
    public Post createPostSync(@RequestBody Post post) {
        return postService.createPostSync(post);
    }
}
```

---

## 🔎 How It Works
- **Async endpoints** return `Mono<Post>` → non-blocking, reactive.
- **Sync endpoints** return `Post` → blocking, waits for response.
- You can test with tools like **Postman** or **curl**:
  - `GET http://localhost:8080/api/posts/async/1`
  - `GET http://localhost:8080/api/posts/sync/1`
  - `POST http://localhost:8080/api/posts/async`
  - `POST http://localhost:8080/api/posts/sync`

---

✅ **Full Flow Recap:**
1. Add WebFlux dependency.  
2. Create Spring Boot main class.  
3. Define entity (`Post`).  
4. Configure `WebClient`.  
5. Implement service with sync & async methods.  
6. Expose controller endpoints for GET and POST.  

