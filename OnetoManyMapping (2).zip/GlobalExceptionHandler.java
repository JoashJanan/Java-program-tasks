package com.PaymentWalletApplication.ExceptionHandler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jakarta.annotation.PostConstruct;

@RestControllerAdvice
public class GlobalExceptionHandler {
	

    @PostConstruct
    public void init() {
        System.out.println("GlobalExceptionHandler initialized");
    }

	@ExceptionHandler(InsufficientBalanceException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
    public ErrorResponse handleInsufficientBalance(InsufficientBalanceException ex) {
		/*
		 * Map<String, Object> body = new HashMap<>(); body.put("timestamp",
		 * LocalDateTime.now()); body.put("status",
		 * HttpStatus.INTERNAL_SERVER_ERROR.value()); body.put("error", "Bad Request");
		 * body.put("message", ex.getMessage());
		 */

        return new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),ex.getMessage());
    }


}
